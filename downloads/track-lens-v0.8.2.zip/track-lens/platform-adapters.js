'use strict';

/*
 * Track Lens platform boundary. The analysis engine lives in background.js;
 * site-specific metadata, on-page discovery and outbound links live here.
 * Both YouTube Music and Spotify Web Player share the
 * background Song Finder engine, cache and harmonic-mixing rules.
 */
(() => {
  const text = node => String(node?.textContent || '').replace(/\s+/g, ' ').trim();
  const clean = value => String(value || '').replace(/\s+/g, ' ').trim();
  const identity = (title, artist) => `${clean(title).toLocaleLowerCase()}::${clean(artist).toLocaleLowerCase()}`;

  function parseCredit(rawTitle, rawArtist) {
    const raw = clean(rawTitle);
    const uploader = clean(rawArtist);
    if (!raw) return null;
    // A label or video channel may be the byline. Artist - Title in the title
    // is a stronger signal for music uploads than the channel name.
    const parts = /^(.{2,100}?)\s+[-–—]\s+(.{2,200})$/.exec(raw);
    const usable = parts && !/^(?:official|music|audio|video|lyric|lyrics|full)$/i.test(parts[1].trim());
    const title = usable ? clean(parts[2]) : raw;
    const artist = usable ? clean(parts[1]) : uploader;
    return title && artist ? {
      title, artist, rawTitle: raw, rawArtist: uploader, parsedVideoTitle: Boolean(usable)
    } : null;
  }

  function bylineName(node) {
    if (!node) return '';
    // For standard tracks, the first credit generally precedes album/duration.
    const full = text(node);
    const credit = node.querySelector('a[href]');
    const fromLink = credit ? text(credit) : '';
    return clean(fromLink || full.split(/[•·]/)[0]);
  }

  function youtubePlayer(doc) {
    const bar = doc.querySelector('ytmusic-player-bar');
    if (!bar) return null;
    const title = text(bar.querySelector('.title.ytmusic-player-bar, .title'));
    const byline = bar.querySelector('.byline.ytmusic-player-bar, .byline');
    const creditedArtists = [...(byline?.querySelectorAll('a[href]') || [])]
      .filter(link => /(?:^|\/)channel\/|(?:^|\/)@/.test(link.getAttribute('href') || ''))
      .map(text).filter(Boolean);
    const rawArtist = creditedArtists.join(', ') || bylineName(byline);
    return parseCredit(title, rawArtist);
  }

  function videoIdFrom(node) {
    const href = node.querySelector('a[href*="watch?v="], a[href*="/watch?v="]')?.getAttribute('href');
    if (!href) return null;
    try {
      const url = new URL(href, 'https://music.youtube.com/');
      const id = url.searchParams.get('v');
      return /^[a-zA-Z0-9_-]{11}$/.test(id || '') ? id : null;
    } catch { return null; }
  }

  function queueItem(row) {
    const title = text(row.querySelector('yt-formatted-string.song-title, .song-title, .title'));
    const rawArtist = bylineName(row.querySelector('yt-formatted-string.byline, .byline'));
    const track = parseCredit(title, rawArtist);
    return track && { ...track, source: 'Up Next', videoId: videoIdFrom(row) };
  }

  function relatedItem(row) {
    // Two-row cards can also be album or playlist recommendations. Those are
    // not a single recording, so avoid treating them as analyzable tracks.
    if (row.localName === 'ytmusic-two-row-item-renderer' && !videoIdFrom(row)) {
      const links = [...row.querySelectorAll('a[href]')].map(node => node.getAttribute('href') || '');
      if (links.some(href => /\/(?:playlist|browse)[/?]/.test(href))) return null;
    }
    const title = text(row.querySelector('yt-formatted-string.title, .title, .flex-column yt-formatted-string, #title yt-formatted-string'));
    const byline = row.querySelector('.secondary-flex-columns yt-formatted-string, yt-formatted-string.subtitle, .subtitle, .byline');
    let rawArtist = bylineName(byline);
    if (!rawArtist) {
      const credits = row.querySelectorAll('.flex-column yt-formatted-string');
      if (credits.length > 1) rawArtist = text(credits[1]);
    }
    const track = parseCredit(title, rawArtist);
    return track && { ...track, source: 'Related', videoId: videoIdFrom(row) };
  }

  function collectYoutubeCandidates(doc) {
    const current = youtubePlayer(doc);
    const currentId = current ? identity(current.title, current.artist) : '';
    const found = [];
    const seen = new Set();
    const counts = { upNext: 0, related: 0 };
    function append(selector, parser, source, limit) {
      const elements = [...doc.querySelectorAll(selector)].slice(0, limit);
      for (const row of elements) {
        if (row.hasAttribute('selected') || row.hasAttribute('is-selected')) continue;
        const track = parser(row);
        if (!track) continue;
        const key = identity(track.title, track.artist);
        if (key === currentId || seen.has(key)) continue;
        seen.add(key);
        found.push(track);
        if (source === 'Up Next') counts.upNext += 1;
        else counts.related += 1;
      }
    }
    // Restrict queue collection to the player page, never playlist/search rows.
    append('ytmusic-player-queue ytmusic-player-queue-item, ytmusic-player-page ytmusic-player-queue-item', queueItem, 'Up Next', 80);
    // Related is normally lazily populated after the user opens that tab.
    append('ytmusic-tab-renderer[page-type="MUSIC_PAGE_TYPE_TRACK_RELATED"] ytmusic-responsive-list-item-renderer, ytmusic-tab-renderer[page-type="MUSIC_PAGE_TYPE_TRACK_RELATED"] ytmusic-two-row-item-renderer, ytmusic-player-page #related ytmusic-responsive-list-item-renderer, ytmusic-player-page #related ytmusic-two-row-item-renderer', relatedItem, 'Related', 80);
    return { candidates: found.slice(0, 40), counts, platform: 'youtube-music' };
  }

  const youtubeMusic = Object.freeze({
    id: 'youtube-music', label: 'YouTube Music',
    host: 'music.youtube.com',
    playerSelector: 'ytmusic-player-bar',
    discoveryHint: 'Find tracks from YouTube Music’s Up Next and Related, then check their harmonic compatibility.',
    readyHint: 'Open Up Next or Related to load suggestions, then press Find Tracks.',
    emptyHint: 'No Up Next or Related songs detected. Open those sections in YouTube Music, then tap Scan again.',
    moreHint: 'Open Related or scroll Up Next, then scan again.',
    readTrack: youtubePlayer,
    collectCandidates: collectYoutubeCandidates,
    openUrl(item) {
      if (/^[a-zA-Z0-9_-]{11}$/.test(item.videoId || '') && item.source !== 'library') {
        return `https://music.youtube.com/watch?v=${item.videoId}`;
      }
      return `https://music.youtube.com/search?q=${encodeURIComponent(`${item.artist} ${item.title}`)}`;
    }
  });
  // Spotify Web Player: only read the rendered page. No private Spotify API,
  // credentials, cookies or playback audio are required. Spotify changes its
  // DOM frequently, so use multiple semantic/aria/data-testid fallbacks.
  const spotifyIdPattern = /^[A-Za-z0-9]{22}$/;
  const spotifyTrackSelector = 'a[href^="/track/"], a[href*="open.spotify.com/track/"]';
  const spotifyArtistSelector = 'a[href^="/artist/"], a[href*="open.spotify.com/artist/"]';

  function spotifyTrackId(link) {
    if (!link) return null;
    try {
      const url = new URL(link.getAttribute('href') || '', 'https://open.spotify.com');
      if (url.hostname !== 'open.spotify.com') return null;
      const match = /^\/track\/([A-Za-z0-9]{22})(?:\/|$)/.exec(url.pathname);
      return match && spotifyIdPattern.test(match[1]) ? match[1] : null;
    } catch { return null; }
  }

  function uniqueText(links, limit = 3) {
    const seen = new Set();
    return [...links].map(text).filter(value => {
      if (!value || seen.has(value.toLowerCase())) return false;
      seen.add(value.toLowerCase());
      return true;
    }).slice(0, limit);
  }

  function spotifyArtist(container) {
    if (!container) return '';
    const names = uniqueText(container.querySelectorAll(spotifyArtistSelector));
    if (names.length) return names[0]; // Primary artist maximises Song Finder match quality.
    // Spotify's Queue may show non-linked credits; tracklist rows usually use
    // an artist link. Use semantic subtitles before any generic text fallback.
    const byline = container.querySelector(
      '[data-testid="context-item-info-subtitles"], ' +
      '[data-testid="tracklist-row-subtitle"], ' +
      '[data-testid="artist-name"], [data-testid="now-playing-artist"], ' +
      '[data-testid="queue-item-artist"], [data-testid="queue-track-artist"], ' +
      '.main-trackList-rowSubTitle, [class*="rowSubTitle"], ' +
      '[class*="queueItemSubtitle"], [class*="queueItemSubTitle"], ' +
      '[class*="ListRowDetails__ListRowDetailText"], .second-line'
    );
    const candidate = text(byline);
    return candidate ? clean(candidate.split(/[,•·]/)[0]) : '';
  }

  function spotifyIdFromUri(uri) {
    const match = /^spotify:track:([A-Za-z0-9]{22})$/.exec(String(uri || '').trim());
    return match?.[1] || null;
  }

  function playingWidgetId(widget, title) {
    // The latest Spotify Web Player often renders the now-playing title as
    // unlinked text. Its enclosing metadata container may still have a URI.
    const container = widget.querySelector('[data-testid="context-item-info-title"], [data-testid="now-playing-track-title"]');
    const scoped = [container, container?.parentElement, widget].filter(Boolean);
    for (const node of scoped) {
      for (const attr of ['data-uri', 'data-item-uri']) {
        const id = spotifyIdFromUri(node.getAttribute(attr));
        if (id) return id;
      }
    }
    // Only inspect links within the title metadata, not unrelated links
    // in the now-playing view (which could be an entirely different track).
    for (const link of container?.querySelectorAll('a[href]') || []) {
      if (text(link) && text(link).toLocaleLowerCase() !== title.toLocaleLowerCase()) continue;
      const id = spotifyTrackId(link) || spotifyIdFromUri(link.getAttribute('data-uri'));
      if (id) return id;
    }
    return null;
  }

  function activeTracklistId(doc, title, artist) {
    // Radio pages sometimes mark the active row without linking the player.
    // Never accept a random tracklist row as the playing track.
    const rows = doc.querySelectorAll('main [data-testid="tracklist-row"], main [role="row"]');
    const found = new Set();
    for (const row of rows) {
      // A selected/focused row is not necessarily the song that is playing.
      if (!row.querySelector('[data-testid="now-playing-indicator"], [data-testid="playing-indicator"]')) continue;
      const link = row.querySelector(spotifyTrackSelector);
      const id = spotifyTrackId(link);
      if (!id) continue;
      const candidateTitle = text(link);
      const candidateArtist = spotifyArtist(row);
      if (candidateTitle.toLocaleLowerCase() !== title.toLocaleLowerCase() ||
          candidateArtist.toLocaleLowerCase() !== artist.toLocaleLowerCase()) continue;
      found.add(id);
    }
    return found.size === 1 ? [...found][0] : null;
  }

  function spotifyPlayer(doc) {
    // Scope to the playback UI: searching all track links would incorrectly
    // treat the first playlist/search result as the currently playing song.
    const widgets = doc.querySelectorAll(
      'footer [data-testid="now-playing-widget"], ' +
      '[data-testid="now-playing-bar"] [data-testid="now-playing-widget"], ' +
      '[data-testid="now-playing-widget"], ' +
      '[data-testid="now-playing-view"]'
    );
    for (const widget of widgets) {
      const titleLink = widget.querySelector(
        '[data-testid="context-item-info-title"] a, ' +
        'a[data-testid="context-item-info-title"], ' +
        '[data-testid="now-playing-track-title"] a, ' +
        spotifyTrackSelector
      );
      const titleNode = titleLink || widget.querySelector('[data-testid="context-item-info-title"], [data-testid="now-playing-track-title"]');
      const title = text(titleNode);
      const artist = spotifyArtist(widget);
      if (!title || !artist) continue;
      const trackId = spotifyTrackId(titleLink) ||
        playingWidgetId(widget, title) || activeTracklistId(doc, title, artist);
      return { title, artist, rawTitle: title, rawArtist: artist, trackId };
    }
    return null;
  }

  function spotifyRow(row, source) {
    const titleLink = row.querySelector(
      'a[data-testid="internal-track-link"], ' +
      '[data-testid="tracklist-row-title"] a, ' +
      spotifyTrackSelector
    );
    const spotifyId = spotifyTrackId(titleLink);
    if (!spotifyId) return null; // Ignore album/playlist/podcast links.
    const title = text(titleLink) || text(row.querySelector('[data-testid="tracklist-row-title"]'));
    const artist = spotifyArtist(row);
    if (!title || !artist) return null;
    return { title, artist, source, spotifyId };
  }

  // Spotify's Queue sometimes renders ordinary text and clickable rows rather
  // than an <a href="/track/...">. Those are still useful *when scoped to the
  // Queue*, provided both a distinct title and a distinct artist are present.
  // Keep Radio strict: its track-link requirement guards against album cards.
  const queueTitleSelector = [
    '[data-testid="queue-track-title"]', '[data-testid="queue-item-title"]',
    '[data-testid="context-item-info-title"]', '[data-testid="tracklist-row-title"]',
    '.main-trackList-rowTitle', '[class*="queueItemTitle"]',
    '[class*="ListRowDetails__ListRowMainText"]', '[class*="rowTitle"]'
  ].join(', ');
  const queueRowSelector = [
    '[data-testid="queue-track"]', '[data-testid="queue-item"]',
    '[data-testid="queue-row"]', '[data-testid="tracklist-row"]',
    '[role="row"]', '[role="listitem"]', 'li',
    '[class*="queueItem"]', '[class*="trackListRow"]', '[class*="ListRow__"]'
  ].join(', ');

  // Spotify's October 2026 Queue markup uses adjacent <p> elements, with
  // the title inside <p><span> and artists linked inside the next <p>.
  // Unlike the Radio tracklist, these Queue items have no /track/ links and
  // no stable title test ID or class. Match the PAIR, not arbitrary page text.
  // Return a result only when the row contains one unambiguous pair.
  function spotifyQueueParagraphPair(row) {
    const pairs = new Map();
    for (const artistsParagraph of row.querySelectorAll('p')) {
      if (!artistsParagraph.querySelector(spotifyArtistSelector) ||
          !artistsParagraph.getClientRects().length) continue;
      const titleParagraph = artistsParagraph.previousElementSibling;
      if (!titleParagraph || titleParagraph.localName !== 'p' ||
          !titleParagraph.getClientRects().length ||
          !titleParagraph.querySelector('span') ||
          titleParagraph.querySelector('a, button')) continue;
      const title = clean(text(titleParagraph));
      const artist = spotifyArtist(artistsParagraph);
      if (!title || !artist || title.toLocaleLowerCase() === artist.toLocaleLowerCase() ||
          title.length > 240) continue;
      pairs.set(identity(title, artist), { title, artist });
    }
    return pairs.size === 1 ? [...pairs.values()][0] : null;
  }

  function spotifyQueueRow(row) {
    const linked = spotifyRow(row, 'Queue');
    if (linked) return linked;
    // Fallback is limited to Queue scopes: no guessing from ordinary playlists.
    // Outer wrappers containing multiple song titles are not individual rows.
    if (row.querySelectorAll(spotifyTrackSelector).length > 1 ||
        row.querySelector('a[href^="/album/"], a[href^="/playlist/"], a[href^="/episode/"], a[href^="/show/"]')) return null;
    const titleNodes = [...row.querySelectorAll(queueTitleSelector)]
      .filter(node => text(node) && node.getClientRects().length);
    const titles = [...new Set(titleNodes.map(text))];
    if (titles.length > 1) return null;
    const paragraphPair = spotifyQueueParagraphPair(row);
    if (!titles.length && !paragraphPair) return null;
    if (titles.length && paragraphPair && titles[0] !== paragraphPair.title) return null;
    const title = titles[0] || paragraphPair.title;
    const artist = paragraphPair?.artist || spotifyArtist(row);
    if (!artist || !title || title.toLocaleLowerCase() === artist.toLocaleLowerCase() ||
        /^(?:queue|now playing|next in queue|next from.*|recently played)$/i.test(title)) return null;
    const ref = row.getAttribute('data-uri') || row.getAttribute('data-track-uri') ||
      row.getAttribute('data-item-uri') || row.querySelector('[data-uri^="spotify:track:"]')?.getAttribute('data-uri') || '';
    const spotifyId = /^spotify:track:([A-Za-z0-9]{22})$/.exec(ref)?.[1] || null;
    return { title, artist, source: 'Queue', spotifyId };
  }

  function spotifyQueueRows(scope) {
    const candidates = new Set(scope.querySelectorAll(queueRowSelector));
    // Queue designs without <li>, role=row or stable row classes still have
    // explicit title nodes; walk up only as far as the first artist-bearing row.
    for (const titleNode of scope.querySelectorAll(queueTitleSelector)) {
      let parent = titleNode.closest(queueRowSelector);
      if (!parent || !scope.contains(parent)) {
        parent = titleNode.parentElement;
        for (let i = 0; parent && parent !== scope && i < 6; i++, parent = parent.parentElement) {
          if (spotifyArtist(parent) && new Set([...parent.querySelectorAll(queueTitleSelector)].map(text)).size === 1) break;
        }
      }
      if (parent && parent !== scope && scope.contains(parent)) candidates.add(parent);
    }
    // Prefer rows nearest the title rather than a generic outer li containing
    // multiple descendants. The resulting track identities are deduped below.
    return [...candidates].filter(row => row.getClientRects().length);
  }

  const spotifyRowSelector =
    '[data-testid="tracklist-row"], [role="row"], [role="listitem"], ' +
    '[data-testid="queue-track"], [class*="main-trackList-trackListRow"], ' +
    '[class*="ListRow__"], li';

  function spotifyRows(scope) {
    // Queue uses list items, radio/playlist uses grid rows. When Spotify
    // changes wrappers, find the smallest parent around each *track link*;
    // never fall back to scraping every label on the page.
    const rows = new Set([...scope.querySelectorAll(spotifyRowSelector)]);
    for (const link of [...scope.querySelectorAll(spotifyTrackSelector)].slice(0, 180)) {
      if (!spotifyTrackId(link)) continue;
      let row = link.closest(spotifyRowSelector);
      if (!row || !scope.contains(row)) {
        let parent = link.parentElement;
        for (let depth = 0; parent && parent !== scope && depth < 6; depth++, parent = parent.parentElement) {
          if (parent.querySelectorAll(spotifyTrackSelector).length !== 1) break;
          if (spotifyArtist(parent)) { row = parent; break; }
        }
      }
      if (row && scope.contains(row)) rows.add(row);
    }
    // Nested [role=row] and [data-testid=tracklist-row] wrappers refer to the
    // same track. Prefer the outer row, retaining links and artist credits.
    return [...rows].filter(row => ![...rows].some(other => other !== row && other.contains(row)));
  }

  function sectionIsUnrelated(row, boundary) {
    // Spotify Radio tracks frequently live inside an unlabelled <section>.
    // Do not reject those sections (the old code rejected *all* of them).
    // Ignore only explicitly labelled editorial/recommendation sections.
    for (let parent = row.parentElement; parent && parent !== boundary; parent = parent.parentElement) {
      if (parent.tagName !== 'SECTION') continue;
      const label = clean(parent.getAttribute('aria-label') ||
        text(parent.querySelector(':scope > h2, :scope > h3, :scope > header h2, :scope > header h3')));
      if (/\b(recommended|recommendations|made for|fans also like|you might also like|artists? you may|albums? you may|popular releases)\b/i.test(label)) {
        return true;
      }
    }
    return false;
  }

  function queueRowIsHistory(row, boundary) {
    for (let parent = row.parentElement; parent && parent !== boundary; parent = parent.parentElement) {
      if (parent.tagName !== 'SECTION' && parent.getAttribute('role') !== 'region') continue;
      const heading = text(parent.querySelector(':scope > h2, :scope > h3, :scope > header h2, :scope > header h3'));
      if (/^(?:now playing|recently played|history)$/i.test(heading)) return true;
    }
    return false;
  }

  function spotifyRadioPage(doc, main) {
    const path = doc.location?.pathname || location.pathname;
    if (/^\/radio(?:\/|$)/i.test(path)) return true;
    if (!main) return false;
    const headings = [...main.querySelectorAll('h1, [data-testid="entityTitle"]')]
      .slice(0, 8).map(text).filter(Boolean);
    // Spotify Song Radio is commonly presented as a playlist (e.g. Jupiter
    // Radio at /playlist/...). Do not scan ordinary playlists or searches.
    if (headings.some(label => /\bradio\s*$/i.test(label))) return true;
    if (!headings.length && /^\/playlist\//i.test(path)) {
      return /\bradio\s*(?:[-|·]|$)/i.test(doc.title || '');
    }
    return false;
  }

  function spotifyQueueScopes(doc) {
    const selectors = [
      '[data-testid="queue-page"]', '[data-testid="queue-side-panel"]',
      '[data-testid="queue-panel"]', '[data-testid="queue-view"]',
      '[data-testid="queue-list"]', '[data-testid="queue-content"]',
      '[data-testid="queue-container"]', '#queue-panel',
      '[aria-label="Queue"]', '[aria-label="Play Queue"]',
      '[aria-label="Next in queue"]'
    ];
    const scopes = new Set(doc.querySelectorAll(selectors.join(', ')));
    // Some Spotify versions use a generic right sidebar without queue-specific
    // test IDs. Only use it when a visible heading actually says Queue.
    for (const aside of doc.querySelectorAll(
      'aside, [role="complementary"], [data-testid="right-sidebar"], [data-testid="right-sidebar-content"]'
    )) {
      const headings = [...aside.querySelectorAll('h1, h2, h3, [role="heading"]')].slice(0, 12);
      if (headings.some(node => /^(?:Queue|Next in queue|Next from\b.*)$/i.test(text(node)))) {
        scopes.add(aside);
      }
    }
    // A toolbar button with aria-label="Queue" is an opener, not a Queue
    // container. It produced a misleading empty scope in the diagnostics.
    return [...scopes].filter(scope =>
      !scope.matches('button, [role="button"]') &&
      ![...scopes].some(parent => parent !== scope && parent.contains(scope)));
  }

  function collectSpotifyCandidates(doc) {
    const current = spotifyPlayer(doc);
    const currentIdentity = current ? identity(current.title, current.artist) : '';
    const candidates = [];
    const seen = new Set();
    const counts = { Queue: 0, Radio: 0, Recommended: 0 };
    const diagnostics = { radioPage: false, Queue: { rows: 0, linked: 0, parsed: 0 },
      Radio: { rows: 0, linked: 0, parsed: 0 },
      Recommended: { rows: 0, linked: 0, parsed: 0 } };

    function append(container, source, radioOnly = false) {
      if (!container) return;
      const rows = (source === 'Queue' ? spotifyQueueRows(container) : spotifyRows(container)).slice(0, 160);
      for (const row of rows) {
        // Skip collapsed panels, but not below-the-fold scrollable track rows.
        if (!row.getClientRects().length) continue;
        if (radioOnly && sectionIsUnrelated(row, container)) continue;
        if (source === 'Queue' && queueRowIsHistory(row, container)) continue;
        diagnostics[source].rows += 1;
        const parsed = source === 'Queue' ? spotifyQueueRow(row) : spotifyRow(row, source);
        if (!parsed) continue;
        diagnostics[source].linked += 1;
        const key = identity(parsed.title, parsed.artist);
        if (key === currentIdentity || seen.has(key)) continue;
        seen.add(key);
        candidates.push(parsed);
        counts[source] += 1;
        diagnostics[source].parsed += 1;
      }
    }

    // A Radio page can be a /playlist/... page with a heading such as
    // 'Jupiter Radio'. Use the tracklist scope, not every Spotify page row.
    const main = doc.querySelector('[data-testid="main-view"], #main-view, main');
    const isRadio = spotifyRadioPage(doc, main);
    diagnostics.radioPage = isRadio;
    if (isRadio) {
      const tracklist = main?.querySelector(
        '[data-testid="playlist-tracklist"], [data-testid="track-list"], ' +
        '[data-testid="tracklist"], [data-testid="main-tracklist"], ' +
        '[role="grid"], [role="table"]'
      ) || main;
      append(tracklist, 'Radio', true);
    }

    // Spotify Queue can appear in a right-side panel, a Queue page, or an
    // <aside> without test IDs. Queue metadata can be link-less: accept rows
    // only with a distinct title and artist inside the Queue scope.
    // Deduplicate against Radio rows by title and artist.
    const queueScopes = spotifyQueueScopes(doc);
    for (const scope of queueScopes) append(scope, 'Queue');
    const path = doc.location?.pathname || location.pathname;
    if (/^\/queue(?:\/|$)/.test(path) && !queueScopes.length) {
      append(main, 'Queue');
    }

    // Keep unrelated playlists, search results and the user's library out.
    const sections = doc.querySelectorAll('main section, #main-view section, [data-testid="recommendations"], [data-testid="recommendations-section"]');
    for (const section of sections) {
      const label = clean(section.getAttribute('aria-label') ||
        text(section.querySelector('h2, h3, [data-testid="section-header"]')));
      if (/\b(recommended|recommendations|suggested|related tracks|more like this|songs you may like)\b/i.test(label)) {
        append(section, 'Recommended');
      }
    }
    return { candidates: candidates.slice(0, 40), counts, diagnostics, platform: 'spotify' };
  }

  // Diagnostic-only inspection for Spotify's evolving Queue markup. The
  // report is composed solely from DOM structure: NO song/artist text, links,
  // account information, HTML source, cookies, storage or audio are included.
  // The user explicitly chooses when to copy it; nothing is transmitted.
  const safeToken = value => {
    const candidate = String(value || '');
    return /^[a-zA-Z][a-zA-Z_-]{0,72}$/.test(candidate) ? candidate : undefined;
  };

  function diagnosticNode(node) {
    if (!node || node.nodeType !== 1) return null;
    const info = { tag: node.localName };
    const testId = safeToken(node.getAttribute('data-testid'));
    const role = safeToken(node.getAttribute('role'));
    if (testId) info.testId = testId;
    if (role) info.role = role;
    const classes = [...node.classList].filter(name =>
      /queue|track|list|row|title|artist|subtitle|song/i.test(name))
      .map(safeToken).filter(Boolean).slice(0, 4);
    if (classes.length) info.classes = classes;
    if (node.hasAttribute('aria-label')) info.hasAriaLabel = true;
    if (node.localName === 'a') {
      const href = node.getAttribute('href') || '';
      info.linkKind = /(?:^|\/)track\//.test(href) ? 'track'
        : /(?:^|\/)artist\//.test(href) ? 'artist'
          : /(?:^|\/)album\//.test(href) ? 'album' : 'other';
    }
    if (node.getAttribute('data-uri')?.startsWith('spotify:track:')) info.hasTrackUri = true;
    return info;
  }

  function diagnosticTree(root, maxNodes = 48, maxDepth = 7) {
    let remaining = maxNodes;
    function build(node, depth) {
      if (!node || remaining <= 0) return null;
      remaining -= 1;
      const result = diagnosticNode(node);
      if (!result) return null;
      if (depth >= maxDepth) {
        if (node.children.length) result.childrenTruncated = node.children.length;
        return result;
      }
      const children = [];
      for (const child of node.children) {
        if (remaining <= 0) break;
        const data = build(child, depth + 1);
        if (data) children.push(data);
      }
      if (children.length) result.children = children;
      if (children.length < node.children.length) result.childrenTruncated = node.children.length - children.length;
      return result;
    }
    return build(root, 0);
  }

  function diagnoseQueueRow(row, scope) {
    if (!row.getClientRects().length) return 'not-rendered';
    if (queueRowIsHistory(row, scope)) return 'previously-played-section';
    if (spotifyQueueRow(row)) return 'accepted';
    const allTitles = [...row.querySelectorAll(queueTitleSelector)];
    const visibleTitles = allTitles.filter(node => text(node) && node.getClientRects().length);
    if (!visibleTitles.length) return 'title-selector-or-paragraph-pair-missed';
    if (new Set(visibleTitles.map(text)).size !== 1) return 'multiple-distinct-titles';
    if (row.querySelectorAll(spotifyTrackSelector).length > 1) return 'multiple-track-links';
    if (!spotifyArtist(row)) return 'artist-selector-missed';
    return 'unusable-metadata';
  }

  function diagnoseSpotifyQueue(doc) {
    const main = doc.querySelector('[data-testid="main-view"], #main-view, main');
    const path = doc.location?.pathname || location.pathname;
    const scopes = spotifyQueueScopes(doc);
    if (/^\/queue(?:\/|$)/.test(path) && !scopes.length && main) scopes.push(main);
    // These counters expose selector coverage without including text content.
    const diagnosticSelectors = {
      trackLinks: spotifyTrackSelector,
      artistLinks: spotifyArtistSelector,
      knownTitleNodes: queueTitleSelector,
      possibleTitleNodes: '[data-testid*="title" i], [class*="title" i]',
      possibleArtistNodes: '[data-testid*="artist" i], [class*="artist" i], [class*="subtitle" i]',
      genericRowNodes: queueRowSelector
    };
    const report = {
      diagnosticVersion: 2,
      extensionVersion: chrome.runtime.getManifest().version,
      platform: 'spotify-web-player',
      capturedAtUTC: new Date().toISOString(),
      privacy: 'Structural counts and tag/testid/class patterns only. No page URLs, titles, artists, account IDs, text, links, cookies, or audio. Copied only when requested.',
      pageKind: spotifyRadioPage(doc, main) ? 'radio' : /^\/queue(?:\/|$)/.test(path) ? 'queue' : 'other',
      queueScopesDetected: scopes.length,
      scopes: []
    };
    const totals = { rows: 0, accepted: 0, rejected: 0, reasons: {} };
    for (const scope of scopes.slice(0, 5)) {
      const rows = spotifyQueueRows(scope).slice(0, 160);
      const reasons = {};
      const examplesByReason = new Map();
      for (const row of rows) {
        const reason = diagnoseQueueRow(row, scope);
        reasons[reason] = (reasons[reason] || 0) + 1;
        const shape = JSON.stringify(diagnosticNode(row));
        if (!examplesByReason.has(reason)) examplesByReason.set(reason, new Map());
        const examples = examplesByReason.get(reason);
        const existing = examples.get(shape);
        if (!existing || row.querySelectorAll('a, [data-testid], [role]').length >
            existing.querySelectorAll('a, [data-testid], [role]').length) {
          examples.set(shape, row);
        }
      }
      totals.rows += rows.length;
      totals.accepted += reasons.accepted || 0;
      totals.rejected += rows.length - (reasons.accepted || 0);
      for (const [reason, count] of Object.entries(reasons)) {
        totals.reasons[reason] = (totals.reasons[reason] || 0) + count;
      }
      const selectorCounts = {};
      for (const [name, selector] of Object.entries(diagnosticSelectors)) {
        selectorCounts[name] = scope.querySelectorAll(selector).length;
      }
      selectorCounts.queueParagraphPairs = rows.filter(row => Boolean(spotifyQueueParagraphPair(row))).length;
      // Include more than one distinct row shape for the dominant failure,
      // but cap the report so copying it stays practical on mobile.
      const samples = [];
      const ordered = [...examplesByReason.entries()]
        .sort((a, b) => (reasons[b[0]] || 0) - (reasons[a[0]] || 0));
      for (const [reason, variants] of ordered) {
        for (const row of [...variants.values()].slice(0, samples.length ? 1 : 3)) {
          if (samples.length >= 5) break;
          samples.push({
            reason,
            row: diagnosticNode(row),
            nodes: {
              matchingTitleSelectors: row.querySelectorAll(queueTitleSelector).length,
              trackLinks: row.querySelectorAll(spotifyTrackSelector).length,
              artistLinks: row.querySelectorAll(spotifyArtistSelector).length,
              elementChildren: row.children.length
            },
            structure: diagnosticTree(row)
          });
        }
        if (samples.length >= 5) break;
      }
      report.scopes.push({
        scope: diagnosticNode(scope),
        candidateRows: rows.length,
        selectorCounts,
        reasons,
        samples
      });
    }
    report.totals = totals;
    report.help = 'Compare title/artist selectors with each rejected-row structure to update the Spotify Queue adapter.';
    return report;
  }

  const spotify = Object.freeze({
    id: 'spotify', label: 'Spotify', host: 'open.spotify.com',
    playerSelector: '[data-testid="now-playing-widget"], [data-testid="now-playing-view"]',
    discoveryHint: 'Find compatible tracks from the Spotify Queue, Song Radio and visible recommended songs.',
    readyHint: 'Open Spotify’s Queue or a Song Radio page to load candidates, then press Find Tracks.',
    emptyHint: 'No Spotify Queue, Song Radio or recommendation tracks detected. Open the Queue or a Song Radio page, then tap Scan again.',
    moreHint: 'Load more tracks in the Queue or Song Radio, then scan again.',
    readTrack: spotifyPlayer,
    collectCandidates: collectSpotifyCandidates,
    diagnoseQueue: diagnoseSpotifyQueue,
    openUrl(item) {
      if (spotifyIdPattern.test(item.spotifyId || '') && item.source !== 'library') {
        return `https://open.spotify.com/track/${item.spotifyId}`;
      }
      return `https://open.spotify.com/search/${encodeURIComponent(`${item.artist} ${item.title}`)}`;
    }
  });

  const registry = Object.freeze({ [youtubeMusic.host]: youtubeMusic, [spotify.host]: spotify });
  globalThis.TrackLensPlatformAdapters = Object.freeze({
    get(hostname = location.hostname) { return registry[hostname] || null; },
    parseCredit
  });
})();
