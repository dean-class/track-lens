'use strict';

// Keep the original storage names so upgrading the existing unpacked extension
// preserves manual matches, analysed songs and the panel's saved size.
const CACHE_KEY = 'listener-track-lens-cache-v1';
const MANUAL_VALUES_KEY = 'track-lens-user-metrics-v1';
const HARMONIC_CACHE_KEYS = ['track-lens-harmonic-v1', 'track-lens-harmonic-v2'];
const MINI_KEY = 'listener-track-lens-mini';
const PICKER_KEY = 'track-lens-auto-open-matching';
const DIAGNOSTICS_KEY = 'track-lens-advanced-diagnostics';
const THEME_KEY = 'track-lens-theme-v1';
const DESKTOP_KEY = 'track-lens-desktop-position-v1';
const DISMISSED_KEY = 'track-lens-dismissed-reviews-v1';

const autoPicker = document.getElementById('auto-open-picker');
const startMini = document.getElementById('start-minimised');
const advancedDiagnostics = document.getElementById('advanced-diagnostics');
const themeChoice = document.getElementById('theme-choice');
const resetDesktopPosition = document.getElementById('reset-desktop-position');
const clearCache = document.getElementById('clear-cache');
const message = document.getElementById('settings-message');

document.getElementById('version').textContent = `v${chrome.runtime.getManifest().version}`;

function notify(text, isError = false) {
  message.textContent = text;
  message.classList.toggle('error', isError);
}

async function start() {
  try {
    const saved = await chrome.storage.local.get([PICKER_KEY, MINI_KEY, DIAGNOSTICS_KEY, THEME_KEY]);
    themeChoice.value = saved[THEME_KEY] === 'light' ? 'light' : 'dark';
    document.documentElement.dataset.theme = themeChoice.value;
    autoPicker.checked = saved[PICKER_KEY] !== false;
    advancedDiagnostics.checked = saved[DIAGNOSTICS_KEY] === true;
    startMini.checked = typeof saved[MINI_KEY] === 'boolean'
      ? saved[MINI_KEY] : window.matchMedia('(max-width: 600px)').matches;
  } catch (error) {
    notify(`Couldn't read preferences: ${error.message}`, true);
  }
}

themeChoice.addEventListener('change', async () => {
  document.documentElement.dataset.theme = themeChoice.value;
  try {
    await chrome.storage.local.set({[THEME_KEY]: themeChoice.value});
    notify('Theme saved. Open music tabs update immediately.');
  } catch(error) {notify(`Could not save theme: ${error.message}`,true);}
});

resetDesktopPosition.addEventListener('click', async () => {
  try { await chrome.storage.local.remove(DESKTOP_KEY); notify('Desktop panel position reset.'); }
  catch(error) {notify(`Could not reset position: ${error.message}`,true);}
});

autoPicker.addEventListener('change', async () => {
  try {
    await chrome.storage.local.set({ [PICKER_KEY]: autoPicker.checked });
    notify('Preference saved. New track lookups will use this setting.');
  } catch (error) {
    notify(`Couldn't save preference: ${error.message}`, true);
  }
});

advancedDiagnostics.addEventListener('change', async () => {
  try {
    await chrome.storage.local.set({ [DIAGNOSTICS_KEY]: advancedDiagnostics.checked });
    notify('Diagnostic preference saved. The player panel has been updated.');
  } catch (error) { notify(`Could not save diagnostics preference: ${error.message}`, true); }
});

startMini.addEventListener('change', async () => {
  try {
    await chrome.storage.local.set({ [MINI_KEY]: startMini.checked });
    notify('Panel preference saved.');
  } catch (error) {
    notify(`Couldn't save preference: ${error.message}`, true);
  }
});

clearCache.addEventListener('click', async () => {
  const confirmed = window.confirm('Clear saved track analyses, manual matches, manually entered metrics, dismissed reviews and harmonic recommendations? Panel preferences will stay unchanged.');
  if (!confirmed) return;
  clearCache.disabled = true;
  try {
    await chrome.storage.local.remove([CACHE_KEY, MANUAL_VALUES_KEY, DISMISSED_KEY, ...HARMONIC_CACHE_KEYS]);
    notify('Track cache cleared. Refresh the music player tab or click ↻ in the panel to look up a track again.');
  } catch (error) {
    notify(`Couldn't clear cache: ${error.message}`, true);
  } finally {
    clearCache.disabled = false;
  }
});

start();


// Portable backups: the unpacked and Web Store versions have different
// extension IDs, therefore separate chrome.storage.local namespaces.
const BACKUP_KEYS = [CACHE_KEY, MANUAL_VALUES_KEY, ...HARMONIC_CACHE_KEYS,
  MINI_KEY, PICKER_KEY, DIAGNOSTICS_KEY, 'track-lens-mobile-position-v1', THEME_KEY, DESKTOP_KEY, DISMISSED_KEY];
const BACKUP_FORMAT = 'track-lens-library-backup';
const BACKUP_VERSION = 1;

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

const exportBackup = document.getElementById('export-backup');
exportBackup.addEventListener('click', async () => {
  try {
    const stored = await chrome.storage.local.get(BACKUP_KEYS);
    const backup = { format: BACKUP_FORMAT, version: BACKUP_VERSION,
      exportedAt: new Date().toISOString(), data: stored };
    const blob = new Blob([JSON.stringify(backup, null, 2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `track-lens-backup-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    notify('Backup exported. Keep this JSON file private because it contains your music library and manual matches.');
  } catch (error) { notify(`Could not export backup: ${error.message}`, true); }
});

const importBackup = document.getElementById('import-backup');
importBackup.addEventListener('change', async () => {
  try {
    const file = importBackup.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) throw new Error('Backup is larger than 5 MB.');
    const parsed = JSON.parse(await file.text());
    if (parsed?.format !== BACKUP_FORMAT || parsed.version !== BACKUP_VERSION || !isPlainObject(parsed.data)) {
      throw new Error('This is not a recognised Track Lens backup.');
    }
    const values = {};
    for (const key of BACKUP_KEYS) {
      if (!Object.prototype.hasOwnProperty.call(parsed.data,key)) continue;
      const value = parsed.data[key];
      if ([PICKER_KEY,MINI_KEY,DIAGNOSTICS_KEY].includes(key)) {
        if (typeof value !== 'boolean') throw new Error(`Invalid setting in backup: ${key}`);
      } else if (key === THEME_KEY) {
        if (!['light','dark'].includes(value)) throw new Error('Invalid theme in backup.');
      } else if (key === DESKTOP_KEY) {
        if (!isPlainObject(value) || !['x','y'].every(k => typeof value[k] === 'number' && Number.isFinite(value[k]) && value[k] >= 0 && value[k] <= 1))
          throw new Error('Invalid desktop panel position.');
      } else if (key === 'track-lens-mobile-position-v1') {
        if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 1) throw new Error('Invalid panel position.');
      } else if (!isPlainObject(value)) throw new Error(`Invalid stored library in backup: ${key}`);
      values[key] = value;
    }
    if (!Object.keys(values).length) throw new Error('Backup contains no supported Track Lens data.');
    if (!window.confirm('Restore this backup? Matching saved keys will overwrite the values in this browser profile.')) return;
    await chrome.storage.local.set(values);
    notify('Backup restored. Reload open Spotify / YouTube Music tabs to use it.');
    await start();
  } catch(error) { notify(`Could not import backup: ${error.message}`, true); }
  finally { importBackup.value = ''; }
});
