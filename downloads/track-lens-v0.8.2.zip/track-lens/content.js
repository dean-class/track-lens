(() => {
  'use strict';
  if (document.getElementById('listener-track-lens-host')) return;
  const adapter = globalThis.TrackLensPlatformAdapters?.get(location.hostname);
  if (!adapter) return;

  const host = document.createElement('div');
  host.id = 'listener-track-lens-host';
  host.style.cssText = 'all:initial;position:fixed;right:16px;bottom:calc(90px + env(safe-area-inset-bottom, 0px));z-index:2147483646;display:block;';
  const shadow = host.attachShadow({ mode: 'open' });
  // Styles stay within this content script: no page -> chrome-extension:// CSS request.
  // This also avoids failures caused by stale extension-resource links after reloads.
  const panelStyles = new CSSStyleSheet();
  panelStyles.replaceSync(String.raw`
:host { color-scheme: dark; }
* { box-sizing: border-box; }
[hidden] { display: none !important; }
.ltl {
  --bg: #12181d;
  --surface: #20292e;
  --edge: #344047;
  --soft: #9dabaf;
  --ink: #f0f5f3;
  --sea: #83d8c6;
  --gold: #f4be76;
  position: relative;
  width: min(364px, calc(100vw - 32px));
  max-height: calc(100vh - 112px);
  overflow-y: auto;
  overflow-x: hidden;
  border: 1px solid #3d4c52;
  border-radius: 15px;
  color: var(--ink);
  font: normal 12px/1.42 -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
  background: var(--bg);
  box-shadow: 0 22px 56px #000b, 0 4px 16px #0006;
  scrollbar-width: thin;
  scrollbar-color: #40515a transparent;
}
.ltl.minimised { width: min(335px, calc(100vw - 32px)); }
.ltl-header {
  min-height: 43px;
  padding: 9px 12px 8px 13px;
  background: linear-gradient(125deg, #1a2528, #182027);
  border-bottom: 1px solid var(--edge);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}
.ltl-identity { display: flex; align-items: center; gap: 7px; font-size: 10px; letter-spacing: 1.75px; font-weight: 790; white-space: nowrap; }
.ltl-mark { display: inline-flex; align-items: center; justify-content: center; font-size: 19px; color: var(--sea); line-height: 1; }
.ltl-submark { color: #a8b7b9; font-weight: 550; letter-spacing: 1.25px; margin-left: 3px; }
.ltl-actions { display: flex; align-items: center; gap: 4px; }
.ltl-icon { width: 27px; height: 26px; border-radius: 7px; border: 1px solid transparent; background: transparent; color: #b6c6ca; font-size: 20px; line-height: 1; cursor: pointer; }
.ltl-icon:hover { color: #f1f9f6; background: #324047; border-color: #4d5c64; }
.ltl-icon:disabled { opacity: .38; cursor: wait; }
.ltl-expanded { padding: 12px 13px 10px; }
.ltl-song { margin-bottom: 7px; min-height: 46px; }
.ltl-song-title { font-size: 15px; line-height: 1.35; font-weight: 720; letter-spacing: -.14px; overflow-wrap: anywhere; max-height: 42px; overflow: hidden; }
.ltl-song-artist { font-size: 11px; margin-top: 3px; color: var(--soft); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ltl-status { min-height: 21px; display: flex; align-items: center; gap: 5px; font-size: 10px; color: #9eafb3; padding-bottom: 5px; }
.ltl-status::before { content: ''; width: 5px; height: 5px; flex: 0 0 auto; border-radius: 100%; background: #80969a; }
.ltl-status[data-kind="success"]::before { background: var(--sea); }
.ltl-status[data-kind="error"] { color: #ffaaa6; }
.ltl-status[data-kind="error"]::before { background: #ff8281; }
.ltl-status[data-kind="warning"] { color: #f7c58b; }
.ltl-status[data-kind="warning"]::before { background: #f7b977; }
.ltl-metrics { display: grid; grid-template-columns: .83fr .95fr 1.07fr .97fr; gap: 5px; margin: 5px 0 13px; }
.ltl-metric { background: var(--surface); border: 1px solid var(--edge); border-radius: 9px; padding: 9px 5px 7px; text-align: center; min-width: 0; }
.ltl-metric-label { display: block; color: #a9b7b9; font-size: 9px; font-weight: 800; letter-spacing: .65px; margin-bottom: 2px; }
.ltl-metric strong { display: inline-block; font-size: 23px; line-height: 1.15; font-weight: 760; font-variant-numeric: tabular-nums; letter-spacing: -.5px; white-space: nowrap; }
.ltl-metric:nth-child(2) strong { color: #d2e6e2; }
.ltl-metric.ltl-spotlight { border-color: #796348; background: #312a22; }
.ltl-metric.ltl-spotlight strong { color: var(--gold); }
.ltl-scale { display: inline-block; font-size: 9px; font-weight: 650; color: #a4b1b4; margin-left: 1px; }
.ltl-bars { display: grid; gap: 8px; margin-bottom: 13px; }
.ltl-barline { display: grid; grid-template-columns: 81px 1fr; gap: 8px; align-items: center; font-size: 10px; color: #bec9cb; }
.ltl-bartrack { border-radius: 99px; height: 6px; background: #303b40; overflow: hidden; }
.ltl-fill { height: 100%; width: 0%; border-radius: inherit; transition: width 230ms ease; }
.ltl-energy-fill { background: linear-gradient(90deg, #d88c60, #f4be76); }
.ltl-dance-fill { background: linear-gradient(90deg, #48ae9c, #83d8c6); }
.ltl-keyinfo { border-top: 1px solid #2c373c; padding: 10px 0; display: flex; justify-content: space-between; align-items: baseline; gap: 8px; font-size: 11px; }
.ltl-keyinfo span:first-child { font-weight: 690; }
.ltl-keyinfo span:last-child { color: #9eb3b6; text-align: right; font-size: 10px; }
.ltl-warning { border: 1px solid #7c5c3c; background: #32261f; border-radius: 8px; color: #f0c498; padding: 8px; font-size: 10px; margin-bottom: 9px; }
.ltl-foot { display: flex; justify-content: space-between; align-items: center; gap: 8px; border-top: 1px solid #2c373c; padding-top: 10px; }
.ltl-source { font-size: 9px; font-weight: 760; letter-spacing: .9px; color: #7f959b; }
.ltl-source a { color: #94c5bb; margin-left: 3px; text-decoration: none; }
.ltl-source a:hover { text-decoration: underline; }
.ltl-link { color: #afdfd4; text-decoration: none; border: 0; background: none; letter-spacing: .5px; font-weight: 740; font-size: 9px; cursor: pointer; }
.ltl-link:hover { color: #e4fff8; text-decoration: underline; }
.ltl-picker { margin-top: 10px; padding: 11px; background: #1e282d; border: 1px solid #3b4a52; border-radius: 10px; }
.ltl-picker label { color: #cfdbdd; font-size: 11px; display: block; margin-bottom: 6px; }
.ltl-picker select, .ltl-picker input { border: 1px solid #4a5b63; border-radius: 6px; background: #10171b; color: #ecf6f3; padding: 9px 7px; width: 100%; font: inherit; outline: none; }
.ltl-picker select:focus, .ltl-picker input:focus { border-color: #82d3c4; }
.ltl-small-btn { padding: 8px 9px; font: inherit; font-weight: 700; cursor: pointer; background: #31594f; color: #e2fff5; border: 1px solid #568579; border-radius: 6px; white-space: nowrap; }
.ltl-small-btn:hover { background: #3d7266; }
.ltl-small-btn:disabled { opacity: .45; cursor: not-allowed; }
#ltl-use-match { margin: 8px 0 4px; }
.ltl-search { display: flex; gap: 5px; margin-top: 7px; }
.ltl-search input { min-width: 0; }
.ltl-match-note { color: #82969c; margin-top: 10px; font-size: 9px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.ltl-compact { font-size: 10.5px; color: #c4d6d2; padding: 10px 13px; font-weight: 600; font-variant-numeric: tabular-nums; }
.ltl-icon:focus-visible, .ltl-link:focus-visible, .ltl-small-btn:focus-visible { outline: 2px solid #93e6d8; outline-offset: 2px; }
@media (max-width: 500px) { .ltl { width: min(340px, calc(100vw - 32px)); } .ltl-metrics { gap: 4px; } .ltl-metric strong { font-size: 20px; } }

/* v0.2: clearly labelled Help entry and in-panel manual search guidance. */
.ltl-help { color: #aee7db; background: #24373a; border: 1px solid #405b5b; border-radius: 6px; padding: 5px 7px; cursor: pointer; font: 750 9px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; letter-spacing: .5px; }
.ltl-help:hover { border-color: #81cabe; background: #31504d; color: #e7fff8; }
.ltl-picker-title { color: #a5d6cc; font-size: 10px; font-weight: 780; letter-spacing: 1px; margin-bottom: 5px; }
.ltl-picker-hint { color: #bfced0; font-size: 11px; line-height: 1.55; margin: 0 0 13px; }
.ltl-picker .ltl-search-label { margin-top: 12px; margin-bottom: 0; font-weight: 700; }
.ltl-picker-tip { color: #90a6aa; font-size: 10px; line-height: 1.5; margin: 8px 0 0; }
.ltl-help:focus-visible { outline: 2px solid #93e6d8; outline-offset: 2px; }


/* v0.3: tap-to-expand mobile strip and on-demand harmonic recommendations. */
.ltl.minimised { width: min(335px, calc(100vw - 32px)); overflow: hidden; }
.ltl-compact { display: block; width: 100%; padding: 10px 12px 11px; border: 0; cursor: pointer; text-align: left; background: linear-gradient(135deg, #1b2a2c, #141c22); color: var(--ink); font: inherit; -webkit-tap-highlight-color: transparent; }
.ltl-compact:hover { background: linear-gradient(135deg, #233638, #19252b); }
.ltl-mini-top { display: flex; align-items: center; gap: 6px; padding-bottom: 9px; width: 100%; }
.ltl-mini-brand { display: flex; align-items: center; gap: 5px; white-space: nowrap; font-weight: 800; font-size: 10px; letter-spacing: 1.45px; }
.ltl-mini-brand .ltl-mark { font-size: 16px; }
.ltl-mini-state { font-size: 9px; letter-spacing: .55px; font-weight: 650; margin-left: auto; color: #96b8b4; white-space: nowrap; }
.ltl-mini-chevron { color: #bcdbd4; font-size: 19px; line-height: .9; margin-left: 5px; }
.ltl-mini-metrics { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); width: 100%; gap: 6px; }
.ltl-mini-stat { display: flex; flex-direction: column; align-items: center; min-width: 0; padding: 6px 2px 5px; border: 1px solid #35474c; border-radius: 7px; background: #202c30; }
.ltl-mini-label { font-size: 8px; font-weight: 750; color: #a9b9bc; letter-spacing: .6px; }
.ltl-mini-stat strong { font-size: 20px; line-height: 1.25; font-weight: 790; font-variant-numeric: tabular-nums; }
.ltl-mini-energy { border-color: #695640; background: #302a23; }
.ltl-mini-energy strong { color: #f4be76; }
.ltl-compact:focus-visible { outline: 2px solid #93e6d8; outline-offset: -3px; }
.ltl-harmonic { border-top: 1px solid #2c373c; padding: 10px 0 11px; }
.ltl-harmonic-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
.ltl-harmonic-kicker { display: block; color: #82bdb1; font-weight: 800; font-size: 9px; letter-spacing: 1.4px; }
.ltl-harmonic-title { font-weight: 690; font-size: 13px; margin-top: 2px; }
.ltl-find-btn { padding: 8px 9px; border: 1px solid #47786e; border-radius: 7px; background: #25453f; color: #c5f2e7; font: 730 10px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; white-space: nowrap; cursor: pointer; }
.ltl-find-btn:disabled { opacity: .48; cursor: wait; }
.ltl-find-btn:hover:not(:disabled) { background: #366357; }
.ltl-harmonic-message { font-size: 10px; color: #92a7aa; line-height: 1.5; margin: 6px 0 0; }
.ltl-harmonic-debug { margin-top: 8px; color: #9db5b7; font-size: 10px; }
.ltl-harmonic-debug summary { cursor: pointer; color: #9ecdc4; font-weight: 680; }
.ltl-harmonic-debug p { margin: 5px 0 0; line-height: 1.55; }

.ltl-suggestions { display: grid; gap: 6px; margin-top: 10px; }
.ltl-suggestion-card { display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: center; gap: 7px; position: relative; min-width: 0; border-radius: 9px; border: 1px solid #344a4b; background: #1d2a2d; color: #eff9f4; padding: 9px 10px; text-decoration: none; }
.ltl-suggestion-card:hover { background: #294042; border-color: #66968b; }
.ltl-suggestion-text { display: flex; flex-direction: column; gap: 3px; min-width: 0; }
.ltl-suggestion-text strong { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 11px; }
.ltl-suggestion-text small { font-size: 10px; color: #9fb2b4; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ltl-suggestion-stats { display: flex; gap: 3px; flex-wrap: wrap; justify-content: flex-end; max-width: 155px; padding-right: 12px; }
.ltl-suggestion-stats span { border: 1px solid #3e5756; border-radius: 5px; padding: 3px 4px; font: 650 9px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; background: #243638; color: #c9e2db; }
.ltl-suggestion-stats span:first-child { color: #d4eee8; }
.ltl-suggestion-stats span:nth-child(3) { color: #f4be76; border-color: #695640; }
.ltl-suggestion-arrow { position: absolute; right: 8px; top: calc(50% - 7px); color: #86beaf; font-size: 13px; }
.ltl-find-btn:focus-visible, .ltl-suggestion-card:focus-visible { outline: 2px solid #93e6d8; outline-offset: 2px; }
@media (max-width: 600px) {
  .ltl { width: min(364px, calc(100vw - 32px)); max-height: min(72dvh, calc(100vh - 140px)); }
  .ltl.minimised { width: min(430px, calc(100vw - 32px)); }
  .ltl-expanded { padding-bottom: 14px; }
  .ltl-suggestion-card { grid-template-columns: minmax(0, 1fr); gap: 7px; }
  .ltl-suggestion-stats { max-width: unset; justify-content: flex-start; padding-right: 0; }
  .ltl-suggestion-arrow { right: 9px; top: 10px; }
}
@media (max-width: 355px) {
  .ltl-mini-metrics { gap: 3px; }
  .ltl-mini-stat strong { font-size: 18px; }
  .ltl-mini-brand { letter-spacing: .8px; }
}

/* v0.4: one-line mobile strip, repositionable with a separate drag handle. */
.ltl-mini-shell { display: flex; align-items: stretch; min-width: 0; background: linear-gradient(135deg, #1b2a2c, #141c22); }
.ltl-drag { display: none; flex: 0 0 27px; margin: 0; padding: 0; border: 0; border-right: 1px solid #35474c; background: transparent; color: #9bc2bb; font: 23px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif; cursor: grab; touch-action: none; user-select: none; -webkit-tap-highlight-color: transparent; }
.ltl-drag:active { cursor: grabbing; color: #dcf9f1; }
.ltl-compact { flex: 1 1 auto; min-width: 0; display: flex; align-items: center; justify-content: space-between; gap: 5px; padding: 7px 9px; background: transparent; }
.ltl-mini-mark { font-size: 17px; line-height: 1; color: #83d8c6; flex: 0 0 auto; }
.ltl-mini-stat { flex: 1 1 auto; min-width: 0; padding: 1px 2px; border: 0; border-radius: 0; background: transparent; gap: 1px; }
.ltl-mini-label { font-size: 8px; letter-spacing: .45px; color: #9fb5b5; }
.ltl-mini-stat strong { font-size: 18px; line-height: 1.1; }
.ltl-mini-energy { border: 0; background: transparent; }
.ltl-mini-chevron { flex: 0 0 auto; margin: 0; }
.ltl-drag:focus-visible { outline: 2px solid #93e6d8; outline-offset: -2px; }
@media (max-width: 600px) {
  .ltl { max-height: calc(100dvh - 24px); }
  .ltl.minimised { width: min(430px, calc(100vw - 32px)); }
  .ltl-drag { display: block; }
}
@media (max-width: 355px) {
  .ltl-compact { gap: 2px; padding-inline: 5px; }
  .ltl-mini-stat strong { font-size: 16px; }
  .ltl-mini-label { font-size: 7px; letter-spacing: .2px; }
  .ltl-drag { flex-basis: 24px; }
}

.ltl-mini-state { display:inline-block; flex:0 0 6px; width:6px; height:6px; border-radius:50%; overflow:hidden; font-size:0; line-height:0; padding:0; margin:0; background:#789699; }
.ltl-mini-state[data-kind="success"] { background:var(--sea); }
.ltl-mini-state[data-kind="warning"] { background:var(--gold); }
.ltl-mini-state[data-kind="error"] { background:#ff9292; }

/* v0.6.2: user-confirmed catalogue alternatives, never auto-labelled harmonic. */
.ltl-review { margin: 10px 0 7px; border: 1px solid #51614e; background: #1c292a; border-radius: 9px; padding: 8px; }
.ltl-review > summary { cursor: pointer; color: #b7dfca; font-weight: 750; font-size: 11px; }
.ltl-review-note { font-size: 10px; color: #b7c4c5; line-height: 1.45; margin: 7px 0; }
.ltl-review-card { padding: 9px 4px; border-top: 1px solid #39494c; display: grid; gap: 7px; }
.ltl-review-card strong { display: block; font-size: 11px; overflow-wrap: anywhere; }
.ltl-review-card small { font-size: 10px; color: #9aafb1; }
.ltl-review-controls { display: flex; gap: 5px; align-items: center; }
.ltl-review-controls select { flex: 1 1 auto; min-width: 0; color: #e4f4ec; background: #111c20; border: 1px solid #465d5a; border-radius: 5px; font: inherit; padding: 6px 4px; }
.ltl-review-controls button { flex: 0 0 auto; font-size: 10px; padding: 7px 6px; white-space: nowrap; }
.ltl-review-controls button:disabled { opacity: .45; cursor: wait; }
.ltl-review-error { color: #ffc0a7; font-size: 10px; margin: 0; }
.ltl-queue-diagnostic { border-top: 1px solid #374b4c; margin-top: 9px; padding-top: 9px; }
.ltl-queue-diagnostic strong { display:block; font-size: 10px; color: #c0e1d9; margin-bottom: 3px; }
.ltl-queue-diagnostic p { margin: 4px 0 7px; color: #a7b9ba; font-size: 10px; line-height: 1.55; }
.ltl-queue-diagnostic .ltl-small-btn { font-size: 10px; padding: 7px 9px; }
.ltl-queue-diagnostic-output { width: 100%; min-height: 88px; max-height: 180px; resize: vertical; margin-top: 7px; padding: 8px; background: #10181b; border: 1px solid #4d6664; border-radius: 6px; color: #e5f7f1; font: 10px/1.5 monospace; }
.ltl-queue-diagnostic-status { font-size: 10px; color: #a8dcca; }
/* v0.6.7: share-link fallback when Spotify omits its playing track ID. */
.ltl-spotify-link-helper { padding: 9px 0 2px; border-top: 1px solid #304047; margin-top: 7px; }
.ltl-spotify-link-helper p { margin: 0 0 8px; color: #acbec1; line-height: 1.5; }
.ltl-spotify-link-form { display: flex; gap: 7px; align-items: stretch; flex-wrap: wrap; }
.ltl-spotify-link-form input { flex: 1 1 160px; min-width: 0; padding: 9px; border-radius: 7px;
  border: 1px solid #54656b; background: #10181c; color: #f0f6f5; font: inherit; }
.ltl-spotify-link-form input:focus { outline: 2px solid #78cabb; outline-offset: 1px; }
.ltl-spotify-link-helper .ltl-small-btn { flex: 0 0 auto; }
.ltl-spotify-link-helper strong { color: #d2e5df; }
.ltl-recco-review { margin-top: 11px; padding: 10px; border: 1px solid #786147; border-radius: 9px; background: #252722; }
.ltl-recco-review summary { cursor: pointer; font-weight: 750; color: #e8c99b; }
.ltl-recco-review-note { font-size: 10px; color: #d5c9b6; line-height: 1.5; margin: 9px 0; }
.ltl-recco-card { padding: 9px 0; border-top: 1px solid #4d514d; display: flex; flex-wrap: wrap; gap: 5px 8px; align-items: center; }
.ltl-recco-info { flex: 1 1 170px; min-width: 0; }
.ltl-recco-info strong { display: block; font-size: 11px; overflow-wrap: anywhere; }
.ltl-recco-info small { display: block; color: #a8b7b9; font-size: 9px; margin-top: 4px; overflow-wrap: anywhere; }
.ltl-recco-confirm { flex: 0 0 auto; }
.ltl-recco-result { color: #dfbd8d; font-size: 10px; margin-top: 8px; }
.ltl-manual-editor { border-top: 1px solid #374b4c; margin: 9px 0 0; padding: 9px 0; }
.ltl-manual-editor summary { cursor: pointer; color: #9fe1d0; font-size: 11px; font-weight: 750; }
.ltl-manual-editor p { color: #a9bdc1; font-size: 10px; line-height: 1.5; }
.ltl-manual-grid { display: grid; grid-template-columns: repeat(2, minmax(0,1fr)); gap: 8px; margin: 9px 0; }
.ltl-manual-grid label, .ltl-manual-source { display: grid; gap: 4px; font-size: 10px; color: #bfdbd6; }
.ltl-manual-grid input, .ltl-manual-source input { box-sizing: border-box; width: 100%; min-width: 0; border-radius: 6px; background: #111b1f; color: #f0f9f4; border: 1px solid #50636a; padding: 9px; font: inherit; }
.ltl-manual-grid input:disabled { opacity: .55; }
.ltl-manual-buttons { display: flex; align-items: center; flex-wrap: wrap; gap: 8px; margin-top: 9px; }
.ltl-manual-message { font-size: 10px; color: #d6b98f; min-height: 14px; }



/* v0.7: compact, per-metric attribution and human-invoked identification reference. */
.ltl-metric-provenance { color: #9bb6b1; font-size: 9px; line-height: 1.5; padding: 2px 0 10px;
  display: flex; gap: 6px 11px; flex-wrap: wrap; }
.ltl-metric-provenance span { white-space: nowrap; }
.ltl-metric-provenance b { color: #d8e7e1; font-weight: 690; }
.ltl-metric-provenance span[data-source="manual"] b { color: #f4be76; }
.ltl-musicbrainz-link { display: inline-block; margin-top: 12px; font-size: 10px;
  color: #9bdccc; text-decoration: none; }
.ltl-musicbrainz-link:hover { text-decoration: underline; }
@media (max-width: 600px) { .ltl-metric-provenance { gap: 4px 9px; } }

/* v0.7.1: narrow review cards use stacked, accessible controls. */
.ltl-review-card { min-width: 0; }
.ltl-review-why { margin: 0; font-size: 10px; line-height: 1.48; color: #efd1a9; overflow-wrap: anywhere; }
.ltl-review-controls { display: grid; grid-template-columns: minmax(0, 1fr); align-items: stretch; gap: 7px; min-width: 0; }
.ltl-review-controls select { display: block; width: 100%; max-width: 100%; min-width: 0; padding: 9px 8px; white-space: nowrap; }
.ltl-review-controls button { width: 100%; min-height: 36px; white-space: normal; }
.ltl-review-choice-note { display: block; line-height: 1.45; overflow-wrap: anywhere; }
.ltl-review-more { margin-top: 8px; width: 100%; min-height: 36px; border-radius: 7px; border: 1px solid #506862; background: #213a36; color: #d2f5e8; cursor: pointer; font: 700 11px/1.4 system-ui, sans-serif; }
.ltl-review-more:hover { background: #2d5049; }
.ltl-review-more:focus-visible { outline: 2px solid #9ce5d5; outline-offset: 2px; }


/* v0.8.1: readable desktop text and two-way desktop positioning. */
.ltl-header { touch-action: none; user-select: none; }
.ltl-header, .ltl-identity { cursor: grab; }
.ltl-header:active, .ltl-identity:active { cursor: grabbing; }
.ltl-actions, .ltl-actions button { touch-action: auto; cursor: pointer; }
.ltl-identity:focus-visible { outline: 2px solid var(--sea); outline-offset: 3px; border-radius: 4px; }
.ltl-theme-btn { font-size: 18px; font-weight: 750; }
@media (min-width: 601px) {
  .ltl { width: min(430px, calc(100vw - 24px)); max-height: calc(100dvh - 24px); font-size: 14px; line-height: 1.47; }
  .ltl.minimised { width: min(370px, calc(100vw - 24px)); }
  .ltl-header { min-height: 51px; padding: 10px 14px; }
  .ltl-identity { font-size: 12px; gap: 8px; letter-spacing: 1.6px; }
  .ltl-mark { font-size: 22px; }
  .ltl-icon { height: 31px; width: 31px; font-size: 21px; }
  .ltl-help { padding: 7px 9px; font-size: 11px; }
  .ltl-expanded { padding: 16px 16px 13px; }
  .ltl-song-title { font-size: 18px; max-height: none; }
  .ltl-song-artist { font-size: 13px; }
  .ltl-status { font-size: 12px; padding-block: 3px 6px; }
  .ltl-metric-label { font-size: 10px; }
  .ltl-metric strong { font-size: 26px; }
  .ltl-scale { font-size: 10px; }
  .ltl-barline { font-size: 12px; grid-template-columns: 98px 1fr; }
  .ltl-keyinfo, .ltl-keyinfo span:last-child { font-size: 12px; }
  .ltl-metric-provenance { font-size: 11px; }
  .ltl-harmonic-title { font-size: 15px; }
  .ltl-harmonic-kicker, .ltl-source { font-size: 10px; }
  .ltl-find-btn, .ltl-link { font-size: 11px; }
  .ltl-harmonic-message, .ltl-harmonic-debug, .ltl-warning { font-size: 12px; }
  .ltl-suggestion-text strong { font-size: 13px; }
  .ltl-suggestion-text small { font-size: 12px; }
  .ltl-suggestion-stats { max-width: 166px; }
  .ltl-suggestion-stats span { font-size: 10px; }
  .ltl-match-note { font-size: 11px; }
  .ltl-picker-title, .ltl-review > summary, .ltl-manual-editor summary { font-size: 12px; }
  .ltl-picker label, .ltl-picker-hint, .ltl-review-note, .ltl-review-card small,
  .ltl-review-why, .ltl-review-choice-note, .ltl-recco-review-note,
  .ltl-manual-editor p, .ltl-manual-grid label, .ltl-manual-source,
  .ltl-queue-diagnostic p, .ltl-picker-tip { font-size: 12px; }
  .ltl-review-card strong, .ltl-recco-info strong { font-size: 13px; }
  .ltl-small-btn, .ltl-review-controls button, .ltl-review-more { font-size: 12px; }
  .ltl-drag { display: block; }
  .ltl-mini-stat strong { font-size: 20px; }
}

/* v0.8.1: explicitly designed light palette, not colour inversion. */
:host([data-theme="light"]) { color-scheme: light; }
.ltl[data-theme="light"] {
  --bg: #f8fbfb; --surface: #eaf1f2; --edge: #b7c9cc;
  --soft: #52676e; --ink: #183038; --sea: #16685e; --gold: #995a12;
  border-color: #9bb8bc; box-shadow: 0 18px 45px #20333d40, 0 4px 12px #20333d20;
  scrollbar-color: #a4b9bd transparent;
}
.ltl[data-theme="light"] .ltl-header { background: linear-gradient(120deg,#e9f4f0,#e5edef); }
.ltl[data-theme="light"] .ltl-identity, .ltl[data-theme="light"] .ltl-song-title { color: #162b32; }
.ltl[data-theme="light"] .ltl-icon { color: #47666a; }
.ltl[data-theme="light"] .ltl-icon:hover { color:#0e4c4a; background:#d3e5e1; border-color:#95b7b1; }
.ltl[data-theme="light"] .ltl-help { background:#d3eae3; color:#13594f; border-color:#92bfb5; }
.ltl[data-theme="light"] .ltl-help:hover { background:#bfdfd5; color:#0c4a42; }
.ltl[data-theme="light"] .ltl-song-artist,
.ltl[data-theme="light"] .ltl-status,
.ltl[data-theme="light"] .ltl-metric-label,
.ltl[data-theme="light"] .ltl-scale,
.ltl[data-theme="light"] .ltl-barline,
.ltl[data-theme="light"] .ltl-keyinfo span:last-child { color:#50666d; }
.ltl[data-theme="light"] .ltl-status[data-kind="error"] { color:#ab2d2d; }
.ltl[data-theme="light"] .ltl-status[data-kind="warning"] { color:#94570d; }
.ltl[data-theme="light"] .ltl-metric:nth-child(2) strong { color:#246c65; }
.ltl[data-theme="light"] .ltl-metric.ltl-spotlight { background:#fff2df; border-color:#d7b585; }
.ltl[data-theme="light"] .ltl-bartrack { background:#cddddd; }
.ltl[data-theme="light"] .ltl-keyinfo,
.ltl[data-theme="light"] .ltl-foot,
.ltl[data-theme="light"] .ltl-harmonic,
.ltl[data-theme="light"] .ltl-manual-editor { border-color:#bfd0d1; }
.ltl[data-theme="light"] .ltl-warning { color:#7a4210; background:#fff2e3; border-color:#d3a56f; }
.ltl[data-theme="light"] .ltl-harmonic-kicker,
.ltl[data-theme="light"] .ltl-source a,
.ltl[data-theme="light"] .ltl-link,
.ltl[data-theme="light"] .ltl-harmonic-debug summary,
.ltl[data-theme="light"] .ltl-musicbrainz-link { color:#176359; }
.ltl[data-theme="light"] .ltl-source { color:#556e72; }
.ltl[data-theme="light"] .ltl-link:hover,
.ltl[data-theme="light"] .ltl-source a:hover { color:#003f38; }
.ltl[data-theme="light"] .ltl-harmonic-message,
.ltl[data-theme="light"] .ltl-harmonic-debug,
.ltl[data-theme="light"] .ltl-match-note,
.ltl[data-theme="light"] .ltl-picker-tip { color:#53696d; }
.ltl[data-theme="light"] .ltl-find-btn,
.ltl[data-theme="light"] .ltl-small-btn { background:#d6eee6; border-color:#75ad9d; color:#145b50; }
.ltl[data-theme="light"] .ltl-find-btn:hover:not(:disabled),
.ltl[data-theme="light"] .ltl-small-btn:hover:not(:disabled) { background:#b9e0d2; }
.ltl[data-theme="light"] .ltl-suggestion-card { background:#eff7f5; border-color:#b1ccc5; color:#1a3339; }
.ltl[data-theme="light"] .ltl-suggestion-card:hover { background:#dcf0e9; border-color:#69a89b; }
.ltl[data-theme="light"] .ltl-suggestion-text small { color:#576e71; }
.ltl[data-theme="light"] .ltl-suggestion-stats span { background:#e4f0ec; border-color:#b6d0ca; color:#26554d; }
.ltl[data-theme="light"] .ltl-suggestion-stats span:first-child { color:#14554a; }
.ltl[data-theme="light"] .ltl-suggestion-stats span:nth-child(3) { color:#965915; border-color:#d8b98e; background:#fff2e3; }
.ltl[data-theme="light"] .ltl-suggestion-arrow { color:#317e70; }
.ltl[data-theme="light"] .ltl-picker,
.ltl[data-theme="light"] .ltl-review { background:#edf4f3; border-color:#b0c9c7; }
.ltl[data-theme="light"] .ltl-picker label,
.ltl[data-theme="light"] .ltl-picker-hint,
.ltl[data-theme="light"] .ltl-review-note,
.ltl[data-theme="light"] .ltl-review-card small,
.ltl[data-theme="light"] .ltl-recco-info small,
.ltl[data-theme="light"] .ltl-manual-editor p,
.ltl[data-theme="light"] .ltl-manual-grid label,
.ltl[data-theme="light"] .ltl-manual-source { color:#4b6269; }
.ltl[data-theme="light"] .ltl-picker-title,
.ltl[data-theme="light"] .ltl-review > summary,
.ltl[data-theme="light"] .ltl-manual-editor summary { color:#175e54; }
.ltl[data-theme="light"] .ltl-picker input,
.ltl[data-theme="light"] .ltl-picker select,
.ltl[data-theme="light"] .ltl-review-controls select,
.ltl[data-theme="light"] .ltl-manual-grid input,
.ltl[data-theme="light"] .ltl-manual-source input,
.ltl[data-theme="light"] .ltl-spotify-link-form input,
.ltl[data-theme="light"] .ltl-queue-diagnostic-output { background:#fff; border-color:#a7bfc1; color:#153039; }
.ltl[data-theme="light"] .ltl-review-card,
.ltl[data-theme="light"] .ltl-queue-diagnostic { border-color:#c1d3d3; }
.ltl[data-theme="light"] .ltl-review-why,
.ltl[data-theme="light"] .ltl-recco-review-note,
.ltl[data-theme="light"] .ltl-recco-result,
.ltl[data-theme="light"] .ltl-manual-message { color:#874d12; }
.ltl[data-theme="light"] .ltl-review-more { background:#d5eae2; border-color:#93bdb0; color:#15594d; }
.ltl[data-theme="light"] .ltl-review-more:hover { background:#c4e1d4; }
.ltl[data-theme="light"] .ltl-recco-review { background:#fff4e8; border-color:#d5b994; }
.ltl[data-theme="light"] .ltl-recco-review summary { color:#8a5015; }
.ltl[data-theme="light"] .ltl-metric-provenance,
.ltl[data-theme="light"] .ltl-queue-diagnostic p,
.ltl[data-theme="light"] .ltl-spotify-link-helper p { color:#536d70; }
.ltl[data-theme="light"] .ltl-metric-provenance b,
.ltl[data-theme="light"] .ltl-spotify-link-helper strong { color:#24454a; }
.ltl[data-theme="light"] .ltl-metric-provenance span[data-source="manual"] b { color:#985c17; }
.ltl[data-theme="light"] .ltl-mini-shell,
.ltl[data-theme="light"] .ltl-compact { background:#e8f2ef; color:#183038; }
.ltl[data-theme="light"] .ltl-compact:hover { background:#d5e8e2; }
.ltl[data-theme="light"] .ltl-mini-label,
.ltl[data-theme="light"] .ltl-mini-chevron { color:#4f686e; }
.ltl[data-theme="light"] .ltl-mini-energy strong { color:#995a12; }
.ltl[data-theme="light"] .ltl-drag { color:#235e57; border-color:#b8cfca; }
.ltl[data-theme="light"] .ltl-mini-state[data-kind="warning"] { background:#a9681e; }
.ltl[data-theme="light"] :is(button, a, input, select, summary):focus-visible { outline:2px solid #0b8273; }

/* v0.8.2: prevent incompatible tracks being mistaken for harmonic matches. */
.ltl-related { margin-top: 11px; border: 1px solid #665b45; border-radius: 9px; padding: 9px; background: #282b27; }
.ltl-related summary { cursor: pointer; color: #f0cb91; font-weight: 750; font-size: 12px; line-height: 1.4; }
.ltl-related-note { margin: 8px 0 9px; color: #d7bf9d; font-size: 11px; line-height: 1.5; }
.ltl-related .ltl-suggestion-card { background: #2e302d; border-color: #5d584a; }
.ltl-related .ltl-suggestion-card:hover { background: #3a3a31; border-color: #b7986d; }
.ltl-related .ltl-suggestion-stats span:first-child { color: #f0cb91; }
.ltl-scan-hint { margin: 9px 0 0; color: #acbec0; font-size: 11px; line-height: 1.45; }
.ltl-retry-btn, .ltl-restore-reviews { display: block; margin-top: 7px; padding: 8px 11px; width: 100%; border: 1px solid #456f67; border-radius: 7px; color: #d1f3e7; background: #263d3a; cursor: pointer; font: 700 11px/1.3 system-ui, sans-serif; }
.ltl-retry-btn:disabled { cursor: wait; opacity: .55; }
.ltl-retry-btn:hover:not(:disabled), .ltl-restore-reviews:hover { background: #305950; }
.ltl-review-dismiss { background: transparent; border: 1px solid #718184; color: #d4dfe0; border-radius: 7px; min-height: 32px; padding: 5px 9px; cursor: pointer; font: 700 11px/1.25 system-ui, sans-serif; }
.ltl-review-dismiss:hover { background: #34454a; }
.ltl-review-dismiss:disabled { opacity: .5; }
.ltl-review-dismiss-note { color: #a3b6b8; font-size: 10px; }
.ltl[data-theme="light"] .ltl-related { border-color: #dbc29d; background: #fff8ee; }
.ltl[data-theme="light"] .ltl-related summary { color: #825018; }
.ltl[data-theme="light"] .ltl-related-note { color: #815b32; }
.ltl[data-theme="light"] .ltl-related .ltl-suggestion-card { background: #fffdf9; border-color: #e2c8a5; }
.ltl[data-theme="light"] .ltl-related .ltl-suggestion-card:hover { background: #faeddb; border-color: #c79b61; }
.ltl[data-theme="light"] .ltl-related .ltl-suggestion-stats span:first-child { color: #975b14; }
.ltl[data-theme="light"] .ltl-scan-hint { color: #546d71; }
.ltl[data-theme="light"] .ltl-retry-btn, .ltl[data-theme="light"] .ltl-restore-reviews { color: #13564c; background: #e6f2ed; border-color: #97c5b8; }
.ltl[data-theme="light"] .ltl-retry-btn:hover:not(:disabled), .ltl[data-theme="light"] .ltl-restore-reviews:hover { background: #d7eae0; }
.ltl[data-theme="light"] .ltl-review-dismiss { color: #31545b; border-color: #a0b6b7; }
.ltl[data-theme="light"] .ltl-review-dismiss:hover { background: #e3eeee; }
.ltl[data-theme="light"] .ltl-review-dismiss-note { color: #597174; }
@media(min-width:601px) {
  .ltl-related summary, .ltl-scan-hint { font-size: 12px; }
  .ltl-retry-btn, .ltl-restore-reviews, .ltl-review-dismiss { font-size: 12px; }
}

`);
  shadow.adoptedStyleSheets = [panelStyles];

  const root = document.createElement('section');
  root.className = 'ltl';
  root.setAttribute('aria-label', 'Track Lens');
  root.innerHTML = `
    <header class="ltl-header" id="ltl-header">
      <div class="ltl-identity" id="ltl-desktop-grip" role="button" tabindex="0" aria-label="Move Track Lens on desktop. Use arrow keys or drag the header." title="Drag the header to move Track Lens"><span class="ltl-mark">◈</span><span>TRACK LENS</span></div>
      <div class="ltl-actions">
        <button type="button" class="ltl-icon ltl-theme-btn" id="ltl-theme" title="Switch to light theme" aria-label="Switch to light theme">☀</button>
        <button type="button" class="ltl-help" id="ltl-help" title="How to use Track Lens and settings" aria-label="Help and settings">HELP</button>
        <button type="button" class="ltl-icon" id="ltl-refresh" title="Refresh track analysis" aria-label="Refresh">↻</button>
        <button type="button" class="ltl-icon" id="ltl-toggle" title="Minimise" aria-label="Minimise">−</button>
      </div>
    </header>
    <div class="ltl-expanded" id="ltl-expanded">
      <div class="ltl-song">
        <div id="ltl-song-title" class="ltl-song-title">Nothing playing yet</div>
        <div id="ltl-song-artist" class="ltl-song-artist">Play a track to begin.</div>
      </div>
      <div id="ltl-status" class="ltl-status" role="status" aria-live="polite">Waiting for a track</div>
      <div class="ltl-metrics">
        <div class="ltl-metric"><span class="ltl-metric-label">BPM</span><strong id="ltl-bpm">—</strong></div>
        <div class="ltl-metric"><span class="ltl-metric-label">CAMELOT</span><strong id="ltl-camelot">—</strong></div>
        <div class="ltl-metric ltl-spotlight"><span class="ltl-metric-label">ENERGY</span><strong id="ltl-energy">—</strong><span class="ltl-scale">/100</span></div>
        <div class="ltl-metric"><span class="ltl-metric-label">DANCEABILITY</span><strong id="ltl-dance">—</strong><span class="ltl-scale">/100</span></div>
      </div>
      <div class="ltl-bars">
        <div class="ltl-barline"><span>Energy</span><div class="ltl-bartrack"><div class="ltl-fill ltl-energy-fill" id="ltl-energy-bar"></div></div></div>
        <div class="ltl-barline"><span>Danceability</span><div class="ltl-bartrack"><div class="ltl-fill ltl-dance-fill" id="ltl-dance-bar"></div></div></div>
      </div>
      <div id="ltl-metric-provenance" class="ltl-metric-provenance" role="note" aria-label="Source of each metric" hidden></div>
      <div class="ltl-keyinfo"><span id="ltl-key">Key unavailable</span><span id="ltl-compatible"></span></div>
      <div id="ltl-tempo-warning" class="ltl-warning" hidden></div>
      <section class="ltl-harmonic" aria-label="Harmonic track suggestions">
        <div class="ltl-harmonic-head">
          <div><span class="ltl-harmonic-kicker">MIX NEXT</span><div class="ltl-harmonic-title">Harmonic suggestions</div></div>
          <button type="button" class="ltl-find-btn" id="ltl-find-tracks" disabled>FIND TRACKS ↗</button>
        </div>
        <p class="ltl-harmonic-message" id="ltl-harmonic-message" role="status" aria-live="polite">Analyse a track to discover harmonically compatible songs.</p>
        <div class="ltl-suggestions" id="ltl-suggestions" aria-label="Verified harmonic matches" hidden></div>
        <details class="ltl-related" id="ltl-related" hidden>
          <summary id="ltl-related-summary">Related tracks (other keys) - not harmonic matches</summary>
          <p class="ltl-related-note">Suggested by the music player, but these keys are NOT harmonically compatible with the current track. Audition them independently.</p>
          <div class="ltl-suggestions" id="ltl-related-list"></div>
        </details>
        <p class="ltl-scan-hint" id="ltl-scan-hint" hidden></p>
        <button type="button" class="ltl-retry-btn" id="ltl-retry-failed" hidden>RETRY FAILED LOOKUPS</button>
        <details class="ltl-review" id="ltl-review" hidden>
          <summary id="ltl-review-summary">Review uncertain catalogue matches</summary>
          <p class="ltl-review-note">Not yet harmonic suggestions. Each recording explains why it needs confirmation. Choose the exact mix before checking its key; similarity scores measure metadata, not mixing quality.</p>
          <div id="ltl-review-list"></div>
          <button type="button" class="ltl-restore-reviews" id="ltl-restore-reviews" hidden>Restore dismissed reviews</button>
        </details>
        <details class="ltl-harmonic-debug" id="ltl-harmonic-debug" hidden>
          <summary>Search details</summary><p id="ltl-harmonic-debug-text"></p>
          <div class="ltl-queue-diagnostic" id="ltl-queue-diagnostic" hidden>
            <strong>Advanced: Spotify Queue diagnostic</strong>
            <p>With Spotify's Queue open, copy a structural report to help diagnose rejected rows. No song names, artist names, account details or URLs are included. Nothing is sent automatically.</p>
            <button type="button" class="ltl-small-btn" id="ltl-copy-queue-report">COPY QUEUE REPORT</button>
            <p class="ltl-queue-diagnostic-status" id="ltl-queue-report-status" role="status" aria-live="polite"></p>
            <textarea class="ltl-queue-diagnostic-output" id="ltl-queue-report-fallback" readonly hidden aria-label="Queue diagnostics, select all and copy"></textarea>
          </div>
        </details>
      </section>
      <div class="ltl-foot">
        <span class="ltl-source">DATA <a id="ltl-source-songfinder" href="https://songfinder.dev/" target="_blank" rel="noopener noreferrer">SONG FINDER ↗</a><span id="ltl-source-join" hidden> + </span><a id="ltl-source-recco" href="https://reccobeats.com/" target="_blank" rel="noopener noreferrer" hidden>RECCOBEATS ↗</a><span id="ltl-source-manual" hidden> + MANUAL</span></span>
        <button id="ltl-match" type="button" class="ltl-link" aria-expanded="false">CHANGE MATCH</button>
      </div>
      <div id="ltl-match-panel" class="ltl-picker" hidden>
        <div class="ltl-picker-title">FIND THE RIGHT RECORDING</div>
        <p id="ltl-picker-hint" class="ltl-picker-hint">Track Lens searches automatically. If you need another version, search by artist and exact mix title below.</p>
        <label for="ltl-choice">Catalogue results</label>
        <select id="ltl-choice"><option value="">No results yet</option></select>
        <button class="ltl-small-btn" id="ltl-use-match" type="button">Use selected track</button>
        <label for="ltl-query" class="ltl-search-label">Search catalogue</label>
        <form id="ltl-search-form" class="ltl-search">
          <input id="ltl-query" type="search" maxlength="240" placeholder="Artist + title + mix" aria-label="Search the Song Finder catalogue" />
          <button type="submit" class="ltl-small-btn">Search</button>
        </form>
        <p class="ltl-picker-tip">Tip: include Original Mix, Extended Mix or the remixer’s name. Then select a result above.</p>
        <a id="ltl-musicbrainz-link" class="ltl-musicbrainz-link" href="https://musicbrainz.org/search?type=recording" target="_blank" rel="noopener noreferrer">Check recording metadata on MusicBrainz ↗</a>
      </div>
      <div id="ltl-match-note" class="ltl-match-note" title="Matched catalogue recording">No catalogue match yet</div>
      <details class="ltl-harmonic-debug" id="ltl-fallback-debug" hidden>
        <summary>Analysis fallback details</summary><p id="ltl-fallback-debug-text"></p>
        <div id="ltl-spotify-link-helper" class="ltl-spotify-link-helper" hidden>
          <p>Spotify isn't exposing this song's track ID. In Spotify, choose <strong>Share → Copy link to song</strong>, then paste it here to retry ReccoBeats directly.</p>
          <form id="ltl-spotify-link-form" class="ltl-spotify-link-form">
            <input type="text" id="ltl-spotify-link" inputmode="url" autocomplete="off" spellcheck="false" placeholder="Spotify track link or spotify:track:ID" aria-label="Spotify track link" />
            <button type="submit" class="ltl-small-btn">CHECK TRACK</button>
          </form>
          <p id="ltl-spotify-link-message" class="ltl-picker-tip" role="status" aria-live="polite"></p>
        </div>
        <details class="ltl-recco-review" id="ltl-recco-review" hidden>
          <summary id="ltl-recco-review-summary">Review alternate ReccoBeats recordings</summary>
          <p class="ltl-recco-review-note">These recordings resemble the playing song, but their ISRCs differ from Song Finder. Compare titles, artists, mix versions and duration before choosing. Track Lens won't merge features across these recordings automatically.</p>
          <div id="ltl-recco-candidates"></div>
          <p id="ltl-recco-result" class="ltl-recco-result" role="status" aria-live="polite"></p>
        </details>
      </details>
      <details id="ltl-manual-editor" class="ltl-manual-editor" hidden>
        <summary id="ltl-manual-summary">Fill missing metrics manually</summary>
        <p>If Song Finder and ReccoBeats cannot analyse the exact recording, enter values you have independently checked. These remain labelled as manual, not provider measurements.</p>
        <form id="ltl-manual-form">
          <div class="ltl-manual-grid">
            <label>BPM <input id="ltl-manual-bpm" type="number" min="40" max="250" step="0.1" placeholder="e.g. 140" /></label>
            <label>Camelot <input id="ltl-manual-camelot" maxlength="3" autocapitalize="characters" placeholder="e.g. 3B" /></label>
            <label>Energy /100 <input id="ltl-manual-energy" type="number" min="0" max="100" step="1" placeholder="0–100" /></label>
            <label>Danceability /100 <input id="ltl-manual-dance" type="number" min="0" max="100" step="1" placeholder="0–100" /></label>
          </div>
          <label class="ltl-manual-source">Reference used (optional)<input id="ltl-manual-reference" type="text" maxlength="80" placeholder="e.g. Mixgraph or manual analysis" /></label>
          <div class="ltl-manual-buttons">
            <button type="submit" id="ltl-save-manual" class="ltl-small-btn">SAVE MISSING VALUES</button>
            <button type="button" id="ltl-clear-manual" class="ltl-small-btn" hidden>CLEAR MANUAL VALUES</button>
          </div>
          <p id="ltl-manual-message" class="ltl-manual-message" role="status" aria-live="polite"></p>
        </form>
      </details>
    </div>
    <div id="ltl-mini-shell" class="ltl-mini-shell" hidden>
      <button type="button" id="ltl-drag" class="ltl-drag" title="Drag to move Track Lens" aria-label="Move Track Lens up or down; use arrow keys or drag">⠿</button>
      <button type="button" id="ltl-compact" class="ltl-compact" aria-label="Expand Track Lens" aria-expanded="false">
        <span class="ltl-mini-mark" aria-hidden="true">◈</span>
        <span class="ltl-mini-state" id="ltl-mini-state" title="Waiting for a track" aria-live="polite">WAITING</span>
        <span class="ltl-mini-stat"><span class="ltl-mini-label">BPM</span><strong id="ltl-mini-bpm">—</strong></span>
        <span class="ltl-mini-stat"><span class="ltl-mini-label">KEY</span><strong id="ltl-mini-camelot">—</strong></span>
        <span class="ltl-mini-stat ltl-mini-energy"><span class="ltl-mini-label">ENERGY</span><strong id="ltl-mini-energy">—</strong></span>
        <span class="ltl-mini-stat"><span class="ltl-mini-label">DANCE</span><strong id="ltl-mini-dance">—</strong></span>
        <span class="ltl-mini-chevron" aria-hidden="true">⌃</span>
      </button>
    </div>
  `;
  shadow.append(root);
  (document.body || document.documentElement).append(host);

  const $ = (id) => shadow.getElementById(id);
  let activeTrack = null;
  let manualSpotifyId = '';
  let signature = '';
  let requestNumber = 0;
  let lastResult = null;
  let candidates = [];
  let mini = window.matchMedia('(max-width: 600px)').matches;
  let pickerOpen = false;
  let activeIsrc = null;
  let currentCamelot = '';
  let suggestionsRequest = 0;
  let suggestionsLoaded = false;
  let suggestionPool = [];
  let suggestionCursor = 0;
  let suggestionMatches = [];
  let suggestionNearMatches = [];
  let suggestionReviews = [];
  let reviewVisibleCount = 5;
  const REVIEW_PAGE_SIZE = 5;
  let suggestionSeen = new Set();
  const failedCandidates = new Map();
  let failedRetryOffset = 0;
  let dismissedReviewsBySeed = {};
  const DISMISSED_REVIEWS_KEY = 'track-lens-dismissed-reviews-v1';
  let suggestionStats = null;
  let suggestionBusy = false;
  let seedFeatures = null;
  let scannedBatches = 0;
  const DISCOVERY_BATCH_SIZE = 8;
  let autoOpenPicker = true;
  let showAdvancedDiagnostics = false;
  let relatedShowState = '';
  const DIAGNOSTICS_KEY = 'track-lens-advanced-diagnostics';
  const PICKER_KEY = 'track-lens-auto-open-matching';
  let barObserver = null;
  let observedBar = null;
  let debounce = null;
  let missingReads = 0;
  const DOCK_KEY = 'track-lens-mobile-position-v1';
  const DESKTOP_KEY = 'track-lens-desktop-position-v1';
  const THEME_KEY = 'track-lens-theme-v1';
  let desktopPosition = null; // null maintains the original desktop location on first install.
  let theme = 'dark';
  const mobileQuery = window.matchMedia('(max-width: 600px)');
  let dockRatio = 0.23; // Upper portion of the player, away from transport controls.
  let dragging = null;
  const isMobile = () => mobileQuery.matches;
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

  function compactTravel() {
    return Math.max(0, window.innerHeight - root.getBoundingClientRect().height - 24);
  }

  function desktopTravel() {
    const rect = root.getBoundingClientRect();
    return {
      x: Math.max(0, window.innerWidth - rect.width - 24),
      y: Math.max(0, window.innerHeight - rect.height - 24)
    };
  }

  function placePanel() {
    if (!isMobile()) {
      if (desktopPosition) {
        const travel = desktopTravel();
        host.style.right = 'auto'; host.style.bottom = 'auto';
        host.style.left = `${Math.round(12 + desktopPosition.x * travel.x)}px`;
        host.style.top = `${Math.round(12 + desktopPosition.y * travel.y)}px`;
      } else {
        host.style.left = 'auto'; host.style.right = '16px';
        host.style.top = 'auto'; host.style.bottom = 'calc(90px + env(safe-area-inset-bottom, 0px))';
      }
      return;
    }
    host.style.left = '16px'; host.style.right = 'auto'; host.style.bottom = 'auto';
    // A full-height panel needs room to scroll; only the mobile mini strip moves.
    const offset = mini ? 12 + dockRatio * compactTravel() : 12;
    host.style.top = `${Math.round(offset)}px`;
  }

  function positionFromDrag(top) {
    const travel = compactTravel();
    const offset = clamp(top, 12, 12 + travel);
    host.style.top = `${Math.round(offset)}px`;
    dockRatio = travel ? (offset - 12) / travel : 0;
  }

  function positionDesktop(left, top) {
    const travel = desktopTravel();
    const x = clamp(left, 12, 12 + travel.x);
    const y = clamp(top, 12, 12 + travel.y);
    host.style.left = `${Math.round(x)}px`; host.style.top = `${Math.round(y)}px`;
    host.style.right = 'auto'; host.style.bottom = 'auto';
    desktopPosition = {x: travel.x ? (x-12)/travel.x : 0, y: travel.y ? (y-12)/travel.y : 0};
  }

  function savePosition() {
    const key = isMobile() ? DOCK_KEY : DESKTOP_KEY;
    chrome.storage.local.set({ [key]: isMobile() ? dockRatio : desktopPosition }).catch(() => {});
  }

  function applyTheme(value) {
    theme = value === 'light' ? 'light' : 'dark';
    root.dataset.theme = theme;
    host.dataset.theme = theme;
    const button = $('ltl-theme');
    button.textContent = theme === 'light' ? '☾' : '☀';
    const label = `Switch to ${theme === 'light' ? 'dark' : 'light'} theme`;
    button.title = label;
    button.setAttribute('aria-label', label);
  }

  function beginDesktopDrag(handle, event) {
    if (isMobile() || (event.pointerType === 'mouse' && event.button !== 0)) return;
    if (handle.id === 'ltl-header' && event.target.closest('.ltl-actions')) return;
    event.preventDefault();
    const rect = host.getBoundingClientRect();
    dragging = { kind: 'desktop', id: event.pointerId, startX: event.clientX,
      startY: event.clientY, startLeft: rect.left, startTop: rect.top };
    handle.setPointerCapture(event.pointerId);
  }
  function moveDrag(event) {
    if (!dragging || event.pointerId !== dragging.id) return;
    if (dragging.kind === 'desktop') {
      positionDesktop(dragging.startLeft + event.clientX - dragging.startX,
        dragging.startTop + event.clientY - dragging.startY);
    } else {
      positionFromDrag(dragging.startTop + event.clientY - dragging.startY);
    }
  }
  function finishDrag(event) {
    if (!dragging || event.pointerId !== dragging.id) return;
    dragging = null;
    savePosition();
  }
  function desktopArrowMove(event) {
    if (isMobile() || !['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    const rect = host.getBoundingClientRect();
    const step = event.shiftKey ? 48 : 20;
    const dx = event.key === 'ArrowRight' ? step : event.key === 'ArrowLeft' ? -step : 0;
    const dy = event.key === 'ArrowDown' ? step : event.key === 'ArrowUp' ? -step : 0;
    positionDesktop(rect.left + dx, rect.top + dy);
    savePosition();
  }

  const desktopHandle = $('ltl-header');
  desktopHandle.addEventListener('pointerdown', event => beginDesktopDrag(desktopHandle, event));
  desktopHandle.addEventListener('pointermove', moveDrag);
  desktopHandle.addEventListener('pointerup', finishDrag);
  desktopHandle.addEventListener('pointercancel', finishDrag);
  $('ltl-desktop-grip').addEventListener('keydown', desktopArrowMove);

  const grip = $('ltl-drag');
  grip.addEventListener('pointerdown', event => {
    if (!mini || (event.pointerType === 'mouse' && event.button !== 0)) return;
    if (!isMobile()) { beginDesktopDrag(grip, event); return; }
    event.preventDefault();
    dragging = { kind: 'mobile', id: event.pointerId, startY: event.clientY,
      startTop: Number.parseFloat(host.style.top) || 12 };
    grip.setPointerCapture(event.pointerId);
  });
  grip.addEventListener('pointermove', moveDrag);
  grip.addEventListener('pointerup', finishDrag);
  grip.addEventListener('pointercancel', finishDrag);
  grip.addEventListener('keydown', event => {
    if (!mini || !['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    if (isMobile()) {
      if (!['ArrowUp','ArrowDown'].includes(event.key)) return;
      event.preventDefault();
      positionFromDrag((Number.parseFloat(host.style.top) || 12) + (event.key === 'ArrowDown' ? 20 : -20));
      savePosition();
    } else desktopArrowMove(event);
  });
  window.addEventListener('resize', () => requestAnimationFrame(placePanel));
  // Panel height changes after catalogues/review sections expand.
  if (typeof ResizeObserver !== 'undefined') {
    new ResizeObserver(() => {
      if (!dragging && desktopPosition && !isMobile()) requestAnimationFrame(placePanel);
    }).observe(root);
  }

  applyTheme('dark');
  setMini(mini);
  chrome.storage.local.get(['listener-track-lens-mini', PICKER_KEY, DOCK_KEY, DIAGNOSTICS_KEY, DESKTOP_KEY, THEME_KEY, DISMISSED_REVIEWS_KEY]).then(data => {
    if (data[DISMISSED_REVIEWS_KEY] && typeof data[DISMISSED_REVIEWS_KEY] === 'object' && !Array.isArray(data[DISMISSED_REVIEWS_KEY])) {
      dismissedReviewsBySeed = data[DISMISSED_REVIEWS_KEY];
      renderReview();
    }
    applyTheme(data[THEME_KEY]);
    if (data[DESKTOP_KEY] && typeof data[DESKTOP_KEY] === 'object' &&
        Number.isFinite(data[DESKTOP_KEY].x) && Number.isFinite(data[DESKTOP_KEY].y)) {
      desktopPosition = {x:clamp(data[DESKTOP_KEY].x,0,1), y:clamp(data[DESKTOP_KEY].y,0,1)};
    }
    if (typeof data[DOCK_KEY] === 'number' && Number.isFinite(data[DOCK_KEY])) {
      dockRatio = clamp(data[DOCK_KEY], 0, 1);
    }
    mini = typeof data['listener-track-lens-mini'] === 'boolean'
      ? data['listener-track-lens-mini'] : window.matchMedia('(max-width: 600px)').matches;
    autoOpenPicker = data[PICKER_KEY] !== false;
    showAdvancedDiagnostics = data[DIAGNOSTICS_KEY] === true;
    $('ltl-queue-diagnostic').hidden = !(adapter.id === 'spotify' && showAdvancedDiagnostics);
    setMini(mini);
    requestAnimationFrame(placePanel);
  }).catch(() => {});

  // Apply preferences changed in the options tab without requiring a reload.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes['listener-track-lens-mini']) {
      mini = Boolean(changes['listener-track-lens-mini'].newValue);
      setMini(mini);
    }
    if (changes[THEME_KEY]) applyTheme(changes[THEME_KEY].newValue);
    if (changes[DESKTOP_KEY]) {
      const value = changes[DESKTOP_KEY].newValue;
      desktopPosition = value && Number.isFinite(value.x) && Number.isFinite(value.y)
        ? {x:clamp(value.x,0,1), y:clamp(value.y,0,1)} : null;
      requestAnimationFrame(placePanel);
    }
    if (changes[PICKER_KEY]) {
      autoOpenPicker = changes[PICKER_KEY].newValue !== false;
    }
    if (changes[DIAGNOSTICS_KEY]) {
      showAdvancedDiagnostics = changes[DIAGNOSTICS_KEY].newValue === true;
      $('ltl-queue-diagnostic').hidden = !(adapter.id === 'spotify' && showAdvancedDiagnostics);
    }
  });

  function toggleMini() {
    mini = !mini;
    setMini(mini);
    chrome.storage.local.set({ 'listener-track-lens-mini': mini }).catch(() => {});
  }
  $('ltl-toggle').addEventListener('click', toggleMini);
  $('ltl-theme').addEventListener('click', () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    chrome.storage.local.set({[THEME_KEY]: next}).catch(() => {});
  });
  $('ltl-compact').addEventListener('click', toggleMini);
  $('ltl-refresh').addEventListener('click', () => {
    if (activeTrack) requestTrack('LOOKUP_TRACK', { refresh: true });
  });
  $('ltl-match').addEventListener('click', () => setPicker(!pickerOpen));
  $('ltl-find-tracks').addEventListener('click', () => findSuggestions(false));
  $('ltl-retry-failed').addEventListener('click', () => findSuggestions(true));
  $('ltl-restore-reviews').addEventListener('click', () => {
    if (!activeIsrc) return;
    delete dismissedReviewsBySeed[activeIsrc];
    chrome.storage.local.set({[DISMISSED_REVIEWS_KEY]: dismissedReviewsBySeed}).catch(() => {});
    renderReview();
  });
  if (adapter.id === 'spotify' && typeof adapter.diagnoseQueue === 'function') {
    $('ltl-queue-diagnostic').hidden = !(adapter.id === 'spotify' && showAdvancedDiagnostics);
    $('ltl-harmonic-debug').hidden = false;
    $('ltl-copy-queue-report').addEventListener('click', async () => {
      const statusNode = $('ltl-queue-report-status');
      const fallback = $('ltl-queue-report-fallback');
      let report;
      try {
        report = JSON.stringify(adapter.diagnoseQueue(document), null, 2);
      } catch (error) {
        statusNode.textContent = 'Could not inspect this Queue. Refresh Spotify and try again.';
        return;
      }
      // Prefer synchronous copying while the user gesture is active. Chromium
      // on some Android builds may lack navigator.clipboard in page scripts.
      let copied = false;
      fallback.value = report;
      fallback.hidden = false;
      fallback.focus();
      fallback.select();
      try { copied = document.execCommand('copy'); } catch { /* fall through */ }
      if (!copied && navigator.clipboard?.writeText) {
        try { await navigator.clipboard.writeText(report); copied = true; } catch { /* user can copy manually */ }
      }
      if (copied) {
        fallback.hidden = true;
        statusNode.textContent = `Copied structural report (${report.length.toLocaleString()} characters). Paste it into our chat. No account or track details included.`;
      } else {
        fallback.hidden = false;
        fallback.focus(); fallback.select();
        statusNode.textContent = 'Automatic copy was blocked. Select all the report text below and copy it manually.';
      }
    });
  }
  $('ltl-help').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'OPEN_OPTIONS' }, reply => {
      if (chrome.runtime.lastError || !reply?.ok) {
        status('Could not open Help. Open Track Lens Options from vivaldi://extensions.', 'error');
      }
    });
  });
  $('ltl-use-match').addEventListener('click', () => {
    const isrc = $('ltl-choice').value;
    if (isrc && activeTrack) requestTrack('SELECT_MATCH', { isrc });
  });
  $('ltl-manual-form').addEventListener('submit', event => {
    event.preventDefault();
    if (!activeTrack) return;
    const inputs = {
      tempo: $('ltl-manual-bpm').value,
      camelot: $('ltl-manual-camelot').value,
      energy: $('ltl-manual-energy').value,
      danceability: $('ltl-manual-dance').value
    };
    if (!Object.values(inputs).some(v => String(v).trim())) {
      $('ltl-manual-message').textContent = 'Enter at least one missing metric.';
      return;
    }
    $('ltl-manual-message').textContent = 'Saving your values…';
    requestTrack('SAVE_MANUAL_FEATURES', {manualFeatures: inputs, manualSource: $('ltl-manual-reference').value});
  });
  $('ltl-clear-manual').addEventListener('click', () => {
    if (activeTrack) requestTrack('CLEAR_MANUAL_FEATURES', {});
  });

  $('ltl-recco-candidates').addEventListener('click', event => {
    const button = event.target.closest('button[data-recco-id]');
    if (!button || !activeTrack) return;
    const chosen = (lastResult?.fallbackAlternatives || []).find(row => row.id === button.dataset.reccoId);
    if (!chosen) return;
    $('ltl-recco-result').textContent = `Checking ${chosen.title} by ${chosen.artist}…`;
    requestTrack('SELECT_RECCO_FALLBACK', { candidateId: chosen.id });
  });
  $('ltl-spotify-link-form').addEventListener('submit', event => {
    event.preventDefault();
    if (!activeTrack || adapter.id !== 'spotify') return;
    const id = parseSpotifyTrackId($('ltl-spotify-link').value);
    const message = $('ltl-spotify-link-message');
    if (!id) {
      message.textContent = 'Paste the full Spotify song link, Spotify track URI, or a 22-character track ID.';
      return;
    }
    message.textContent = 'Checking this exact Spotify recording with ReccoBeats…';
    manualSpotifyId = id;
    requestTrack('RETRY_FALLBACK', { trackId: id });
  });
  $('ltl-search-form').addEventListener('submit', event => {
    event.preventDefault();
    const query = $('ltl-query').value.trim();
    if (query && activeTrack) requestTrack('SEARCH_MATCH', { query });
  });

  function setMini(value) {
    root.classList.toggle('minimised', value);
    $('ltl-header').hidden = value;
    $('ltl-expanded').hidden = value;
    $('ltl-mini-shell').hidden = !value;
    $('ltl-compact').setAttribute('aria-expanded', String(!value));
    requestAnimationFrame(placePanel);
    $('ltl-toggle').textContent = value ? '+' : '−';
    $('ltl-toggle').title = value ? 'Expand' : 'Minimise';
    $('ltl-toggle').setAttribute('aria-label', value ? 'Expand' : 'Minimise');
  }

  function setPicker(open) {
    pickerOpen = open;
    $('ltl-match-panel').hidden = !open;
    $('ltl-match').setAttribute('aria-expanded', String(open));
    $('ltl-match').textContent = open ? 'CLOSE MATCH' : 'CHANGE MATCH';
    if (open) updateCandidates();
  }

  function readPlayer() {
    return adapter.readTrack(document);
  }

  function refreshPlayerBarObserver() {
    const bar = document.querySelector(adapter.playerSelector);
    if (bar === observedBar) return;
    barObserver?.disconnect();
    observedBar = bar;
    if (!bar) return;
    barObserver = new MutationObserver(() => {
      clearTimeout(debounce);
      debounce = setTimeout(checkCurrentTrack, 220);
    });
    barObserver.observe(bar, { childList: true, characterData: true, subtree: true });
  }

  function parseSpotifyTrackId(input) {
    const value = String(input || '').trim();
    if (/^[A-Za-z0-9]{22}$/.test(value)) return value;
    const uri = /^spotify:track:([A-Za-z0-9]{22})$/.exec(value);
    if (uri) return uri[1];
    try {
      const url = new URL(value);
      if (url.hostname !== 'open.spotify.com') return null;
      return /^\/track\/([A-Za-z0-9]{22})(?:\/|$)/.exec(url.pathname)?.[1] || null;
    } catch { return null; }
  }

  function checkCurrentTrack() {
    refreshPlayerBarObserver();
    const data = readPlayer();
    if (!data) {
      // A player can unmount while navigating. Wait for three checks to avoid
      // briefly clearing analysis during normal track transitions.
      if (++missingReads >= 3 && activeTrack) {
        signature = '';
        manualSpotifyId = '';
        activeTrack = null;
        ++requestNumber;
        activeIsrc = null;
        currentCamelot = '';
        seedFeatures = null;
        resetSuggestions();
        resetAnalysis();
        $('ltl-song-title').textContent = 'Nothing playing yet';
        $('ltl-song-artist').textContent = `Open ${adapter.label} and play a track.`;
        $('ltl-match-note').textContent = 'Waiting for track metadata';
        status('Waiting for a track');
      }
      return;
    }
    missingReads = 0;
    // Include provider track ID for same-title remixes when the page exposes it.
    const next = `${data.rawTitle}\u0001${data.rawArtist}\u0001${data.trackId || ''}`;
    if (next === signature) return;
    signature = next;
    manualSpotifyId = '';
    activeTrack = data;
    $('ltl-song-title').textContent = data.title;
    $('ltl-song-artist').textContent = data.artist;
    $('ltl-musicbrainz-link').href = `https://musicbrainz.org/search?query=${encodeURIComponent(`${data.artist} ${data.title}`)}&type=recording&method=indexed`; 
    $('ltl-query').value = `${data.artist} ${data.title}`;
    setPicker(false);
    activeIsrc = null;
    currentCamelot = '';
    seedFeatures = null;
    resetSuggestions();
    clearMetrics();
    requestTrack('LOOKUP_TRACK', {});
  }

  function status(text, kind = '') {
    $('ltl-status').textContent = text;
    $('ltl-status').dataset.kind = kind;
    $('ltl-mini-state').dataset.kind = kind;
    $('ltl-mini-state').title = text;
    $('ltl-mini-state').textContent = kind === 'success' ? 'READY'
      : kind === 'warning' ? 'MATCH NEEDED'
      : kind === 'error' ? 'CHECK MATCH'
      : /looking|searching|loading/i.test(text) ? 'LOOKING UP' : 'WAITING';
  }

  function setAnalysisSource(data) {
    const origin = typeof data === 'string' ? data : (data?.analysisSource || 'songfinder');
    const sourceKeys = typeof data === 'object' ? Object.values(data?.featureSources || {}) : [];
    const manual = sourceKeys.includes('manual') || origin === 'manual' || origin === 'mixed_manual';
    const recco = sourceKeys.includes('reccobeats') || origin === 'reccobeats' || (origin === 'mixed' && !manual);
    const songfinder = sourceKeys.includes('songfinder') || (!sourceKeys.length && origin === 'songfinder') || (origin === 'mixed' && !manual);
    $('ltl-source-songfinder').hidden = !songfinder;
    $('ltl-source-recco').hidden = !recco;
    $('ltl-source-join').hidden = !(songfinder && recco);
    $('ltl-source-manual').hidden = !manual;
    $('ltl-source-manual').textContent = manual && (songfinder || recco) ? ' + MANUAL' : 'MANUAL';
  }

  function renderMetricProvenance(data) {
    const block = $('ltl-metric-provenance');
    block.replaceChildren();
    const fields = [['tempo','BPM'], ['key','Key'], ['energy','Energy'], ['danceability','Dance']];
    const featureSources = data.featureSources || {};
    const features = data.features || {};
    const names = { songfinder: 'Song Finder', reccobeats: 'ReccoBeats', manual: 'Manual' };
    for (const [field, label] of fields) {
      const hasValue = field === 'key' ? Boolean(features.key?.camelot)
        : typeof features[field] === 'number' && Number.isFinite(features[field]);
      const origin = hasValue ? (featureSources[field] || (data.analysisSource === 'reccobeats'
        ? 'reccobeats' : data.analysisSource === 'manual' ? 'manual' : 'songfinder')) : 'unavailable';
      const chip = document.createElement('span');
      chip.dataset.source = origin;
      const name = document.createElement('b');
      name.textContent = `${label}: `;
      chip.append(name, document.createTextNode(names[origin] || 'N/A'));
      block.append(chip);
    }
    block.hidden = false;
    // Tooltips are especially useful in the mobile compact view, where the
    // extra source row is deliberately not displayed.
    const ids = [['ltl-bpm','ltl-mini-bpm','tempo'], ['ltl-camelot','ltl-mini-camelot','key'],
      ['ltl-energy','ltl-mini-energy','energy'], ['ltl-dance','ltl-mini-dance','danceability']];
    for (const [full, mini, field] of ids) {
      const source = featureSources[field] || (data.analysisSource === 'reccobeats' ? 'reccobeats' :
        data.analysisSource === 'manual' ? 'manual' : 'songfinder');
      const present = field === 'key' ? Boolean(features.key?.camelot) : typeof features[field] === 'number';
      const tooltip = `${field === 'tempo' ? 'BPM' : field}: ${present ? (names[source] || 'Unknown source') : 'Unavailable'}`;
      $(full).parentElement.title = tooltip;
      $(mini).parentElement.title = tooltip;
    }
  }

  function resetAnalysis() {
    $('ltl-metric-provenance').replaceChildren();
    $('ltl-metric-provenance').hidden = true;
    setAnalysisSource('songfinder');
    ['ltl-bpm', 'ltl-camelot', 'ltl-energy', 'ltl-dance'].forEach(id => $(id).textContent = '—');
    $('ltl-energy-bar').style.width = '0%';
    $('ltl-dance-bar').style.width = '0%';
    $('ltl-key').textContent = 'Musical key unavailable';
    $('ltl-compatible').textContent = '';
    $('ltl-tempo-warning').hidden = true;
    $('ltl-fallback-debug').hidden = true;
    $('ltl-spotify-link-helper').hidden = true;
    $('ltl-recco-review').hidden = true;
    $('ltl-recco-candidates').replaceChildren();
    $('ltl-manual-editor').hidden = true;
    ['ltl-mini-bpm', 'ltl-mini-camelot', 'ltl-mini-energy', 'ltl-mini-dance'].forEach(id => $(id).textContent = '—');
  }

  function clearMetrics() {
    resetAnalysis();
    $('ltl-match-note').textContent = 'Searching Song Finder catalogue';
    $('ltl-mini-state').textContent = 'LOOKING UP';
    status('Looking up track…');
    candidates = [];
    updateCandidates();
  }

  function asPercent(number) {
    if (typeof number !== 'number' || !Number.isFinite(number) || number < 0) return null;
    return Math.max(0, Math.min(100, Math.round(number * 100)));
  }

  function displayNumber(num) {
    return typeof num === 'number' && Number.isFinite(num) && num > 0 ? String(Math.round(num)) : '—';
  }

  function updateCandidates() {
    const select = $('ltl-choice');
    select.replaceChildren();
    if (!candidates.length) {
      const item = document.createElement('option');
      item.textContent = 'No suggestions yet — search below';
      item.value = '';
      select.append(item);
      select.disabled = true;
      $('ltl-use-match').disabled = true;
      return;
    }
    select.disabled = false;
    $('ltl-use-match').disabled = false;
    for (const item of candidates) {
      const option = document.createElement('option');
      option.value = item.isrc;
      option.textContent = `${item.artist} — ${item.title}${item.album ? ` (${item.album})` : ''}`;
      select.append(option);
    }
  }

  async function requestTrack(type, extra) {
    if (!activeTrack) return;
    const thisRequest = ++requestNumber;
    const requestIdentity = signature;
    status(type === 'SAVE_MANUAL_FEATURES' ? 'Saving manual metrics…' : type === 'CLEAR_MANUAL_FEATURES' ? 'Clearing manual metrics…' : type === 'SEARCH_MATCH' ? 'Searching catalogue…' : type === 'SELECT_MATCH' ? 'Loading selected recording…' : type === 'SELECT_RECCO_FALLBACK' ? 'Checking selected ReccoBeats recording…' : type === 'RETRY_FALLBACK' ? 'Checking Spotify link…' : 'Looking up track…');
    $('ltl-refresh').disabled = true;
    try {
      const reply = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type, ...activeTrack, trackId: manualSpotifyId || activeTrack.trackId || '', ...extra }, response => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(response);
        });
      });
      if (thisRequest !== requestNumber || requestIdentity !== signature) return;
      if (!reply?.ok) throw new Error(reply?.error || 'Unknown extension error.');
      renderResult(reply.data);
      if (type === 'SAVE_MANUAL_FEATURES' || type === 'CLEAR_MANUAL_FEATURES') {
        $('ltl-manual-editor').open = false;
      }
    } catch (error) {
      if (thisRequest !== requestNumber || requestIdentity !== signature) return;
      const errorMessage = error.message || 'Could not look up this track.';
      status(errorMessage, 'error');
      const rateLimited = /rate limit/i.test(errorMessage);
      $('ltl-picker-hint').textContent = rateLimited
        ? 'Please wait briefly before searching or refreshing; Song Finder is limiting requests.'
        : 'The lookup failed. You can try searching by artist and exact mix title below.';
      $('ltl-match-note').textContent = rateLimited ? 'Wait, then refresh the analysis' : 'Use Change Match to search for a recording';
      $('ltl-mini-state').textContent = 'CHECK MATCH';
      if (!rateLimited && autoOpenPicker) setPicker(true);
    } finally {
      if (thisRequest === requestNumber) $('ltl-refresh').disabled = false;
    }
  }

  function renderReccoChoices(data, hasFeatures) {
    const section = $('ltl-recco-review');
    const list = $('ltl-recco-candidates');
    const rows = Array.isArray(data.fallbackAlternatives) ? data.fallbackAlternatives : [];
    section.hidden = hasFeatures || rows.length === 0;
    list.replaceChildren();
    if (section.hidden) return;
    $('ltl-recco-review-summary').textContent = `Review ${rows.length} possible ReccoBeats recording${rows.length === 1 ? '' : 's'}`;
    for (const candidate of rows) {
      const card = document.createElement('div');
      card.className = 'ltl-recco-card';
      const info = document.createElement('div');
      info.className = 'ltl-recco-info';
      const name = document.createElement('strong');
      name.textContent = `${candidate.title} — ${candidate.artist}`;
      const meta = document.createElement('small');
      const duration = Number(candidate.durationMs);
      const durationText = duration > 0 ? `${Math.floor(duration / 60000)}:${String(Math.floor(duration / 1000) % 60).padStart(2, '0')}` : 'Unknown length';
      meta.textContent = `${durationText} · ISRC ${candidate.isrc || 'not supplied'} · metadata match ${candidate.score}/100`;
      info.append(name, meta);
      const choose = document.createElement('button');
      choose.type = 'button';
      choose.className = 'ltl-small-btn ltl-recco-confirm';
      choose.textContent = 'USE THIS RECORDING';
      choose.dataset.reccoId = candidate.id;
      choose.title = 'Select this alternate ReccoBeats recording for analysis; its ISRC differs from Song Finder';
      card.append(info, choose);
      list.append(card);
    }
  }

  function renderResult(data) {
    lastResult = data;
    candidates = data.candidates || [];
    updateCandidates();
    if (data.status !== 'ok') {
      activeIsrc = null;
      currentCamelot = '';
      resetSuggestions();
    }
    if (data.status === 'choose') {
      resetAnalysis();
      status(data.manual ? 'Search results found. Choose the correct recording.' : 'Several recordings found. Choose the right mix.', 'warning');
      $('ltl-picker-hint').textContent = 'The catalogue contains similar recordings. Check the mix or remix name before choosing. You can compare release metadata in MusicBrainz below.';
      $('ltl-match-note').textContent = 'Select a recording to load its analysis';
      $('ltl-mini-state').textContent = 'MATCH NEEDED';
      if (autoOpenPicker) setPicker(true);
      return;
    }
    if (data.status === 'not_found') {
      resetAnalysis();
      status(data.manual ? 'No results for that search. Try a shorter query.' : 'No automatic match. Search the catalogue below.', 'warning');
      $('ltl-picker-hint').textContent = 'Edit the search below, press Search, then choose the right recording and click Use selected track. Try removing mix names if no results appear.';
      $('ltl-match-note').textContent = 'You can search manually for the correct version';
      $('ltl-mini-state').textContent = 'MATCH NEEDED';
      if (autoOpenPicker) setPicker(true);
      return;
    }
    const features = data.features || {};
    setAnalysisSource(data);
    renderMetricProvenance(data);
    const energy = asPercent(features.energy);
    const dance = asPercent(features.danceability);
    const bpm = displayNumber(features.tempo);
    const camelot = features.key?.camelot || '—';
    $('ltl-bpm').textContent = bpm;
    $('ltl-camelot').textContent = camelot;
    $('ltl-energy').textContent = energy === null ? '—' : String(energy);
    $('ltl-dance').textContent = dance === null ? '—' : String(dance);
    $('ltl-mini-bpm').textContent = bpm;
    $('ltl-mini-camelot').textContent = camelot;
    $('ltl-mini-energy').textContent = energy === null ? '—' : String(energy);
    $('ltl-mini-dance').textContent = dance === null ? '—' : String(dance);
    $('ltl-energy-bar').style.width = energy === null ? '0%' : `${energy}%`;
    $('ltl-dance-bar').style.width = dance === null ? '0%' : `${dance}%`;
    $('ltl-key').textContent = features.key?.name || 'Musical key unavailable';
    // Use exactly the same rules as Mix Next: same-key transitions count.
    const compatibleKeys = [...matchingKeys(camelot)];
    $('ltl-compatible').textContent = compatibleKeys.length
      ? `Mix with: ${compatibleKeys.map((key, index) => index === 0 ? `${key} (same)` : key).join(' · ')}` : '';
    const cross = Number(data.tempoCrossCheck);
    const primary = Number(features.tempo);
    const tempoDifferent = Number.isFinite(cross) && cross > 0 && primary > 0 && Math.abs(cross - primary) > 3;
    $('ltl-tempo-warning').hidden = !tempoDifferent;
    if (tempoDifferent) $('ltl-tempo-warning').textContent = `Tempo cross-check: another source reports ${Math.round(cross)} BPM. Check for half/double-time.`;
    const track = data.track || {};
    const nextIsrc = track.isrc || (track.reccoId ? `recco:${track.reccoId}` : null);
    if (nextIsrc !== activeIsrc) resetSuggestions();
    activeIsrc = nextIsrc;
    currentCamelot = camelot;
    seedFeatures = features;
    $('ltl-find-tracks').disabled = !activeIsrc || !/^([1-9]|1[0-2])[AB]$/i.test(camelot);
    $('ltl-harmonic-message').textContent = $('ltl-find-tracks').disabled
      ? 'A matched recording with a Camelot key is needed to find compatible tracks.'
      : adapter.discoveryHint;
    $('ltl-match-note').textContent = `Matched: ${track.artist || '?'} — ${track.title || '?'}${data.manual ? ' (manually chosen)' : ''}${data.matchMethod === 'spotify_id' ? ' · Verified using Spotify track ID' : ''}`;
    const hasFeatures = [features.tempo, features.energy, features.danceability, features.key].some(value => value !== null && value !== undefined);
    const hasMissingCore = !(typeof features.tempo === 'number' && features.tempo > 0 &&
      /^([1-9]|1[0-2])[AB]$/i.test(features.key?.camelot || '') && energy !== null && dance !== null);
    renderReccoChoices(data, !hasMissingCore);
    const sourceLabel = data.analysisSource === 'manual' ? 'Manually supplied metrics'
      : data.analysisSource === 'mixed_manual' ? 'Includes manually supplied metrics'
      : data.analysisSource === 'reccobeats' ? `ReccoBeats fallback${data.fallbackMethod === 'spotify_id' ? ' (Spotify ID)' : ''}`
      : data.analysisSource === 'mixed' ? 'Song Finder + ReccoBeats' : '';
    const readyText = data.cached ? 'Analysis loaded from cache' : 'Analysis ready';
    const unavailableText = data.fallbackStatus === 'review_required'
      ? 'Possible ReccoBeats recordings need your review.'
      : data.fallbackStatus === 'no_verified_match'
      ? 'Catalogue matched, but ReccoBeats found no matching recording.'
      : data.fallbackStatus === 'unavailable' ? 'Catalogue matched. ReccoBeats fallback unavailable.'
      : data.fallbackStatus === 'no_features' ? 'Neither provider returned acoustic analysis.'
      : data.fallbackStatus === 'isrc_conflict' ? 'ReccoBeats found a different recording. No features were mixed.'
      : 'Catalogue match found, but no acoustic analysis.';
    status(hasFeatures ? `${readyText}${sourceLabel ? ` · ${sourceLabel}` : ''}` : unavailableText,
      hasFeatures ? 'success' : 'warning');
    if (data.manualFallbackSelection) {
      $('ltl-match-note').textContent += ` · ReccoBeats selection: ${data.manualFallbackSelection.title} (different ISRC, chosen by you)`;
    } else if (data.recordingIdWarning && data.analysisSource === 'reccobeats') {
      $('ltl-match-note').textContent += ' · ReccoBeats matched via Spotify ID; recording identifiers differ';
    }
    const fallbackDetails = $('ltl-fallback-debug');
    fallbackDetails.hidden = !data.fallbackAttemptedAt || (!hasMissingCore && !showAdvancedDiagnostics);
    $('ltl-spotify-link-helper').hidden = !(adapter.id === 'spotify' && data.fallbackAttemptedAt && hasMissingCore);
    $('ltl-spotify-link-message').textContent = '';
    if (data.fallbackAttemptedAt) {
      const info = data.fallbackDiagnostics || {};
      const helperText = $('ltl-spotify-link-helper').querySelector('p');
      if (helperText && info.spotifyIdLookup === 'not_found') {
        helperText.textContent = 'The Spotify ID was checked, but ReccoBeats did not return that ID. Review plausible alternate recordings below, or try another link if this is not the playing song.';
      } else if (helperText) {
        helperText.textContent = 'If Spotify did not expose its track ID, use Share → Copy link to song and paste the link below to retry ReccoBeats.';
      }
      const idStatus = {
        not_available: 'not available in current player', returned: 'found a candidate',
        not_found: 'not found', metadata_mismatch: 'candidate rejected: metadata mismatch',
        error: 'lookup unavailable'
      }[info.spotifyIdLookup] || 'not attempted';
      $('ltl-fallback-debug-text').textContent =
        `Spotify ID lookup: ${idStatus} · Text-search rows: ${Number(info.searchRows) || 0}` +
        ` · Reviewable alternate recordings: ${Number(info.reviewableCandidates) || 0}` +
        ` · Verified text matches: ${Number(info.validCandidates) || 0}` +
        ` · Fallback status: ${data.fallbackStatus || 'unknown'}` +
        (Object.keys(info.rejected || {}).length ? ` · Search rejected: ${Object.entries(info.rejected).map(([reason,count]) => `${reason} ${count}`).join(', ')}` : '') +
        (data.fallbackMethod ? ` · Selected via: ${data.fallbackMethod.replace('_', ' ')}` : '');
    }
    renderManualEditor(data);
    if (data.manual) setPicker(false);
  }

  function renderManualEditor(data) {
    const fields = [
      ['tempo','ltl-manual-bpm', v => v],
      ['key','ltl-manual-camelot', v => v?.camelot],
      ['energy','ltl-manual-energy', v => Math.round(v * 100)],
      ['danceability','ltl-manual-dance', v => Math.round(v * 100)]
    ];
    const features = data.features || {};
    const sources = data.featureSources || {};
    const haveManual = Object.values(sources).includes('manual');
    const hasMissing = fields.some(([field]) => field === 'key' ? !features.key?.camelot : features[field] === null || features[field] === undefined);
    const editor = $('ltl-manual-editor');
    editor.hidden = !hasMissing && !haveManual;
    $('ltl-clear-manual').hidden = !haveManual;
    if (editor.hidden) return;
    $('ltl-manual-reference').value = haveManual ? (data.manualMetricsSource || '') : '';
    for (const [field, id, transform] of fields) {
      const input = $(id);
      const present = field === 'key' ? !!features.key?.camelot : typeof features[field] === 'number';
      const readonlyProvider = present && sources[field] !== 'manual';
      input.disabled = readonlyProvider;
      input.value = present && !readonlyProvider ? String(transform(features[field])) : '';
      input.title = readonlyProvider ? 'Already supplied by an analysis provider' : '';
      input.placeholder = readonlyProvider ? 'Provided by API' :
        field === 'tempo' ? 'e.g. 140' : field === 'key' ? 'e.g. 3B' : '0–100';
    }
    $('ltl-manual-summary').textContent = haveManual ? 'Manual metrics · saved (edit or clear)' : 'Fill missing metrics manually';
    $('ltl-manual-message').textContent = haveManual ? `Manual values saved for this recording${data.manualMetricsSource ? ` (${data.manualMetricsSource})` : ''}.` : '';
  }

  function resetSuggestions() {
    suggestionsRequest += 1; // Ignore any previous track's outstanding request.
    suggestionsLoaded = false;
    suggestionPool = [];
    suggestionCursor = 0;
    suggestionMatches = [];
    suggestionNearMatches = [];
    suggestionReviews = [];
    reviewVisibleCount = REVIEW_PAGE_SIZE;
    suggestionSeen = new Set();
    failedCandidates.clear();
    failedRetryOffset = 0;
    relatedShowState = '';
    suggestionStats = null;
    suggestionBusy = false;
    scannedBatches = 0;
    $('ltl-suggestions').replaceChildren();
    $('ltl-suggestions').hidden = true;
    $('ltl-related-list').replaceChildren();
    $('ltl-related').hidden = true;
    $('ltl-scan-hint').hidden = true;
    $('ltl-retry-failed').hidden = true;
    $('ltl-review-list').replaceChildren();
    $('ltl-restore-reviews').hidden = true;
    $('ltl-review').hidden = true;
    $('ltl-review').open = false;
    $('ltl-find-tracks').disabled = true;
    $('ltl-find-tracks').textContent = 'FIND TRACKS ↗';
    $('ltl-find-tracks').title = 'Find candidates from the visible music service queue or recommendations.';
    $('ltl-harmonic-message').textContent = 'Analyse a track to discover harmonically compatible songs.';
    $('ltl-harmonic-debug').hidden = adapter.id !== 'spotify';
    $('ltl-harmonic-debug').open = false;
    $('ltl-queue-report-status').textContent = '';
    $('ltl-queue-report-fallback').hidden = true;
  }

  function matchingKeys(key) {
    const result = /^([1-9]|1[0-2])([AB])$/i.exec(String(key || '').trim());
    if (!result) return new Set();
    const n = Number(result[1]);
    const mode = result[2].toUpperCase();
    return new Set([`${n}${mode}`, `${n}${mode === 'A' ? 'B' : 'A'}`,
      `${n === 1 ? 12 : n - 1}${mode}`, `${n === 12 ? 1 : n + 1}${mode}`]);
  }

  function tempoGap(a, b) {
    if (!Number.isFinite(a) || !Number.isFinite(b) || !a || !b) return 32;
    return Math.min(Math.abs(a - b), Math.abs(a * 2 - b), Math.abs(a - b * 2));
  }

  function dismissedReviewSet() {
    return new Set(activeIsrc && Array.isArray(dismissedReviewsBySeed[activeIsrc])
      ? dismissedReviewsBySeed[activeIsrc] : []);
  }

  function dismissReview(id) {
    if (!activeIsrc || !suggestionReviews.some(item => item.id === id)) return;
    const ids = dismissedReviewSet();
    ids.add(id);
    dismissedReviewsBySeed[activeIsrc] = [...ids].slice(-80);
    // Bound storage to a reasonable number of seeds. Dismissal is local to
    // this seed, not a global judgement about the artist/recording.
    const seeds = Object.keys(dismissedReviewsBySeed);
    if (seeds.length > 120) delete dismissedReviewsBySeed[seeds[0]];
    chrome.storage.local.set({[DISMISSED_REVIEWS_KEY]: dismissedReviewsBySeed}).catch(() => {});
    renderReview();
  }

  function rankSuggestion(item) {
    const tempo = tempoGap(seedFeatures?.tempo, item.bpm);
    const energy = Number.isFinite(seedFeatures?.energy) && Number.isFinite(item.energy)
      ? Math.abs(seedFeatures.energy - item.energy) * 100 : 28;
    const keyPenalty = item.camelot === currentCamelot ? 0 : 3;
    return tempo * 1.8 + energy * 0.45 + keyPenalty;
  }

  function updateDiscoveryControls() {
    const retry = $('ltl-retry-failed');
    const hint = $('ltl-scan-hint');
    const button = $('ltl-find-tracks');
    if (!suggestionStats) {
      retry.hidden = true;
      hint.hidden = true;
      return;
    }
    const remaining = suggestionCursor < suggestionPool.length;
    retry.hidden = failedCandidates.size === 0;
    retry.disabled = suggestionBusy;
    retry.textContent = `RETRY FAILED LOOKUPS (${failedCandidates.size})`;
    retry.title = 'Recheck up to eight previously missing, incomplete or failed analyses. Unlike Scan New Tracks, this may request the same recordings again.';
    hint.hidden = remaining;
    hint.textContent = 'Scan New Tracks looks for newly loaded Radio, Queue or Up Next songs only; checked tracks are skipped.';
    if (!suggestionBusy) {
      button.textContent = remaining ? 'FIND MORE' : 'SCAN NEW TRACKS';
      button.title = remaining
        ? 'Analyse the next eight discovered recordings.'
        : 'Discover newly visible tracks without repeating previously checked recordings.';
    }
  }

  function renderDiscovery() {
    const list = $('ltl-suggestions');
    const matches = [...suggestionMatches].sort((a, b) => rankSuggestion(a) - rankSuggestion(b));
    const toShow = matches.slice(0, 5 + Math.max(0, scannedBatches - 1) * 3);
    list.replaceChildren(...toShow.map(suggestionCard));
    list.hidden = !toShow.length;

    // Other keys are never placed inside the harmonic-match list.
    const related = $('ltl-related');
    const otherKeys = [...suggestionNearMatches].sort((a, b) => rankSuggestion(a) - rankSuggestion(b));
    related.hidden = !otherKeys.length;
    $('ltl-related-summary').textContent = `Related tracks (${otherKeys.length}) - other keys, NOT harmonic matches`;
    $('ltl-related-list').replaceChildren(...otherKeys.slice(0, 5).map(suggestionCard));
    const state = matches.length ? 'has-matches' : 'no-matches';
    if (otherKeys.length && relatedShowState !== state) related.open = !matches.length;
    relatedShowState = state;
    renderReview();
    const st = suggestionStats;
    if (st) {
      $('ltl-harmonic-debug-text').textContent =
        `Source: ${adapter.label} ${Object.entries(st.sources || {}).map(([name, amount]) => `${name} (${amount})`).join(' · ') || 'no visible candidates'} · ` +
        `${st.checked}/${st.found} analysed · ${st.cached} cache hits · ` +
        `${st.compatible} compatible · ${st.incompatible} other keys · ` +
        `${st.ambiguous} uncertain matches (${st.reviewed || 0} manually resolved, ${dismissedReviewSet().size} dismissed) · ${st.missingKey} without a key` +
        (st.missingKey ? ` (${Object.entries(st.missingKeyReasons || {}).map(([kind, count]) => `${kind === 'no-features' ? 'no acoustic features' : 'key unavailable'}: ${count}`).join(', ')})` : '') + ' · ' +
        `${st.notFound} not found · ${st.errors} errors · ${st.retries || 0} retries · ` +
        `${st.fromLibrary} compatible from your local library.` +
        (adapter.id === 'spotify' && st.discovery ?
          ` Spotify extraction: Radio page ${st.discovery.radioPage ? 'yes' : 'no'} · ` +
          `Radio rows ${st.discovery.Radio?.rows ?? 0}, usable ${st.discovery.Radio?.linked ?? 0} · ` +
          `Queue rows ${st.discovery.Queue?.rows ?? 0}, usable ${st.discovery.Queue?.linked ?? 0} · ` +
          `Recommended rows ${st.discovery.Recommended?.rows ?? 0}, usable ${st.discovery.Recommended?.linked ?? 0}.` : '');
      $('ltl-harmonic-debug').hidden = false;
    }
    updateDiscoveryControls();
  }

  function suggestionMessage() {
    const st = suggestionStats;
    if (!st) return;
    const more = suggestionCursor < suggestionPool.length;
    const progress = more ? ` Checked ${st.checked} of ${st.found} discovered tracks.` : '';
    if (suggestionMatches.length) {
      $('ltl-harmonic-message').textContent =
        `${suggestionMatches.length} verified Camelot matches, ranked by tempo and energy.${progress}`;
    } else if (st.fromLibrary) {
      $('ltl-harmonic-message').textContent =
        `${st.fromLibrary} compatible matches from your previously analysed tracks (not new recommendations).`;
    } else if (suggestionNearMatches.length) {
      $('ltl-harmonic-message').textContent =
        `No compatible keys found in ${st.checked} analysed tracks.${more ? ' Find More can check the remaining tracks.' : ' See Related tracks below for other keys.'}`;
    } else if (!st.found) {
      $('ltl-harmonic-message').textContent = adapter.emptyHint;
    } else {
      $('ltl-harmonic-message').textContent =
        `No verified matches yet.${progress} ${more ? 'Select Find More to continue.' : adapter.moreHint}`;
    }
    updateDiscoveryControls();
  }

  function renderReview() {
    const section = $('ltl-review');
    const list = $('ltl-review-list');
    const dismissed = dismissedReviewSet();
    const ranked = suggestionReviews.filter(review => !dismissed.has(review.id)).sort((a, b) =>
      Number(b.candidates?.some(c => c.keyAvailability === 'cached-key')) -
      Number(a.candidates?.some(c => c.keyAvailability === 'cached-key')));
    section.hidden = !ranked.length && !dismissed.size;
    $('ltl-review-summary').textContent = `Review uncertain catalogue matches (${ranked.length}${dismissed.size ? `; ${dismissed.size} dismissed` : ''})`;
    list.replaceChildren();
    // Items with already cached musical keys appear first, but nothing is
    // considered a harmonic match until the listener confirms the recording.
    for (const review of ranked.slice(0, reviewVisibleCount)) {
      const card = document.createElement('div');
      card.className = 'ltl-review-card';
      const heading = document.createElement('div');
      const title = document.createElement('strong');
      title.textContent = `${review.title} — ${review.artist}`;
      const origin = document.createElement('small');
      origin.textContent = `Source: ${review.source}`;
      heading.append(title, origin);
      card.append(heading);
      const why = document.createElement('p');
      why.className = 'ltl-review-why';
      why.textContent = `Why review? ${review.reviewReason || 'Catalogue metadata cannot independently verify the exact recording or mix.'}`;
      card.append(why);
      if (review.candidates.length) {
        const controls = document.createElement('div');
        controls.className = 'ltl-review-controls';
        const choice = document.createElement('select');
        choice.setAttribute('aria-label', `Choose catalogue version for ${review.title}`);
        for (const candidate of review.candidates) {
          const option = document.createElement('option');
          option.value = candidate.isrc;
          const checked = candidate.keyAvailability === 'cached-key' ? ' · key saved' :
            candidate.keyAvailability === 'cached-no-key' ? ' · no saved key' : '';
          option.textContent = `${candidate.artist} — ${candidate.title} (${candidate.score}/100 metadata similarity${checked})`;
          choice.append(option);
        }
        choice.value = review.selectedIsrc || review.candidates[0].isrc;
        choice.disabled = Boolean(review.resolving);
        const note = document.createElement('small');
        note.className = 'ltl-review-choice-note';
        const updateNote = () => {
          const candidate = review.candidates.find(item => item.isrc === choice.value);
          note.textContent = candidate?.keyAvailability === 'cached-key'
            ? 'This recording has a previously saved musical key; confirm its identity before using it.'
            : candidate?.keyAvailability === 'cached-no-key'
              ? 'This recording was previously analysed, but has no known key.'
              : 'Acoustic feature availability is checked after you select this recording.';
        };
        choice.addEventListener('change', () => { review.selectedIsrc = choice.value; updateNote(); });
        updateNote();
        const button = document.createElement('button');
        button.className = 'ltl-small-btn';
        button.type = 'button';
        button.textContent = review.resolving ? 'Checking recording…' : 'Use selected recording';
        button.disabled = Boolean(review.resolving);
        button.addEventListener('click', () => resolveDiscoveryReview(review.id, choice.value));
        controls.append(choice, note, button);
        card.append(controls);
      } else {
        const note = document.createElement('small');
        note.textContent = 'No catalogue choices available. Try changing the source-track metadata.';
        card.append(note);
      }
      if (review.error) {
        const warning = document.createElement('p');
        warning.className = 'ltl-review-error';
        warning.textContent = review.error;
        card.append(warning);
      }
      const dismiss = document.createElement('button');
      dismiss.type = 'button';
      dismiss.className = 'ltl-review-dismiss';
      dismiss.textContent = 'Dismiss this suggestion';
      dismiss.title = 'Hide this uncertain recording for the current seed track. You can restore it below.';
      dismiss.disabled = Boolean(review.resolving);
      dismiss.addEventListener('click', () => dismissReview(review.id));
      card.append(dismiss);
      list.append(card);
    }
    const restore = $('ltl-restore-reviews');
    restore.hidden = !dismissed.size;
    restore.textContent = `Restore dismissed suggestions (${dismissed.size})`;
    if (ranked.length > reviewVisibleCount) {
      const more = document.createElement('button');
      more.className = 'ltl-review-more';
      more.type = 'button';
      more.textContent = `Show ${Math.min(REVIEW_PAGE_SIZE, ranked.length - reviewVisibleCount)} more (${ranked.length - reviewVisibleCount} remaining)`;
      more.addEventListener('click', () => { reviewVisibleCount += REVIEW_PAGE_SIZE; renderReview(); });
      list.append(more);
    }
  }

  async function resolveDiscoveryReview(id, isrc) {
    const review = suggestionReviews.find(item => item.id === id);
    if (!review || review.resolving || !review.candidates.some(item => item.isrc === isrc)) return;
    const token = suggestionsRequest;
    const trackSignature = signature;
    const seedIsrc = activeIsrc;
    review.selectedIsrc = isrc;
    review.resolving = true;
    review.error = '';
    renderReview();
    try {
      // SELECT_MATCH also stores this explicit recording choice in the shared
      // cache, so subsequent Mix Next scans can reuse it on either platform.
      const result = await askBackground({ type: 'SELECT_MATCH', title: review.title,
        artist: review.artist, isrc });
      if (token !== suggestionsRequest || signature !== trackSignature || activeIsrc !== seedIsrc) return;
      if (result.status !== 'ok' || !result.track) throw new Error('No details for the selected recording.');
      const features = result.features || {};
      const camelot = String(features.key?.camelot || '').toUpperCase();
      const suggestion = { isrc: result.track.isrc, title: result.track.title,
        artist: result.track.artist, camelot, bpm: features.tempo,
        energy: features.energy, danceability: features.danceability,
        analysisSource: result.analysisSource,
        source: review.source, videoId: review.videoId, spotifyId: review.spotifyId };
      const index = suggestionReviews.findIndex(item => item.id === id);
      if (index >= 0) suggestionReviews.splice(index, 1);
      suggestionStats.ambiguous = Math.max(0, suggestionStats.ambiguous - 1);
      suggestionStats.reviewed = (suggestionStats.reviewed || 0) + 1;
      if (!matchingKeys(camelot).size) suggestionStats.missingKey += 1;
      else if (matchingKeys(currentCamelot).has(camelot)) {
        suggestionMatches.push(suggestion);
        suggestionStats.compatible += 1;
      } else {
        suggestionNearMatches.push(suggestion);
        suggestionStats.incompatible += 1;
      }
      renderDiscovery();
      suggestionMessage();
    } catch (error) {
      if (token !== suggestionsRequest || signature !== trackSignature || activeIsrc !== seedIsrc) return;
      review.error = error?.message || 'Could not check this recording.';
      review.resolving = false;
      renderReview();
    }
  }

  function suggestionCard(item) {
    // Use textContent for remote catalogue strings, never inject them as HTML.
    const link = document.createElement('a');
    link.className = 'ltl-suggestion-card';
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.href = adapter.openUrl(item);
    link.setAttribute('aria-label', `Open ${item.title} by ${item.artist} on ${adapter.label}`);

    const text = document.createElement('span');
    text.className = 'ltl-suggestion-text';
    const title = document.createElement('strong');
    title.textContent = item.title;
    const artist = document.createElement('small');
    artist.textContent = `${item.artist}${item.source ? ` · ${item.source}` : ''}${item.analysisSource === 'reccobeats' ? ' · ReccoBeats' : item.analysisSource === 'mixed' ? ' · Mixed data' : ''}`;
    text.append(title, artist);

    const stats = document.createElement('span');
    stats.className = 'ltl-suggestion-stats';
    const energy = asPercent(item.energy);
    const dance = asPercent(item.danceability);
    const chips = [
      { label: item.camelot || '—', tooltip: item.camelot ? 'Camelot key' : 'Key unavailable' },
      { label: `${displayNumber(item.bpm)} BPM`, tooltip: 'Tempo' },
      { label: `E ${energy === null ? '—' : energy}`, tooltip: `Energy ${energy === null ? 'unavailable' : `${energy}/100`}` },
      { label: `D ${dance === null ? '—' : dance}`, tooltip: `Danceability ${dance === null ? 'unavailable' : `${dance}/100`}` }
    ];
    for (const item of chips) {
      const chip = document.createElement('span');
      chip.textContent = item.label;
      chip.title = item.tooltip;
      stats.append(chip);
    }
    const arrow = document.createElement('span');
    arrow.className = 'ltl-suggestion-arrow';
    arrow.setAttribute('aria-hidden', 'true');
    arrow.textContent = '↗';
    link.append(text, stats, arrow);
    return link;
  }

  function askBackground(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, reply => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else if (!reply?.ok) reject(new Error(reply?.error || 'Track Lens request failed.'));
        else resolve(reply.data);
      });
    });
  }

  function recommendationIdentity(item) {
    return `${String(item.artist || '').toLowerCase().trim()}::${String(item.title || '').toLowerCase().trim()}`;
  }

  async function localFallback(token, identity, isrc) {
    if (suggestionMatches.length || token !== suggestionsRequest) return;
    try {
      const local = await askBackground({ type: 'GET_CACHED_MIXES', isrc, camelot: currentCamelot,
        title: activeTrack?.title, artist: activeTrack?.artist });
      if (token !== suggestionsRequest || identity !== signature || isrc !== activeIsrc) return;
      for (const item of Array.isArray(local) ? local : []) {
        const id = recommendationIdentity(item);
        if (suggestionSeen.has(id)) continue;
        suggestionSeen.add(id);
        suggestionMatches.push({ ...item, source: 'library' });
        suggestionStats.fromLibrary += 1;
      }
      renderDiscovery();
      suggestionMessage();
    } catch (error) {
      if (suggestionStats && token === suggestionsRequest) {
        suggestionStats.errors += 1;
        renderDiscovery();
      }
    }
  }

  async function findSuggestions(retryFailed = false) {
    if (!activeTrack || !activeIsrc || !matchingKeys(currentCamelot).size || suggestionBusy) return;
    if (retryFailed && !failedCandidates.size) return;
    const token = ++suggestionsRequest;
    const isrc = activeIsrc;
    const identity = signature;
    suggestionBusy = true;
    const button = $('ltl-find-tracks');
    button.disabled = true;
    $('ltl-retry-failed').disabled = true;
    button.textContent = retryFailed ? 'RETRYING...' : 'CHECKING...';
    const stillCurrent = () => token === suggestionsRequest && identity === signature && isrc === activeIsrc;

    // Read rendered recommendations on the current platform, not the sparse
    // Song Finder similar endpoint. A scan only considers NEW candidate IDs.
    if (!retryFailed && (!suggestionsLoaded || suggestionCursor >= suggestionPool.length)) {
      const fresh = adapter.collectCandidates(document);
      const next = (Array.isArray(fresh?.candidates) ? fresh.candidates : [])
        .filter(item => !suggestionSeen.has(recommendationIdentity(item)));
      suggestionPool = next;
      suggestionCursor = 0;
      suggestionsLoaded = true;
      suggestionStats = suggestionStats || { found: 0, sources: {},
        checked: 0, cached: 0, compatible: 0, incompatible: 0, ambiguous: 0,
        missingKey: 0, missingKeyReasons: {}, notFound: 0, errors: 0, fromLibrary: 0 };
      suggestionStats.found += next.length;
      if (adapter.id === 'spotify') suggestionStats.discovery = fresh?.diagnostics || null;
      for (const item of next) {
        suggestionStats.sources[item.source] = (suggestionStats.sources[item.source] || 0) + 1;
      }
    }

    const failedSnapshot = retryFailed ? [...failedCandidates.values()] : [];
    // Rotate retries through the whole unresolved pool instead of rechecking
    // the same first eight items forever.
    const retryOrder = retryFailed && failedSnapshot.length
      ? [...failedSnapshot.slice(failedRetryOffset % failedSnapshot.length),
          ...failedSnapshot.slice(0, failedRetryOffset % failedSnapshot.length)] : [];
    const batch = retryFailed
      ? retryOrder.slice(0, DISCOVERY_BATCH_SIZE)
      : suggestionPool.slice(suggestionCursor, suggestionCursor + DISCOVERY_BATCH_SIZE);
    if (!batch.length) {
      if (!retryFailed) await localFallback(token, identity, isrc);
      if (stillCurrent()) {
        suggestionBusy = false;
        suggestionMessage();
        updateDiscoveryControls();
        button.disabled = false;
      }
      return;
    }

    if (!retryFailed) scannedBatches += 1;
    let stopReason = '';
    const validKeys = matchingKeys(currentCamelot);
    for (const candidate of batch) {
      if (!stillCurrent()) break;
      const key = recommendationIdentity(candidate);
      const previous = failedCandidates.get(key);
      if (!retryFailed) {
        suggestionCursor += 1;
        suggestionSeen.add(key);
      }
      $('ltl-harmonic-message').textContent =
        `${retryFailed ? 'Retrying' : 'Checking'} ${candidate.artist} - ${candidate.title}...`;
      const clearPreviousFailure = () => {
        if (!previous) return;
        if (previous.failureKind === 'notFound') suggestionStats.notFound = Math.max(0, suggestionStats.notFound - 1);
        if (previous.failureKind === 'error') suggestionStats.errors = Math.max(0, suggestionStats.errors - 1);
        if (previous.failureKind === 'missingKey') {
          suggestionStats.missingKey = Math.max(0, suggestionStats.missingKey - 1);
          const oldReason = previous.missingKeyReason || 'key-unavailable';
          suggestionStats.missingKeyReasons[oldReason] = Math.max(0, (suggestionStats.missingKeyReasons[oldReason] || 0) - 1);
        }
        failedCandidates.delete(key);
      };
      try {
        const analysed = await askBackground({ type: 'ANALYSE_DISCOVERY_CANDIDATE',
          platform: adapter.id, title: candidate.title, artist: candidate.artist,
          trackId: candidate.spotifyId || candidate.trackId || '', refresh: retryFailed });
        if (!stillCurrent()) break;
        clearPreviousFailure();
        if (analysed.cached) suggestionStats.cached += 1;
        const result = analysed.track;
        if (analysed.status === 'ok' && result && validKeys.has(result.camelot)) {
          suggestionStats.compatible += 1;
          suggestionMatches.push({ ...result, source: candidate.source, videoId: candidate.videoId, spotifyId: candidate.spotifyId });
        } else if (analysed.status === 'ok' && result) {
          suggestionStats.incompatible += 1;
          suggestionNearMatches.push({ ...result, source: candidate.source, videoId: candidate.videoId, spotifyId: candidate.spotifyId });
        } else if (analysed.status === 'missing_key') {
          suggestionStats.missingKey += 1;
          const reason = analysed.missingKeyReason || 'key-unavailable';
          suggestionStats.missingKeyReasons ||= {};
          suggestionStats.missingKeyReasons[reason] = (suggestionStats.missingKeyReasons[reason] || 0) + 1;
          failedCandidates.set(key, {...candidate, failureKind:'missingKey', missingKeyReason:reason});
        } else if (analysed.status === 'ambiguous') {
          suggestionStats.ambiguous += 1;
          suggestionReviews.push({ ...candidate, id: key,
            candidates: Array.isArray(analysed.candidates) ? analysed.candidates : [],
            reviewReason: analysed.reviewReason || '', reviewCode: analysed.reviewCode || '',
            selectedIsrc: analysed.candidates?.[0]?.isrc || null, resolving: false, error: '' });
        } else {
          suggestionStats.notFound += 1;
          failedCandidates.set(key, {...candidate, failureKind:'notFound'});
        }
      } catch (error) {
        if (!stillCurrent()) break;
        if (/rate limit/i.test(error.message || '')) {
          // The current candidate was not processed; keep it pending.
          if (!retryFailed) {
            suggestionCursor -= 1;
            suggestionSeen.delete(key);
          }
          stopReason = 'An analysis provider is rate limiting requests. Wait before trying again; this recording remains pending.';
          break;
        }
        clearPreviousFailure();
        suggestionStats.errors += 1;
        failedCandidates.set(key, {...candidate, failureKind:'error'});
      }
      if (retryFailed) suggestionStats.retries = (suggestionStats.retries || 0) + 1;
      else suggestionStats.checked += 1;
      renderDiscovery();
    }
    if (stillCurrent()) {
      if (retryFailed && failedSnapshot.length) {
        failedRetryOffset = (failedRetryOffset + batch.length) % failedSnapshot.length;
      }
      if (!retryFailed && suggestionCursor >= suggestionPool.length && !suggestionMatches.length) {
        await localFallback(token, identity, isrc);
      }
      if (stillCurrent()) {
        suggestionBusy = false;
        renderDiscovery();
        suggestionMessage();
        if (stopReason) $('ltl-harmonic-message').textContent = stopReason;
        button.disabled = false;
        updateDiscoveryControls();
      }
    }
  }

  refreshPlayerBarObserver();
  checkCurrentTrack();
  setInterval(checkCurrentTrack, 1700);
})();
