'use strict';

// Song Finder's documented API returns {code, message, data}.
// https://github.com/songfinder-dev/songfinder/blob/main/js/src/client.ts
const API_BASE = 'https://songfinder.dev';
const RECCO_BASE = 'https://api.reccobeats.com/v1';
const CACHE_KEY = 'listener-track-lens-cache-v1';
const MANUAL_VALUES_KEY = 'track-lens-user-metrics-v1';
const CACHE_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const NOT_FOUND_TTL_MS = 12 * 60 * 60 * 1000;
const RECCO_RETRY_TTL_MS = 6 * 60 * 60 * 1000; // avoid repeatedly searching for recordings not in ReccoBeats
const MAX_CACHE_ENTRIES = 120;
const MIN_REQUEST_SPACING_MS = 1800;
const HTTP_TIMEOUT_MS = 18000;
const ISRC_RE = /^[A-Za-z0-9]{12}$/;

let lastRequestStart = 0;
let apiQueue = Promise.resolve();
let reccoQueue = Promise.resolve();
let lastReccoRequestStart = 0;
const pendingLookups = new Map();

const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Always use the extension's background worker for network access.
// The content script never needs broad cross-origin access.
async function fetchJson(path, timeoutMs = HTTP_TIMEOUT_MS) {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    // Queue API calls rather than issuing bursts when songs are skipped quickly.
    const task = apiQueue.catch(() => {}).then(async () => {
      const delay = Math.max(0, MIN_REQUEST_SPACING_MS - (Date.now() - lastRequestStart));
      if (delay) await wait(delay);
      lastRequestStart = Date.now();
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const response = await fetch(`${API_BASE}${path}`, {
          method: 'GET',
          headers: { Accept: 'application/json' },
          signal: controller.signal,
          cache: 'no-store'
        });
        if (response.status === 429) {
          const err = new Error('Song Finder rate limit reached. Try again shortly.');
          err.retryable = true;
          throw err;
        }
        if (!response.ok) throw new Error(`Song Finder returned HTTP ${response.status}.`);
        let payload;
        try {
          payload = await response.json();
        } catch {
          throw new Error('Song Finder returned an unreadable response.');
        }
        if (payload?.code !== 0) throw new Error(payload?.message || 'Song Finder declined the lookup.');
        return payload.data;
      } catch (error) {
        if (error?.name === 'AbortError') {
          throw new Error('Song Finder took too long to respond.');
        }
        throw error;
      } finally {
        clearTimeout(timeout);
      }
    });
    apiQueue = task.catch(() => {});
    try {
      return await task;
    } catch (error) {
      if (error.retryable && attempt === 0) {
        await wait(4500);
        continue;
      }
      throw error;
    }
  }
}

// Keep the original cache key format so upgrades preserve all saved/manual
// recordings, including artists with characters such as IKØN.
function legacyNormalise(value) {
  return String(value ?? '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\b(?:official|music|lyric)\s+(?:video|audio|visuali[sz]er)\b/g, ' ')
    .replace(/\b(?:video|audio|4k|hd)\b/g, ' ')
    .replace(/\bfeat(?:uring)?\.?\b/g, 'ft')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalise(value) {
  // Unicode NFKD does not transliterate Ø, Ł, Æ or Œ. Without this,
  // IKØN and IKON score as entirely different artists during fallback.
  return legacyNormalise(String(value ?? '')
    .replace(/[Øø]/g, 'o').replace(/[Łł]/g, 'l')
    .replace(/[ĐđÐð]/g, 'd').replace(/[Ææ]/g, 'ae')
    .replace(/[Œœ]/g, 'oe').replace(/ß/g, 'ss')
    .replace(/[Þþ]/g, 'th'));
}

function tokens(s) {
  return new Set(normalise(s).split(' ').filter(Boolean));
}

function overlap(a, b) {
  const x = tokens(a);
  const y = tokens(b);
  if (!x.size || !y.size) return 0;
  const common = [...x].filter(word => y.has(word)).length;
  // Symmetric token similarity, forgiving extra title suffixes but not replacements.
  return 2 * common / (x.size + y.size);
}

function variantPenalty(titleA, titleB) {
  const labels = ['extended', 'radio', 'remix', 'edit', 'instrumental', 'acoustic', 'live', 'vip', 'dub'];
  const a = tokens(titleA);
  const b = tokens(titleB);
  let mismatches = 0;
  for (const term of labels) {
    if (a.has(term) !== b.has(term)) mismatches += 1;
  }
  return Math.min(24, mismatches * 12);
}

// Providers frequently omit the harmless '(Original Mix)' label. Do not
// strip other mix labels or remixer credits when comparing recording titles.
function stripOriginalMixSuffix(value) {
  return String(value || '').replace(/\s*(?:\(original mix\)|[-–—]\s*original mix)\s*$/i, '').trim();
}

// Classify evidence without confusing catalogue text similarity with an actual
// recording identity. Strong Spotify-ID/ISRC agreement is handled separately.
function comparableVersion(title) {
  const tags = variantTags(title).split('|').filter(Boolean);
  return {
    // Some services omit the words "Original Mix" from the same release.
    tags: tags.filter(tag => tag !== 'original').sort().join('|'),
    fullTitle: normalise(title),
    hasSpecificMix: tags.some(tag => ['remix','rework','bootleg','vip','edit','mixed','live','instrumental','acoustic'].includes(tag))
  };
}

function catalogueAssessment(title, artist, candidates) {
  const first = candidates?.[0];
  if (!first) return { confident: false, reasons: ['No catalogue recordings found.'], reasonCode: 'not-found' };
  const runnerUp = candidates[1];
  const sourceVersion = comparableVersion(title);
  const candidateVersion = comparableVersion(first.title);
  const sameVersion = sourceVersion.tags === candidateVersion.tags &&
    (!(sourceVersion.hasSpecificMix || candidateVersion.hasSpecificMix) || sourceVersion.fullTitle === candidateVersion.fullTitle);
  // An unlabelled title and its explicit '(Original Mix)' variant may be
  // compared on the same base title without merging their ISRCs.
  const titleMatch = normalise(stripOriginalMixSuffix(title)) === normalise(stripOriginalMixSuffix(first.title))
    ? 1 : overlap(stripOriginalMixSuffix(title), stripOriginalMixSuffix(first.title));
  const artistMatch = normalise(artist) === normalise(first.artist) ? 1 : overlap(artist, first.artist);
  const closeRivals = candidates.filter(row => row.isrc !== first.isrc && row.score >= first.score - 6);
  const lead = !runnerUp || first.score - runnerUp.score >= 7;
  const reasons = [];
  if (!sameVersion) reasons.push('Mix or remix version differs from the playing track.');
  if (titleMatch < .85) reasons.push('Catalogue title differs from the displayed track.');
  if (artistMatch < .65) reasons.push('Artist credits do not agree closely enough.');
  if (first.score < 78) reasons.push('Catalogue metadata similarity is below the automatic threshold.');
  if (closeRivals.length) reasons.push(`${closeRivals.length + 1} plausible recordings have different ISRCs and similar metadata scores.`);
  if (!lead && !closeRivals.length) reasons.push('No clearly preferred catalogue recording.');
  const confident = sameVersion && titleMatch >= .85 && artistMatch >= .65 &&
    first.score >= 78 && lead && !closeRivals.length;
  const reasonCode = !sameVersion ? 'mix-variant'
    : titleMatch < .85 ? 'title-difference'
    : artistMatch < .65 ? 'artist-difference'
    : closeRivals.length ? 'competing-isrcs'
    : first.score < 78 ? 'low-similarity' : !lead ? 'no-clear-lead' : 'matched';
  return { confident, reasons, reasonCode, highestScore: first.score };
}

function candidateScore(candidate, title, artist) {
  const baseTitle = stripOriginalMixSuffix(title);
  const baseCandidateTitle = stripOriginalMixSuffix(candidate.title);
  const titleNorm = normalise(baseTitle);
  const candidateNorm = normalise(baseCandidateTitle);
  const artistNorm = normalise(artist);
  const candidateArtistNorm = normalise(candidate.artist);
  const titleMatch = titleNorm === candidateNorm ? 1 : overlap(baseTitle, baseCandidateTitle);
  const artistMatch = artistNorm === candidateArtistNorm ? 1 : overlap(artist, candidate.artist);
  return Math.max(0, Math.min(100, Math.round(
    titleMatch * 68 + artistMatch * 32 - variantPenalty(title, candidate.title)
  )));
}

function cacheId(title, artist) {
  // Do not silently invalidate all the user's v0.1–v0.6.5 matches.
  return `${legacyNormalise(title)}::${legacyNormalise(artist)}`;
}

function recordingRef(track) {
  const isrc = String(track?.isrc || '').toUpperCase();
  if (ISRC_RE.test(isrc)) return `isrc:${isrc}`;
  if (/^[a-f0-9-]{36}$/i.test(track?.reccoId || '')) return `recco:${track.reccoId}`;
  if (SPOTIFY_ID_RE.test(track?.spotifyId || '')) return `spotify:${track.spotifyId}`;
  return null;
}

function equivalentIdentity(a, b) {
  if (!a || !b) return false;
  return normalise(a.title) === normalise(b.title) &&
    normalise(a.artist) === normalise(b.artist) &&
    variantTags(a.title) === variantTags(b.title);
}

// Old cache IDs are retained. Searching by a safer Unicode-aware identity
// reuses known matches for IKØN/IKON and cross-platform credits without
// treating two different remix versions as equivalent.
async function equivalentCachedTrack(title, artist) {
  const entries = Object.entries(await loadCache());
  const matches = entries.filter(([, entry]) => entry?.value?.status === 'ok' &&
    equivalentIdentity({ title, artist }, entry.value.track) &&
    Date.now() - entry.savedAt < CACHE_TTL_MS);
  const recordings = new Set(matches.map(([, entry]) => recordingRef(entry.value.track) ||
    `${entry.value.track?.title}:${entry.value.track?.artist}`));
  return matches.length && recordings.size === 1 ? matches[0][1].value : null;
}

async function loadCache() {
  const data = await chrome.storage.local.get(CACHE_KEY);
  return data[CACHE_KEY] || {};
}

async function fromCache(key) {
  const cache = await loadCache();
  const entry = cache[key];
  if (!entry) return null;
  const ttl = entry.value?.status === 'not_found' ? NOT_FOUND_TTL_MS : CACHE_TTL_MS;
  return Date.now() - entry.savedAt < ttl ? entry.value : null;
}

async function putCache(key, value) {
  const cache = await loadCache();
  cache[key] = { savedAt: Date.now(), value };
  const ordered = Object.entries(cache)
    .sort((a, b) => b[1].savedAt - a[1].savedAt)
    .slice(0, MAX_CACHE_ENTRIES);
  await chrome.storage.local.set({ [CACHE_KEY]: Object.fromEntries(ordered) });
}

function shapeCandidate(candidate, title, artist) {
  return {
    isrc: candidate.isrc,
    title: candidate.title || '',
    artist: candidate.artist || '',
    album: candidate.album || '',
    durationMs: Number(candidate.durationMs) || null,
    score: candidateScore(candidate, title, artist)
  };
}

async function searchCandidates(query, title, artist) {
  const response = await fetchJson(`/api/track/search?q=${encodeURIComponent(query)}`);
  if (!Array.isArray(response)) throw new Error('Unexpected results from Song Finder search.');
  const unique = new Set();
  return response.filter(item => {
    if (!item || !ISRC_RE.test(item.isrc || '')) return false;
    const isrc = item.isrc.toUpperCase();
    if (unique.has(isrc)) return false;
    unique.add(isrc);
    return true;
  }).map(item => shapeCandidate(item, title, artist))
    .sort((a, b) => b.score - a.score)
    .slice(0, 10);
}

async function getDetail(isrc) {
  if (!ISRC_RE.test(isrc)) throw new Error('The selected track has an invalid ISRC.');
  const detail = await fetchJson(`/api/track/detail?isrc=${encodeURIComponent(isrc)}`);
  if (!detail?.track) throw new Error('Song Finder returned incomplete track details.');
  return detail;
}

// ReccoBeats is used ONLY when Song Finder has matched a recording but has
// missing acoustic features. Search metadata is verified before any analysis
// is accepted. No audio is uploaded and no API key is used.
const RECCO_MIN_SPACING_MS = 1200;
const RECCO_TIMEOUT_MS = 12000;
const RECCO_CAMELOT_MAJOR = ['8B', '3B', '10B', '5B', '12B', '7B', '2B', '9B', '4B', '11B', '6B', '1B'];
const RECCO_CAMELOT_MINOR = ['5A', '12A', '7A', '2A', '9A', '4A', '11A', '6A', '1A', '8A', '3A', '10A'];
const RECCO_PITCH_NAMES = ['C', 'C♯', 'D', 'E♭', 'E', 'F', 'F♯', 'G', 'A♭', 'A', 'B♭', 'B'];

async function fetchReccoJson(path) {
  // Prevent accidental third-party calls outside the documented API paths.
  if (!/^\/(?:track\/search\?|track\?ids=[A-Za-z0-9]{22}$|track\/[a-f0-9-]{36}\/audio-features$)/i.test(path)) {
    throw new Error('Unsupported ReccoBeats request.');
  }
  const task = reccoQueue.catch(() => {}).then(async () => {
    const delay = Math.max(0, RECCO_MIN_SPACING_MS - (Date.now() - lastReccoRequestStart));
    if (delay) await wait(delay);
    lastReccoRequestStart = Date.now();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), RECCO_TIMEOUT_MS);
    try {
      const response = await fetch(`${RECCO_BASE}${path}`, {
        method: 'GET', headers: { Accept: 'application/json' },
        signal: controller.signal, cache: 'no-store'
      });
      if (response.status === 429) {
        // Honour Retry-After without holding the service worker open for a long retry.
        const after = response.headers?.get('Retry-After');
        const seconds = Number(after);
        const error = new Error('ReccoBeats rate limited this lookup.');
        error.retryAfterMs = Number.isFinite(seconds) && seconds >= 0
          ? Math.min(60000, seconds * 1000) : 30000;
        throw error;
      }
      if (response.status === 404) return null;
      if (!response.ok) throw new Error(`ReccoBeats returned HTTP ${response.status}.`);
      return await response.json();
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error('ReccoBeats request timed out.');
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  });
  reccoQueue = task.catch(() => {});
  return task;
}

function reccoTrack(row) {
  if (!row || typeof row !== 'object') return null;
  const id = String(row.id || '');
  const title = String(row.trackTitle || row.title || '').trim();
  const artist = (Array.isArray(row.artists) ? row.artists : [])
    .map(item => typeof item === 'string' ? item : item?.name)
    .filter(Boolean).join(', ');
  const isrc = String(row.isrc || '').trim().toUpperCase();
  if (!/^[a-f0-9-]{36}$/i.test(id) || !title || !artist) return null;
  return { id, title, artist, isrc, durationMs: Number(row.durationMs) || null };
}

function variantTags(value) {
  const terms = ['original', 'extended', 'radio', 'remix', 'edit', 'live', 'vip', 'dub', 'instrumental', 'acoustic', 'mixed', 'rework', 'bootleg'];
  const found = tokens(value);
  return terms.filter(term => found.has(term)).join('|');
}

function reccoConfidence(candidate, track, expectedDurationMs) {
  // An exact ISRC stays authoritative; this preserves working matches.
  const expectedIsrc = String(track?.isrc || '').trim().toUpperCase();
  const bothIsrcs = ISRC_RE.test(expectedIsrc) && ISRC_RE.test(candidate.isrc);
  if (bothIsrcs && expectedIsrc === candidate.isrc) {
    return { accepted: true, reviewable: false, exactIsrc: true, score: 100, reason: null };
  }
  // Normalise a missing/explicit "Original Mix" suffix, but do not collapse
  // Extended, Radio, Remix, Edit, Live, VIP, Dub or Instrumental variants.
  const baseTitle = value => String(value || '').replace(/\s*(?:\(original mix\)|[-–—]\s*original mix)\s*$/i, '').trim();
  const mainTitle = baseTitle(track?.title);
  const optionTitle = baseTitle(candidate.title);
  const coreVariants = value => variantTags(value).split('|').filter(tag => tag && tag !== 'original').join('|');
  const sameVariant = coreVariants(track?.title) === coreVariants(candidate.title);
  const sameTitle = normalise(mainTitle) === normalise(optionTitle);
  const closeTitle = overlap(mainTitle, optionTitle) >= .94;
  const sameArtist = overlap(track?.artist, candidate.artist) >= .78;
  const score = candidateScore({ ...candidate, title: optionTitle }, mainTitle, track?.artist);
  const durationKnown = Number.isFinite(expectedDurationMs) && expectedDurationMs > 0 &&
    Number.isFinite(candidate.durationMs) && candidate.durationMs > 0;
  const durationOk = !durationKnown || Math.abs(expectedDurationMs - candidate.durationMs) <= 20000;
  const reason = !sameVariant ? 'mix variant'
    : !sameTitle && !closeTitle ? 'title mismatch'
    : !sameArtist ? 'artist mismatch'
    : !durationOk ? 'duration mismatch'
    : score < 90 ? 'low confidence' : null;
  if (reason) return { accepted: false, reviewable: false, exactIsrc: false, score, reason };
  if (bothIsrcs && expectedIsrc !== candidate.isrc) {
    // An alternate release can have a different ISRC, but never auto-select it.
    // Only offer a manually confirmed recording if title, artist, mix and
    // available duration metadata passed their checks above.
    return { accepted: false, reviewable: true, exactIsrc: false, score, reason: 'ISRC differs' };
  }
  return { accepted: true, reviewable: false, exactIsrc: bothIsrcs, score, reason: null };
}
const SPOTIFY_ID_RE = /^[A-Za-z0-9]{22}$/;
function reccoRows(json) {
  return (Array.isArray(json) ? json : Array.isArray(json?.content) ? json.content : [])
    .map(reccoTrack).filter(Boolean);
}

function isSpotifyIdCandidate(row, song, displayed) {
  // The ID came from the NOW PLAYING track link (not a Radio or Queue row).
  // Cross-check its title/artist against the visible player and the Song
  // Finder recording before accepting any acoustic values.
  const played = displayed?.title && displayed?.artist ? displayed : song;
  // Some providers append '(Original Mix)' even when the Spotify title
  // displays only the base name. This is safe with a confirmed Spotify ID;
  // explicit remixes/extended versions are still checked below.
  const originalBase = String(row.title).replace(/\s*(?:\(original mix\)|[-–—]\s*original mix)\s*$/i, '');
  const titleSame = normalise(row.title) === normalise(played.title) ||
    normalise(originalBase) === normalise(played.title);
  const titleClose = overlap(row.title, played.title) >= 0.72;
  const artistClose = overlap(row.artist, played.artist) >= 0.60;
  if ((!titleSame && !titleClose) || !artistClose) return false;
  // An explicit Remix, Extended or Live mix must never be silently replaced
  // by a different mix. An unlabelled player title may omit 'Original Mix'.
  const expectedTags = variantTags(played.title).split('|').filter(Boolean);
  const actualTags = variantTags(row.title).split('|').filter(Boolean);
  const critical = ['remix', 'extended', 'radio', 'edit', 'live', 'vip', 'dub', 'instrumental', 'acoustic', 'rework', 'bootleg', 'mixed'];
  if (critical.some(tag => expectedTags.includes(tag) !== actualTags.includes(tag))) return false;
  if (expectedTags.includes('original') && !actualTags.includes('original') && actualTags.length) return false;
  const expectedVersion = comparableVersion(played.title);
  const actualVersion = comparableVersion(row.title);
  if ((expectedVersion.hasSpecificMix || actualVersion.hasSpecificMix) &&
      expectedVersion.fullTitle !== actualVersion.fullTitle) return false;
  return true;
}

async function findReccoTrack(song, context = {}) {
  const diagnostics = { spotifyIdLookup: 'not_available', searchRows: 0, validCandidates: 0, rejected: {} };
  const spotifyId = String(context.spotifyId || '').trim();
  if (SPOTIFY_ID_RE.test(spotifyId)) {
    // ReccoBeats explicitly supports Spotify IDs via /track?ids=.
    // This avoids a title-only search for generic names like 'Jupiter'.
    try {
      const direct = reccoRows(await fetchReccoJson(`/track?ids=${spotifyId}`));
      diagnostics.spotifyIdLookup = direct.length ? 'returned' : 'not_found';
      const matched = direct.find(row => isSpotifyIdCandidate(row, song, context.displayed));
      if (matched) {
        const expectedIsrc = String(song.isrc || '').toUpperCase();
        const isrcConflict = ISRC_RE.test(expectedIsrc) && ISRC_RE.test(matched.isrc) && expectedIsrc !== matched.isrc;
        return { row: matched, method: 'spotify_id', isrcConflict, diagnostics };
      }
      if (direct.length) diagnostics.spotifyIdLookup = 'metadata_mismatch';
    } catch (error) {
      diagnostics.spotifyIdLookup = 'error';
      diagnostics.spotifyIdError = String(error?.message || 'ID lookup failed').slice(0, 120);
      // Continue with the usual catalogue search when direct ID lookup fails.
    }
  }

  const title = String(song.title || '').trim();
  if (!title) return { row: null, method: 'search', isrcConflict: false, diagnostics };
  const artist = String(song.artist || '').trim();
  // An artist-qualified search may reach beyond the first page for generic
  // titles. The title-only query is retained as a second chance.
  const queries = [...new Set([`${artist} ${title}`.trim(), title].filter(Boolean))];
  const expectedDuration = Number(song.durationMs) || null;
  const reviewMap = new Map();
  for (const query of queries) {
    const rows = reccoRows(await fetchReccoJson(`/track/search?searchText=${encodeURIComponent(query)}&page=0&size=30`));
    diagnostics.searchRows += rows.length;
    const classified = rows.map(row => ({ row, ...reccoConfidence(row, song, expectedDuration) }));
    for (const item of classified) {
      if (!item.accepted) {
        const reason = item.reason || 'other';
        diagnostics.rejected[reason] = (diagnostics.rejected[reason] || 0) + 1;
      }
      if (item.reviewable && !reviewMap.has(item.row.id)) {
        reviewMap.set(item.row.id, { ...item.row, score: item.score });
      }
    }
    const scored = classified.filter(item => item.accepted).sort((a, b) =>
      (Number(b.exactIsrc) - Number(a.exactIsrc)) || b.score - a.score);
    diagnostics.validCandidates += scored.length;
    if (!scored.length) continue;
    // Do not pick between similarly named but different releases if we lack ISRC.
    if (!scored[0].exactIsrc && scored[1] && scored[1].score >= scored[0].score - 2 &&
        scored[0].row.isrc !== scored[1].row.isrc) {
      diagnostics.ambiguous = true;
      break;
    }
    return { row: scored[0].row, method: 'search', isrcConflict: false, diagnostics };
  }
  const alternatives = [...reviewMap.values()].sort((a, b) => b.score - a.score).slice(0, 6);
  diagnostics.reviewableCandidates = alternatives.length;
  return { row: null, alternatives, method: 'search', isrcConflict: false, diagnostics };
}

// For an ambiguous/missing Song Finder catalogue match, the current Spotify
// track ID offers a recording-level second chance. The ID comes from the
// NOW PLAYING widget, never an arbitrary Queue/Radio suggestion.
// Song Finder remains preferred when the ID identifies one of its candidates.
async function resolveWithSpotifyId(title, artist, spotifyId, candidates = []) {
  if (!SPOTIFY_ID_RE.test(spotifyId || '')) return null;
  const direct = reccoRows(await fetchReccoJson(`/track?ids=${spotifyId}`));
  const matched = direct.filter(row => isSpotifyIdCandidate(row,
    { title, artist }, { title, artist }));
  if (matched.length !== 1) return null;
  const row = matched[0];
  const candidate = ISRC_RE.test(row.isrc) ? candidates.find(item => item.isrc.toUpperCase() === row.isrc) : null;
  // An ISRC supplied by the Spotify-ID lookup may exist in Song Finder even
  // when its title search didn't include that recording in the top 10.
  // Consult that exact ISRC, and verify its metadata before preferring it.
  if (candidate || ISRC_RE.test(row.isrc)) {
    const details = await getDetail(candidate?.isrc || row.isrc).catch(() => null);
    if (details?.track && isSpotifyIdCandidate(details.track, { title, artist }, { title, artist })) {
      const selected = resultFromDetail(details, candidates);
      selected.matchMethod = 'spotify_id';
      selected.matchConfidence = 'linked-recording';
      return fillFromRecco(selected, false, { spotifyId, displayed: { title, artist } });
    }
  }
  const raw = await fetchReccoJson(`/track/${row.id}/audio-features`);
  const features = reccoFeatures(raw);
  if (!features || !CORE_FEATURES.some(field => presentFeature(features, field))) return null;
  const result = {
    status: 'ok', analysisSource: 'reccobeats',
    track: { isrc: ISRC_RE.test(row.isrc) ? row.isrc : null,
      reccoId: row.id, spotifyId, title: row.title, artist: row.artist,
      album: '', durationMs: row.durationMs },
    features, featureSources: Object.fromEntries(CORE_FEATURES
      .filter(field => presentFeature(features, field)).map(field => [field, 'reccobeats'])),
    candidates, matchMethod: 'spotify_id', matchConfidence: 'linked-recording',
    fallbackMethod: 'spotify_id', fallbackStatus: 'used', fallbackAttemptedAt: Date.now(),
    fallbackSpotifyId: spotifyId
  };
  return result;
}

function fraction(value) {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1 ? value : null;
}

function keyFromRecco(rawKey, rawMode) {
  if (rawKey === null || rawKey === undefined || rawKey === '' || rawMode === null || rawMode === undefined || rawMode === '') return null;
  const pitch = Number(rawKey);
  const mode = Number(rawMode);
  if (!Number.isInteger(pitch) || pitch < 0 || pitch > 11 || (mode !== 0 && mode !== 1)) return null;
  const camelot = (mode ? RECCO_CAMELOT_MAJOR : RECCO_CAMELOT_MINOR)[pitch];
  return {
    pitchClass: pitch, mode,
    name: `${RECCO_PITCH_NAMES[pitch]} ${mode ? 'Major' : 'Minor'}`,
    camelot, openKey: null, compatible: [...camelotNeighbours(camelot)]
  };
}

function reccoFeatures(raw) {
  const row = raw?.audio_features || raw?.audioFeatures || raw;
  if (!row || typeof row !== 'object') return null;
  const tempo = Number(row.tempo);
  return {
    tempo: typeof row.tempo === 'number' && Number.isFinite(tempo) && tempo > 0 && tempo <= 350 ? tempo : null,
    key: keyFromRecco(row.key, row.mode),
    energy: fraction(row.energy), danceability: fraction(row.danceability),
    valence: fraction(row.valence), acousticness: fraction(row.acousticness),
    instrumentalness: fraction(row.instrumentalness), liveness: fraction(row.liveness),
    speechiness: fraction(row.speechiness),
    loudness: typeof row.loudness === 'number' && Number.isFinite(row.loudness) ? row.loudness : null,
    tempoSource: 'ReccoBeats'
  };
}

function presentFeature(features, field) {
  const value = features?.[field];
  if (field === 'key') return typeof value?.camelot === 'string' && camelotNeighbours(value.camelot).size > 0;
  if (field === 'tempo') return typeof value === 'number' && Number.isFinite(value) && value > 0;
  if (field === 'loudness') return typeof value === 'number' && Number.isFinite(value);
  return fraction(value) !== null;
}

const CORE_FEATURES = ['tempo', 'key', 'energy', 'danceability'];
const EXTRA_FEATURES = ['valence', 'acousticness', 'instrumentalness', 'liveness', 'speechiness', 'loudness'];
function missingCore(features) { return CORE_FEATURES.some(field => !presentFeature(features, field)); }

async function fillFromRecco(result, force = false, context = {}) {
  if (result?.status !== 'ok' || !result.track || !missingCore(result.features)) return result;
  const spotifyId = SPOTIFY_ID_RE.test(context.spotifyId || '') ? context.spotifyId : '';
  const newlyAvailableSpotifyId = spotifyId && result.fallbackSpotifyId !== spotifyId;
  if (!force && !newlyAvailableSpotifyId && result.fallbackAttemptedAt &&
      Date.now() - result.fallbackAttemptedAt < RECCO_RETRY_TTL_MS) return result;
  const updated = { ...result, fallbackAttemptedAt: Date.now() };
  if (spotifyId) updated.fallbackSpotifyId = spotifyId;
  try {
    const match = await findReccoTrack(updated.track, context);
    updated.fallbackDiagnostics = match.diagnostics;
    updated.fallbackAlternatives = Array.isArray(match.alternatives) ? match.alternatives : [];
    if (!match.row) {
      updated.fallbackStatus = updated.fallbackAlternatives.length ? 'review_required' : 'no_verified_match';
      return updated;
    }
    updated.fallbackAlternatives = [];
    updated.fallbackMethod = match.method;
    // Different ISRCs can signify different releases. If Song Finder has
    // any core analysis, never mix it with features from a conflicting ISRC.
    const primaryHasCore = CORE_FEATURES.some(field => presentFeature(updated.features, field));
    if (match.isrcConflict && primaryHasCore) {
      updated.fallbackStatus = 'isrc_conflict';
      return updated;
    }
    const raw = await fetchReccoJson(`/track/${match.row.id}/audio-features`);
    const supplement = reccoFeatures(raw);
    if (!supplement || !CORE_FEATURES.some(field => presentFeature(supplement, field))) {
      updated.fallbackStatus = 'no_features'; return updated;
    }
    const merged = { ...(updated.features || {}) };
    const sources = { ...(updated.featureSources || {}) };
    for (const field of [...CORE_FEATURES, ...EXTRA_FEATURES]) {
      if (!presentFeature(merged, field) && presentFeature(supplement, field)) {
        merged[field] = supplement[field];
        if (CORE_FEATURES.includes(field)) sources[field] = 'reccobeats';
      } else if (presentFeature(merged, field) && CORE_FEATURES.includes(field) && !sources[field]) {
        sources[field] = 'songfinder';
      }
    }
    updated.features = merged;
    updated.featureSources = sources;
    const chosen = new Set(CORE_FEATURES.filter(field => presentFeature(merged, field)).map(field => sources[field] || 'songfinder'));
    updated.analysisSource = chosen.size === 2 ? 'mixed'
      : chosen.has('reccobeats') ? 'reccobeats' : 'songfinder';
    if (match.isrcConflict) updated.recordingIdWarning = true;
    updated.fallbackStatus = 'used';
    return updated;
  } catch (error) {
    // Song Finder metadata remains usable even if the secondary provider fails.
    updated.fallbackStatus = 'unavailable';
    updated.fallbackError = String(error?.message || 'ReccoBeats unavailable').slice(0, 160);
    return updated;
  }
}

// An explicitly supplied value belongs to the playing recording only. It is
// stored separately from provider responses so Refresh cannot erase it.
function userCamelotKey(code) {
  const match = /^([1-9]|1[0-2])([AB])$/.exec(String(code || '').trim().toUpperCase());
  if (!match) return null;
  const camelot = `${Number(match[1])}${match[2]}`;
  const mode = match[2] === 'B' ? 1 : 0;
  const pitch = (mode ? RECCO_CAMELOT_MAJOR : RECCO_CAMELOT_MINOR).indexOf(camelot);
  if (pitch < 0) return null;
  return { pitchClass: pitch, mode, name: `${RECCO_PITCH_NAMES[pitch]} ${mode ? 'Major' : 'Minor'}`,
    camelot, openKey: null, compatible: [...camelotNeighbours(camelot)] };
}

function validateUserMetrics(raw) {
  if (!raw || typeof raw !== 'object') throw new Error('Enter at least one acoustic metric.');
  const output = {};
  for (const field of ['tempo','energy','danceability']) {
    const value = raw[field];
    if (value === undefined || value === null || String(value).trim() === '') continue;
    if (typeof value !== 'string' && typeof value !== 'number') throw new Error(`Invalid ${field}.`);
    const number = Number(value);
    const low = field === 'tempo' ? 40 : 0;
    const high = field === 'tempo' ? 250 : 100;
    if (!Number.isFinite(number) || number < low || number > high) {
      throw new Error(`${field === 'tempo' ? 'BPM' : field} must be between ${low} and ${high}.`);
    }
    output[field] = field === 'tempo' ? number : number / 100;
  }
  if (raw.camelot !== undefined && raw.camelot !== null && String(raw.camelot).trim() !== '') {
    const key = userCamelotKey(raw.camelot);
    if (!key) throw new Error('Camelot must be 1A–12A or 1B–12B, for example 3B.');
    output.key = key;
  }
  if (!Object.keys(output).length) throw new Error('Enter at least one metric before saving.');
  return output;
}

function analysisOrigin(sources) {
  const selected = new Set(CORE_FEATURES.map(field => sources?.[field]).filter(Boolean));
  if (selected.has('manual')) return selected.size === 1 ? 'manual' : 'mixed_manual';
  return selected.size === 2 ? 'mixed' : selected.has('reccobeats') ? 'reccobeats' : 'songfinder';
}

function applyUserValues(result, values, label) {
  if (result?.status !== 'ok' || !recordingRef(result.track)) return result;
  const updated = { ...result, features: { ...(result.features || {}) }, featureSources: { ...(result.featureSources || {}) } };
  let applied = 0;
  for (const field of CORE_FEATURES) {
    if (!(field in values)) continue;
    if (presentFeature(updated.features, field) && updated.featureSources[field] !== 'manual') continue;
    updated.features[field] = values[field];
    updated.featureSources[field] = 'manual';
    applied += 1;
  }
  if (applied) {
    updated.analysisSource = analysisOrigin(updated.featureSources);
    updated.manualMetricsSource = String(label || 'Personal reference').slice(0, 80);
    updated.manualMetricsApplied = true;
  }
  return updated;
}

async function manualValuesStore() {
  const data = await chrome.storage.local.get(MANUAL_VALUES_KEY);
  return data[MANUAL_VALUES_KEY] || {};
}

async function applyStoredUserValues(result, key) {
  if (result?.status !== 'ok') return result;
  const stored = (await manualValuesStore())[key];
  if (!stored || (stored.recordingRef || (stored.isrc ? `isrc:${stored.isrc}` : null)) !== recordingRef(result.track)) return result;
  return applyUserValues(result, stored.values || {}, stored.source || 'Personal reference');
}

async function saveUserMetrics(title, artist, raw, source) {
  const key = cacheId(title, artist);
  const result = await fromCache(key);
  if (result?.status !== 'ok' || !recordingRef(result.track)) {
    throw new Error('Choose a verified recording before entering manual metrics.');
  }
  const values = validateUserMetrics(raw);
  const previous = (await manualValuesStore())[key];
  const saved = (previous?.recordingRef || (previous?.isrc ? `isrc:${previous.isrc}` : null)) === recordingRef(result.track) ? { ...previous.values, ...values } : values;
  const label = String(source || previous?.source || 'Personal reference').trim().replace(/[<>]/g,'').slice(0,80);
  const updated = applyUserValues(result, saved, label);
  const store = await manualValuesStore();
  store[key] = { isrc: result.track.isrc || null, recordingRef: recordingRef(result.track), values: saved, source: label, savedAt: Date.now() };
  await chrome.storage.local.set({ [MANUAL_VALUES_KEY]: store });
  await putCache(key, updated);
  return updated;
}

async function clearUserMetrics(title, artist) {
  const key = cacheId(title, artist);
  const store = await manualValuesStore();
  delete store[key];
  await chrome.storage.local.set({ [MANUAL_VALUES_KEY]: store });
  const existing = await fromCache(key);
  if (existing?.status !== 'ok') throw new Error('No analysed recording found.');
  const updated = { ...existing, features: { ...(existing.features || {}) }, featureSources: { ...(existing.featureSources || {}) } };
  for (const field of CORE_FEATURES) {
    if (updated.featureSources[field] === 'manual') {
      delete updated.features[field];
      delete updated.featureSources[field];
    }
  }
  updated.analysisSource = analysisOrigin(updated.featureSources);
  delete updated.manualMetricsSource;
  delete updated.manualMetricsApplied;
  await putCache(key, updated);
  return updated;
}

function featureSourceMap(data) {
  if (!data || data.status !== 'ok') return {};
  const defined = data.featureSources || {};
  const source = data.analysisSource === 'reccobeats' ? 'reccobeats'
    : data.analysisSource === 'manual' ? 'manual' : 'songfinder';
  return Object.fromEntries(CORE_FEATURES.map(field => [field,
    presentFeature(data.features, field) ? (defined[field] || source) : null]));
}

function resultFromDetail(detail, candidates, manual = false) {
  return {
    status: 'ok',
    analysisSource: 'songfinder',
    track: {
      isrc: detail.track.isrc,
      title: detail.track.title,
      artist: detail.track.artist,
      album: detail.track.album || '',
      durationMs: detail.track.durationMs ?? null
    },
    features: detail.features || null,
    featureSources: Object.fromEntries(CORE_FEATURES.filter(field => presentFeature(detail.features, field)).map(field => [field, 'songfinder'])),
    tempoCrossCheck: detail.tempoCrossCheck ?? null,
    candidates,
    manual
  };
}

async function lookup(title, artist, refresh, legacyTitle = '', legacyArtist = '', spotifyId = '') {
  if (!title || !artist) throw new Error('The current title or artist is missing.');
  const key = cacheId(title, artist);
  const fallbackContext = { spotifyId, displayed: { title, artist } };
  if (!refresh) {
    const cached = await fromCache(key);
    if (cached) {
      if (cached.status === 'ok' && missingCore(cached.features) &&
          (!cached.fallbackAttemptedAt || Date.now() - cached.fallbackAttemptedAt >= RECCO_RETRY_TTL_MS ||
           (SPOTIFY_ID_RE.test(spotifyId) && cached.fallbackSpotifyId !== spotifyId))) {
        if (pendingLookups.has(key)) return pendingLookups.get(key);
        const job = fillFromRecco(cached, false, fallbackContext).then(async updated => {
          updated = await applyStoredUserValues(updated, key);
          await putCache(key, updated);
          return { ...updated, cached: false };
        });
        pendingLookups.set(key, job);
        try { return await job; } finally { pendingLookups.delete(key); }
      }
    // Re-try cached uncertain matches when a NOW PLAYING Spotify ID becomes
    // available. A failed ID lookup is throttled for six hours.
    if (cached && (cached.status === 'choose' || cached.status === 'not_found') &&
        SPOTIFY_ID_RE.test(spotifyId) &&
        (cached.spotifyResolutionId !== spotifyId ||
         Date.now() - (cached.spotifyResolutionAttemptedAt || 0) > RECCO_RETRY_TTL_MS)) {
      const resolved = await resolveWithSpotifyId(title, artist, spotifyId, cached.candidates || [])
        .catch(() => null);
      const next = resolved || { ...cached, spotifyResolutionId: spotifyId,
        spotifyResolutionAttemptedAt: Date.now() };
      await putCache(key, next);
      return { ...next, cached: false };
    }
      return { ...cached, cached: true };
    }
    const alias = await equivalentCachedTrack(title, artist);
    if (alias) {
      const withManual = await applyStoredUserValues(alias, key);
      await putCache(key, withManual);
      return { ...withManual, cached: true };
    }
    // Preserve previously hand-picked recordings when upgrading from 0.3.
    // Old versions indexed video uploads by their channel/uploader label.
    if (legacyTitle && legacyArtist) {
      const legacyKey = cacheId(legacyTitle, legacyArtist);
      if (legacyKey !== key) {
        const old = await fromCache(legacyKey);
        if (old?.status === 'ok' && old.manual && ISRC_RE.test(old.track?.isrc || '')) {
          const upgraded = await fillFromRecco(old, false, fallbackContext);
          const withUser = await applyStoredUserValues(upgraded, key);
          await putCache(key, withUser);
          return { ...withUser, cached: withUser === old };
        }
      }
    }
  }
  if (pendingLookups.has(key)) return pendingLookups.get(key);
  const job = (async () => {
    const candidates = await searchCandidates(`${title} ${artist}`, title, artist);
    let result;
    if (!candidates.length) {
      result = { status: 'not_found', candidates: [] };
    } else {
      const first = candidates[0];
      const assessment = catalogueAssessment(title, artist, candidates);
      if (!assessment.confident) {
        result = { status: 'choose', candidates, reviewReason: assessment.reasons.join(' '),
          reviewCode: assessment.reasonCode };
      } else {
        const detail = await getDetail(first.isrc);
        result = await fillFromRecco(resultFromDetail(detail, candidates), refresh, fallbackContext);
      }
    }
    if (result.status === 'choose' || result.status === 'not_found') {
      const resolved = await resolveWithSpotifyId(title, artist, spotifyId, candidates)
        .catch(() => null);
      if (resolved) result = resolved;
      else if (SPOTIFY_ID_RE.test(spotifyId)) {
        result.spotifyResolutionId = spotifyId;
        result.spotifyResolutionAttemptedAt = Date.now();
      }
    }
    result = await applyStoredUserValues(result, key);
    await putCache(key, result);
    return result;
  })();
  pendingLookups.set(key, job);
  try {
    return await job;
  } finally {
    pendingLookups.delete(key);
  }
}

async function retryFallback(title, artist, spotifyId) {
  if (!SPOTIFY_ID_RE.test(spotifyId || '')) throw new Error('Enter a valid Spotify track link or 22-character track ID.');
  const key = cacheId(title, artist);
  const cached = await fromCache(key);
  if (cached?.status !== 'ok' || !cached.track || !ISRC_RE.test(cached.track.isrc || '')) {
    throw new Error('Select a catalogue recording before checking its Spotify link.');
  }
  const updated = await fillFromRecco(cached, true,
    { spotifyId, displayed: { title, artist } });
  await putCache(key, updated);
  return updated;
}

async function selectReccoFallback(title, artist, candidateId) {
  const key = cacheId(title, artist);
  const cached = await fromCache(key);
  if (cached?.status !== 'ok' || !cached.track) throw new Error('Analyse the playing track first.');
  const candidate = (cached.fallbackAlternatives || []).find(row => row.id === candidateId);
  if (!candidate) throw new Error('This ReccoBeats choice is no longer available. Refresh and try again.');
  // Only results that passed our title, artist, mix and duration safeguards
  // can be chosen. Their ISRC differs, so the choice must be explicit.
  if (!reccoConfidence(candidate, cached.track, cached.track.durationMs).reviewable) {
    throw new Error('This recording no longer passes the matching safeguards.');
  }
  const raw = await fetchReccoJson(`/track/${candidate.id}/audio-features`);
  const features = reccoFeatures(raw);
  if (!features || !CORE_FEATURES.some(field => presentFeature(features, field))) {
    throw new Error('This ReccoBeats recording has no acoustic features. Try another candidate.');
  }
  // Never silently combine primary and secondary values across ISRCs.
  // The user has explicitly selected ReccoBeats as the analysis source here.
  const updated = {
    ...cached, features, analysisSource: 'reccobeats',
    featureSources: Object.fromEntries(CORE_FEATURES.filter(field => presentFeature(features, field)).map(field => [field, 'reccobeats'])),
    fallbackMethod: 'manual_review', fallbackStatus: 'used', fallbackAttemptedAt: Date.now(),
    recordingIdWarning: true, manualFallbackSelection: {
      title: candidate.title, artist: candidate.artist, isrc: candidate.isrc,
      durationMs: candidate.durationMs, reccoId: candidate.id
    }, fallbackAlternatives: []
  };
  await putCache(key, updated);
  return updated;
}

async function manualDetail(title, artist, isrc, spotifyId = '') {
  const detail = await getDetail(isrc);
  const cached = await fromCache(cacheId(title, artist));
  const existingCandidates = cached?.candidates || [];
  const result = await fillFromRecco(resultFromDetail(detail, existingCandidates, true), true,
    { spotifyId, displayed: { title, artist } });
  const withUser = await applyStoredUserValues(result, cacheId(title, artist));
  await putCache(cacheId(title, artist), withUser);
  return withUser;
}

async function manualSearch(title, artist, query) {
  if (!query || query.length > 240) throw new Error('Enter a shorter search query.');
  const candidates = await searchCandidates(query, title, artist);
  const result = {
    status: candidates.length ? 'choose' : 'not_found',
    candidates,
    manual: true
  };
  // Save these candidates so the user's manual choice and subsequent edits
  // refer to the new search rather than the original automatic results.
  await putCache(cacheId(title, artist), result);
  return result;
}

// Camelot mixing rules are shared by every platform. Mix Next candidate
// discovery is delegated to the current streaming-service adapter.
function camelotNeighbours(key) {
  const match = /^([1-9]|1[0-2])([AB])$/i.exec(String(key || '').trim());
  if (!match) return new Set();
  const number = Number(match[1]);
  const mode = match[2].toUpperCase();
  return new Set([
    `${number}${mode}`,
    `${number}${mode === 'A' ? 'B' : 'A'}`,
    `${number === 1 ? 12 : number - 1}${mode}`,
    `${number === 12 ? 1 : number + 1}${mode}`
  ]);
}

function cleanSuggestion(track, features, analysisSource = null) {
  if (!track || !String(track.title || '').trim() || !String(track.artist || '').trim()) return null;
  const rawIsrc = String(track.isrc || '').trim().toUpperCase();
  const camelot = String(features?.key?.camelot || '').trim().toUpperCase();
  return {
    isrc: ISRC_RE.test(rawIsrc) ? rawIsrc : null,
    title: String(track.title).trim(),
    artist: String(track.artist).trim(),
    camelot: camelotNeighbours(camelot).size ? camelot : null,
    bpm: typeof features?.tempo === 'number' && Number.isFinite(features.tempo) ? features.tempo : null,
    energy: typeof features?.energy === 'number' && Number.isFinite(features.energy) ? features.energy : null,
    danceability: typeof features?.danceability === 'number' && Number.isFinite(features.danceability) ? features.danceability : null,
    analysisSource
  };
}

function suggestionId(track) {
  return `${normalise(track.title)}::${normalise(track.artist)}`;
}

function tempoDistance(a, b) {
  if (!Number.isFinite(a) || !Number.isFinite(b)) return 999;
  return Math.min(Math.abs(a - b), Math.abs(a * 2 - b), Math.abs(a - b * 2));
}

// Local fallback and shared library: old analyses remain available even when
// YouTube Music does not expose any usable recommendations.
async function knownTracksFromCache(seed, allowed) {
  const cache = await loadCache();
  const records = Object.values(cache).map(entry => entry?.value).filter(value => value?.status === 'ok');
  const origin = records.find(value => String(value.track?.isrc || '').toUpperCase() === seed.isrc ||
    (seed.identity && suggestionId(value.track || {}) === seed.identity));
  const seedTempo = origin?.features?.tempo;
  const seedEnergy = origin?.features?.energy;
  const seen = new Set();
  const matches = [];
  for (const data of records) {
    const track = cleanSuggestion(data.track, data.features, data.analysisSource);
    if (!track || !track.camelot || !allowed.has(track.camelot) ||
        (track.isrc && track.isrc === seed.isrc) ||
        (seed.identity && suggestionId(track) === seed.identity) || seen.has(suggestionId(track))) continue;
    seen.add(suggestionId(track));
    const bpmGap = tempoDistance(seedTempo, track.bpm);
    const energyGap = Number.isFinite(seedEnergy) && Number.isFinite(track.energy)
      ? Math.abs(seedEnergy - track.energy) * 100 : 50;
    matches.push({ track, sort: bpmGap + energyGap / 3 });
  }
  return matches.sort((a, b) => a.sort - b.sort).slice(0, 5).map(({ track }) => track);
}

// A discovery lookup must not silently discard promising but ambiguous
// catalogue results. Return safe, scored alternatives for *explicit* review:
// only a user's confirmation may cache an uncertain ISRC for future scans.
async function reviewCandidates(result) {
  const existing = Object.values(await loadCache()).map(entry => entry?.value)
    .filter(value => value?.status === 'ok' && ISRC_RE.test(value.track?.isrc || ''));
  const cacheByIsrc = new Map(existing.map(value => [value.track.isrc.toUpperCase(), value]));
  return (Array.isArray(result?.candidates) ? result.candidates : [])
    .filter(candidate => ISRC_RE.test(candidate?.isrc || ''))
    .slice(0, 5)
    .map(candidate => {
      const cached = cacheByIsrc.get(candidate.isrc.toUpperCase());
      const hasKey = Boolean(cached?.features?.key?.camelot);
      const knownMissing = Boolean(cached && !hasKey);
      return {
        isrc: candidate.isrc, title: candidate.title, artist: candidate.artist,
        album: candidate.album || '', score: Number(candidate.score) || 0,
        keyAvailability: hasKey ? 'cached-key' : knownMissing ? 'cached-no-key' : 'unchecked'
      };
    });
}

// Shared across YouTube Music and Spotify: identical lookup, review and cache.
async function analyseDiscoveryCandidate(title, artist, spotifyId = '', refresh = false) {
  const result = await lookup(title, artist, refresh, '', '', spotifyId);
  const cached = Boolean(result?.cached);
  if (result?.status === 'choose') {
    const assessment = catalogueAssessment(title, artist, result.candidates || []);
    return { status: 'ambiguous', candidates: await reviewCandidates(result), cached,
      reviewReason: result.reviewReason || assessment.reasons.join(' ') || 'Recording identity needs confirmation.',
      reviewCode: result.reviewCode || assessment.reasonCode };
  }
  if (result?.status !== 'ok' || !result.track) {
    return { status: 'not_found', cached };
  }
  const confidence = candidateScore(result.track, title, artist);
  // A genuine linked Spotify track ID is stronger identity evidence than our
  // heuristic title similarity, especially with multiple artist credits.
  if (!result.manual && result.matchConfidence !== 'linked-recording' && confidence < 80) {
    return { status: 'ambiguous', confidence, candidates: await reviewCandidates(result), cached,
      reviewReason: 'The recording is associated with this song, but artist/title metadata differs. Confirm the correct mix before using its key.',
      reviewCode: 'unconfirmed-metadata' };
  }
  const suggested = cleanSuggestion(result.track, result.features, result.analysisSource);
  if (!suggested || !suggested.camelot) {
    const features = result.features || {};
    const kind = !CORE_FEATURES.some(field => presentFeature(features, field))
      ? 'no-features' : 'key-unavailable';
    return { status: 'missing_key', cached, missingKeyReason: kind,
      fallbackStatus: result.fallbackStatus || null };
  }
  return { status: 'ok', track: suggested, cached, confidence };
}

async function cachedHarmonicCandidates(isrc, camelot, title, artist) {
  const allowed = camelotNeighbours(camelot);
  if (!allowed.size) return [];
  const seed = { isrc: String(isrc || '').toUpperCase(), identity: suggestionId({ title, artist }) };
  return knownTracksFromCache(seed, allowed);
}

const CONTENT_HOSTS = new Set(['music.youtube.com', 'open.spotify.com']);
function trustedContentSender(sender) {
  if (!sender?.url) return true; // Options page messages originate inside extension.
  try {
    const url = new URL(sender.url);
    return url.protocol === 'https:' && CONTENT_HOSTS.has(url.hostname);
  } catch { return false; }
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!trustedContentSender(sender)) return false;
  const action = message?.type;
  if (action === 'OPEN_OPTIONS') {
    chrome.runtime.openOptionsPage()
      .then(() => respond({ ok: true }))
      .catch(error => respond({ ok: false, error: error.message || String(error) }));
    return true;
  }
  if (!['LOOKUP_TRACK', 'SELECT_MATCH', 'SEARCH_MATCH', 'RETRY_FALLBACK', 'SELECT_RECCO_FALLBACK', 'SAVE_MANUAL_FEATURES', 'CLEAR_MANUAL_FEATURES', 'ANALYSE_DISCOVERY_CANDIDATE', 'GET_CACHED_MIXES'].includes(action)) return false;
  if (action === 'GET_CACHED_MIXES') {
    cachedHarmonicCandidates(message.isrc, message.camelot, message.title, message.artist)
      .then(data => respond({ ok: true, data }))
      .catch(error => respond({ ok: false, error: error.message || String(error) }));
    return true;
  }
  const title = String(message.title || '').trim().slice(0, 240);
  const artist = String(message.artist || '').trim().slice(0, 240);
  if (!title || !artist) {
    respond({ ok: false, error: 'No song title or artist detected.' });
    return false;
  }
  let promise;
  const spotifyId = SPOTIFY_ID_RE.test(message.trackId || '') ? message.trackId : '';
  if (action === 'ANALYSE_DISCOVERY_CANDIDATE') promise = analyseDiscoveryCandidate(title, artist, spotifyId, Boolean(message.refresh));
  if (action === 'LOOKUP_TRACK') promise = lookup(title, artist, Boolean(message.refresh),
    String(message.rawTitle || ''), String(message.rawArtist || ''), spotifyId);
  if (action === 'SELECT_MATCH') promise = manualDetail(title, artist, String(message.isrc || ''), spotifyId);
  if (action === 'SEARCH_MATCH') promise = manualSearch(title, artist, String(message.query || '').trim());
  if (action === 'RETRY_FALLBACK') promise = retryFallback(title, artist, spotifyId);
  if (action === 'SELECT_RECCO_FALLBACK') promise = selectReccoFallback(title, artist, String(message.candidateId || ''));
  if (action === 'SAVE_MANUAL_FEATURES') promise = saveUserMetrics(title, artist, message.manualFeatures, message.manualSource);
  if (action === 'CLEAR_MANUAL_FEATURES') promise = clearUserMetrics(title, artist);
  Promise.resolve(promise)
    .then(data => respond({ ok: true, data: data?.status === 'ok'
      ? { ...data, featureSources: featureSourceMap(data) } : data }))
    .catch(error => respond({ ok: false, error: error.message || String(error) }));
  return true; // Keep the MV3 messaging channel open for the async API calls.
});

// Clicking the toolbar icon opens the same quick-start and settings page.
chrome.action.onClicked.addListener(() => {
  chrome.runtime.openOptionsPage().catch(error => console.warn('Track Lens options:', error));
});
