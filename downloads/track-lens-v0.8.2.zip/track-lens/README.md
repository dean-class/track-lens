# Track Lens 0.8.2 - private beta release candidate

Track Lens adds BPM, Camelot key, energy/danceability and Mix Next to the Spotify Web Player and YouTube Music in Chromium-based browsers.

## Changes since v0.8.1

- Incompatible Camelot keys are **never** displayed in the verified harmonic suggestions list. They appear in a separate, clearly marked Related tracks section instead.
- Spotify Queue diagnostics appear only on Spotify, even when advanced diagnostics are enabled.
- **Scan New Tracks** reads newly loaded Radio/Queue/Up Next entries without re-analysing previously checked songs.
- **Retry Failed Lookups** checks up to eight failed, missing, or incomplete analyses at a time, and bypasses their old lookup cache. This can use extra API requests or hit provider rate limits.
- **Dismiss this suggestion** hides an incorrect uncertain-match review for the current seed song. Restore dismissed reviews from the same panel; choices are saved locally and included in backups.
- Existing dark/light themes, desktop dragging, larger desktop typography, mobile strip, provider fallback and manual metrics are retained.

## Installation and updating

Extract the ZIP, then load the folder containing `manifest.json` via Chrome's or Vivaldi's `Load unpacked` option. Existing users must copy the new contents into the **existing extension installation folder** rather than installing a separate unpacked extension. Reload the extension at `chrome://extensions` or `vivaldi://extensions`, then reopen music tabs. Export a private backup from Help & Settings before large upgrades.

## Important limitations

This is beta software. Catalogue coverage varies, some recordings require manual selection, and musical-key agreement alone doesn't establish a seamless DJ transition. Related tracks are **not** harmonic recommendations. Only public track metadata is queried for analysis; no playback audio is recorded. Song Finder and ReccoBeats impose their own service availability and rate limits. Unpacked extensions require manual updates. Read the privacy page on the download site before distribution.

## Developer regression checks

JavaScript syntax, simulated playback for both platform IDs, separated harmonic/related cards, rescan/retry differences, seed-specific dismissal and restore, 390 px mobile light theme, desktop dragging/persistence and GitHub Pages links should all pass before sharing.
